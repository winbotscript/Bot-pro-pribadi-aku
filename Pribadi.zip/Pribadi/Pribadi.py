from TEAM_TERMUX import *
from justgood import imjustgood
from BEAPI import BEAPI
from Liff.ttypes import LiffChatContext, LiffContext, LiffSquareChatContext, LiffNoneContext, LiffViewRequest
from akad.ttypes import Message
from akad.ttypes import ContentType as Type
from akad.ttypes import TalkException
from datetime import timedelta, date
from datetime import datetime
from thrift.protocol import TCompactProtocol
from thrift.transport import THttpClient
from thrift.TMultiplexedProcessor import *
from thrift.TSerialization import *
from thrift.TRecursive import *
from time import sleep
from bs4 import BeautifulSoup as bSoup
from bs4 import BeautifulSoup
import calculators
from calculators.apself import ApCalculator
from humanfriendly import format_timespan, format_size, format_number, format_length
from Naked.toolshed.shell import execute_js
from threading import Thread
from io import StringIO
from multiprocessing import Pool
from googletrans import Translator
from urllib.parse import urlencode
from wikiapi import WikiApi
from random import randint
from shutil import copyfile
import youtube_dl
from youtube_dl import YoutubeDL
import subprocess, youtube_dl, humanize, traceback
import subprocess as cmd
import platform
import requests, json
import time, random, sys, json, null, pafy, codecs, html5lib ,shutil ,threading, glob, re, base64, string, os, requests, six, ast, pytz, wikipedia, urllib, urllib.parse, atexit, asyncio, traceback
_session = requests.session()
try:
    import urllib.request as urllib2
except ImportError:
    import urllib2
#=========================================================
#f = open('token1.txt','r')
#token = f.read()

#cl = LINE("{}".format(str(token)))
#f.close()
cl = LINE("imel@gmail.com","kata sandi")
cl.log("Auth Token : " + str(cl.authToken))
cl.log("Timeline Token : " + str(cl.tl.channelAccessToken))
#=========================================================
oepoll = OEPoll(cl)
#=========================================================
#=========================================================
clProfile = cl.getProfile()
clSettings = cl.getSettings()
#=========================================================
clMID = cl.profile.mid
mid = cl.profile.mid
creator = ["isi mid mu di sini"]
owner = ["isi mid mu di sini"]
admin = ["isi mid mu di sini"]
staff = ["isi mid mu di sini"]
KAC = [cl]
ABC = [cl]
Bots = [mid]
Alvian = creator + owner+ admin + staff
#=========================================================
protectqr = []
protectkick = []
protectjoin = []
protectinvite = []
protectcancel = []
welcome = []
leave = []
msg_dict = {}
msg_dict1 = {}
#=========================================================
settings = {
    "Picture":False,
    "group":{},
    "groupPicture":False,
    "changePicture":False,
    "changeCover":{},
    "autoJoinTicket":False,
    "readerPesan": "Gw @!, Kang Sider",
    "userAgent": [
        "Mozilla/5.0 (X11; U; Linux i586; de; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; U; Linux amd64; rv:5.0) Gecko/20100101 Firefox/5.0 (Debian)",
        "Mozilla/5.0 (X11; U; Linux amd64; en-US; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 FirePHP/0.5",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux ppc; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux AMD64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; FreeBSD amd64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; rv:6.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1.1; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; U; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; rv:2.0.1) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; rv:5.0) Gecko/20100101 Firefox/5.0"
    ]
}

tailah = {
    "siderTemp": {},
    "siderPesan": "You can join chat?",
}

read = { 
    "readMember": {},
    "readPoint": {}
}

tes = {
    "Message": {},
    "msg": {},
}

tes2 = {
    "Message2": {},
    "msg2": {},
}

wait = {
    "Limit": 50,
    "owner":{},
    "admin":{},
    "addadmin":False,
    "delladmin":False,
    "staff":{},
    "addstaff":False,
    "dellstaff":False,
    "bots":{},
    "addbots":False,
    "dellbots":False,
    "blacklist":{},
    "wblacklist":False,
    "dblacklist":False,
    "Talkblacklist":{},
    "Talkwblacklist":False,
    "Talkdblacklist":False,
    "talkban":False,
    "tiktok":True,
    "contact":False,
    'autoBlock':False,
    'autoJoin':True,
    'autoAdd':True,
    'autotext':False,
    'autoLeave':False,
    'Timeline':False,
    "detectMention":False,
    "Mentionkick":False,
    "welcomeOn":False,
    "stickerOn":False,
    "sticker":False,
    "smule": True,
    "smulenotife":False,
    "changevp": False,
    "changeFoto": {},
    "likeOn": False,
    "stickers": {},
    "salam" : "وَعَلَيْكُمْ السَّلاَمُ وَرَحْمَةُ اللهِ وَبَرَكَاتُهُ",
    "apikey" : "Rambu86",
    "call" : False,
    "callText": "Maaf kak belum bisa naik,lagi tanggung dikit lagi ya",
    "apkTikel": True,
    "AddstickerSider": {
        "sid": "",
        "spkg": "",
        "status": False
    },
    "AddstickerTag": {
        "sid": "",
        "spkg": "",
        "status": False
    },
    "AddstickerPesan": {
        "sid": "",
        "spkg": "",
        "status": False
    },
    "AddstickerWelcome": {
        "sid": "",
        "spkg": "",
        "status": False
    },
    "AddstickerLeave": {
        "sid": "",
        "spkg": "",
        "status": False
    },
    "stk":{},
    "selfbot":True,
    "token":True,
    "yt":True,
    "responGc":True,
    "Images":{},
    "Img":{},
    "Addimage":{},
    "Videos":{},
    "Video":{},
    "Addvideo":{},
    "laranganOn":True,
    "chat":False,
    "link":"https://i.gifer.com/7CJk.gif",
    "link":"https://www.smule.com",
    "mention":"Hati-Hati Kalau Ketemu Orang ini, Langsung Kabur Aja! ",
    "Respontag":"Jangan Suka Tag Teg Tog Kaka, Jewer Nih Kapok!!",
    "leave":"Terimakasih Kak Sudah Pernah Ada Di Room ini, Sampai Jumpa Lagi",
    "welcome":"Hallo Kak Selemat Datang, Salam Kenal Ya Kak, Semoga Betah Kak",
    "comment":"""
╭─「 Zulkifli 」─
│• 
│• Done Like & Comment
│• Add Owner kami
│• line.me/ti/p/~linux.1""",
    "message":"THANKS SUDAH ADD",
    "unsend":False,
    }

read = {
    "readPoint":{},
    "readMember":{},
    "readTime":{},
    "ROM":{},
}

comd = {
    "help": "help",
    "speed": "speed",
    "kick": "kick",
    "tagall": "hay",
    "cban": "cban",
    "siderOn": "sider on",
    "siderOff": "sider off",
    "bye": "@bye",
    "unsend": "unsend"
}

cctv = {
    "cyduk":{},
    "point":{},
    "sidermem":{}
}

temptag = {
    "stealtag":False,
    "respontag":False,
}

with open('creator.json', 'r') as fp:
    creator = json.load(fp)
with open('owner.json', 'r') as fp:
    owner = json.load(fp)
with open('sticker.json', 'r') as fp:
    stickers = json.load(fp)

Setbot = codecs.open("setting.json","r","utf-8")
Setmain = json.load(Setbot)

stickersOpen = codecs.open("sticker.json","r","utf-8")
stickers = json.load(stickersOpen)

mulai = time.time()

def speedtest(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours,24)
    weaks, days = divmod(days,7)
    if days == 0:
        return '%02d' % (secs)
    elif days > 0 and weaks == 0:
        return '%02d' %(secs)
    elif days > 0 and weaks > 0:
        return '%02d' %(secs)

def restart_program(): 
    python = sys.executable
    os.execl(python, python, * sys.argv)

def restartBot():
    python = sys.executable
    os.execl(python, python, *sys.argv)

def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    return '%02d Jam %02d Menit %02d Detik' % (hours, mins, secs)

def runtime(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)
    
def runtime2(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Menit %02d Detik' % (mins, secs)
   
def pretyPrintJson(djson):
        print(json.dumps(djson, indent=4, sort_keys=True))   

def allowLiff():
    url = 'https://access.line.me/dialog/api/permissions'
    data = {'on': ['P','CM'],'off': []}
    headers = {'X-Line-Access': cl.authToken,'X-Line-Application': cl.server.APP_NAME,'X-Line-ChannelId': '1602687308','Content-Type': 'application/json'}
    requests.post(url, json=data, headers=headers)

def flex3(to, text):
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    data = { "type": "flex", "altText": "TEAM TERMUX", "contents": { "type": "bubble", "size": "micro", "body": { "type": "box", "layout": "vertical", "contents": [ { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "TEAM TERMUX", "size": "12px", "color": "#00ff00", "align": "center", "wrap": True, "offsetTop": "2px" } ], "width": "140px", "height": "20px", "backgroundColor": "#000000", "borderWidth": "1px", "borderColor": "#00ff00", "cornerRadius": "4px" }, { "type": "text", "text": text, "size": "10px", "color": "#ffffff", "wrap": True }, { "type": "box", "layout": "vertical", "contents": [ { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/KbfDFN1/1657636839741.jpg", "size": "full", "aspectRatio": "1:1", "aspectMode": "cover", "animated": True } ], "position": "absolute", "width": "25px", "height": "25px", "backgroundColor": "#000000" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "TEAM TERMUX", "color": "#00ff00", "align": "center", "size": "10px", "offsetTop": "2px" } ], "position": "absolute", "width": "105px", "height": "17px", "borderWidth": "0.5px", "borderColor": "#00ff00", "cornerRadius": "2px", "offsetStart": "27px", "offsetTop": "3px" } ], "width": "140px", "height": "25px", "backgroundColor": "#000000", "borderWidth": "1px", "borderColor": "#00ff00", "cornerRadius": "4px" } ], "backgroundColor": "#000000", "borderWidth": "1px", "borderColor": "#00ff00", "cornerRadius": "10px" }, "action": { "type": "uri", "label": "action", "uri": "line://nv/profilePopup/mid=u1094909befea4ff8d79d5f71d5356afb" } } }
    sendTemplate(to, data)

def flexvian(to, text):
    contact = cl.getProfile()
    mids = [contact.mid]
    status = cl.getContact(mid)
    scover = cl.getProfileCoverURL(mid)
    data = {"type": "flex","altText": "TEAM TERMUX","contents": {"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","contents": [{"type": "separator","color": "#00ff00","margin": "5px"},{"type": "text","text": text,"size": "10px","color": "#ffffff","wrap": True,"offsetStart": "2px","offsetBottom": "12px","align": "center"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/KbfDFN1/1657636839741.jpg","size": "full","aspectRatio": "1:1","aspectMode": "cover","animated": True}],"position": "absolute","width": "17px","height": "17px","backgroundColor": "#000000","borderWidth": "0.5px","borderColor": "#00ff00","cornerRadius": "50px","offsetBottom": "3px","offsetStart": "10px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "TEAM TERMUX","size": "12px","color": "#ffffff","align": "center"}],"position": "absolute","width": "125px","height": "17px","offsetBottom": "3px","offsetEnd": "7px"}],"backgroundColor": "#000000","borderWidth": "0.5px","borderColor": "#ffffff","cornerRadius": "10px"},"action": {"type": "uri","label": "action","uri": "line://nv/profilePopup/mid=u1094909befea4ff8d79d5f71d5356afb"}}}
    sendTemplate(to, data)

def flex2(to, text):
    contact = cl.getProfile()
    mids = [contact.mid]
    status = cl.getContact(mid)
    scover = cl.getProfileCoverURL(mid)
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    data = {"type": "flex","altText": "TEAM TERMUX","contents": {"type": "bubble","size": "micro","header": {"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/KbfDFN1/1657636839741.jpg","size": "full","aspectRatio": "1:1","aspectMode": "cover","animated": True}],"position": "absolute","width": "17px","height": "17px","backgroundColor": "#000000","offsetEnd": "5px","cornerRadius": "50px","offsetTop": "2px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "TEAM TERMUX","size": "10px","color": "#ffffff","align": "center"}],"position": "absolute","width": "130px","height": "15px","borderWidth": "0.5px","borderColor": "#ffffff","cornerRadius": "3px","offsetTop": "3px","offsetStart": "5px"}],"backgroundColor": "#000000"},"body": {"type": "box","layout": "vertical","contents": [{"type": "text","text": text,"size": "10px","color": "#000000","wrap": True}]},"action": {"type": "uri","label": "action","uri": "line://nv/profilePopup/mid=u1094909befea4ff8d79d5f71d5356afb"}}}
    sendTemplate(to, data)

def flexhelp(to, text):
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    contact = cl.getContact(mid)
    data = {"type": "flex","altText": "TEAM TERMUX","contents": {"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/h8bC8T2/1639913956273.png","size": "full","aspectMode": "cover","aspectRatio": "2:3","backgroundColor": "#000000"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/KbfDFN1/1657636839741.jpg","size": "full","aspectRatio": "1:1","aspectMode": "cover","animated": True}],"position": "absolute","width": "30px","height": "30px","backgroundColor": "#000000","cornerRadius": "50px","offsetTop": "3px","offsetStart": "8px","borderWidth": "0.1px","borderColor": "#00ffff"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/KbfDFN1/1657636839741.jpg","size": "full","aspectRatio": "1:1","aspectMode": "cover","animated": True}],"position": "absolute","width": "13px","height": "13px","backgroundColor": "#000000","cornerRadius": "50px","offsetTop": "17px","offsetStart": "47px","borderWidth": "0.1px","borderColor": "#00ffff"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/KbfDFN1/1657636839741.jpg","size": "full","aspectRatio": "2:3","aspectMode": "cover","animated": True}],"position": "absolute","width": "130px","height": "170px","offsetTop": "50px","offsetStart": "13px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "🄼🄰🄸🄽 🄼🄴🄽🅄","size": "8px","color": "#00ffff","align": "center","offsetTop": "3px"}],"position": "absolute","width": "77px","height": "14px","borderWidth": "0.1px","borderColor": "#00ffff","cornerRadius": "3px","offsetTop": "17px","offsetEnd": "14px"},{"type": "box","layout": "horizontal","contents": [{"type": "text","text": "𝐀𝐃𝐌𝐈𝐍","size": "10px","color": "#00ffff","align": "center","offsetTop": "4px"}],"position": "absolute","width": "80px","height": "20px","backgroundColor": "#000000","borderWidth": "0.5px","borderColor": "#00ffff","cornerRadius": "5px","offsetTop": "50px","offsetStart": "43px","action": {"type": "uri","label": "action","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=Admin"}},{"type": "box","layout": "horizontal","contents": [{"type": "text","text": "𝐓𝐑𝐀𝐍𝐒𝐋𝐀𝐓𝐄","size": "10px","color": "#00ffff","align": "center","offsetTop": "4px"}],"position": "absolute","width": "80px","height": "20px","backgroundColor": "#000000","borderWidth": "0.5px","borderColor": "#00ffff","cornerRadius": "5px","offsetTop": "80px","offsetStart": "43px","action": {"type": "uri","label": "action","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=Translate"}},{"type": "box","layout": "horizontal","contents": [{"type": "text","text": "𝐁𝐀𝐍𝐍𝐄𝐃","size": "10px","color": "#00ffff","align": "center","offsetTop": "4px"}],"position": "absolute","width": "80px","height": "20px","backgroundColor": "#000000","borderWidth": "0.5px","borderColor": "#00ffff","cornerRadius": "5px","offsetTop": "110px","offsetStart": "43px","action": {"type": "uri","label": "action","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=Banned"}},{"type": "box","layout": "horizontal","contents": [{"type": "text","text": "𝐒𝐄𝐓𝐓𝐈𝐍𝐆","size": "10px","color": "#00ffff","align": "center","offsetTop": "4px"}],"position": "absolute","width": "80px","height": "20px","backgroundColor": "#000000","borderWidth": "0.5px","borderColor": "#00ffff","cornerRadius": "5px","offsetTop": "140px","offsetStart": "43px","action": {"type": "uri","label": "action","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=Setting"}},{"type": "box","layout": "horizontal","contents": [{"type": "text","text": "𝐆𝐑𝐎𝐔𝐏","size": "10px","color": "#00ffff","align": "center","offsetTop": "4px"}],"position": "absolute","width": "80px","height": "20px","backgroundColor": "#000000","borderWidth": "0.5px","borderColor": "#00ffff","cornerRadius": "5px","offsetTop": "170px","offsetStart": "43px","action": {"type": "uri","label": "action","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=Group"}},{"type": "box","layout": "horizontal","contents": [{"type": "text","text": "𝐌𝐄𝐃𝐈𝐀","size": "10px","color": "#00ffff","align": "center","offsetTop": "4px"}],"position": "absolute","width": "80px","height": "20px","backgroundColor": "#000000","borderWidth": "0.5px","borderColor": "#00ffff","cornerRadius": "5px","offsetTop": "200px","offsetStart": "43px","action": {"type": "uri","label": "action","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=Media"}},{"type": "text","text": "TEAM TERMUX","size": "6px","color": "#ffffff","offsetTop": "1px","offsetEnd": "27px","position": "absolute"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "𝔖𝔢𝔩𝔣𝔟𝔬𝔱","size": "6px","color": "#00ffff","align": "center","offsetTop": "1px"}],"position": "absolute","width": "46px","height": "8px","borderWidth": "0.1px","borderColor": "#00ffff","cornerRadius": "2px","offsetBottom": "1.5px","offsetStart": "12px","backgroundColor": "#000000"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "𝔗𝔢𝔪𝔭𝔩𝔞𝔱𝔢","size": "6px","color": "#00ffff","align": "center","offsetTop": "1px"}],"position": "absolute","width": "46px","height": "8px","borderWidth": "0.1px","borderColor": "#00ffff","cornerRadius": "2px","offsetBottom": "1.5px","backgroundColor": "#000000","offsetEnd": "10.5px"}],"paddingAll": "0px"},"action": {"type": "uri","label": "action","uri": "line://nv/profilePopup/mid=u1094909befea4ff8d79d5f71d5356afb"}},{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/h8bC8T2/1639913956273.png","size": "full","aspectMode": "cover","aspectRatio": "2:3","backgroundColor": "#000000"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/KbfDFN1/1657636839741.jpg","size": "full","aspectRatio": "1:1","aspectMode": "cover","animated": True}],"position": "absolute","width": "30px","height": "30px","backgroundColor": "#000000","cornerRadius": "50px","offsetTop": "3px","offsetStart": "8px","borderWidth": "0.1px","borderColor": "#00ffff"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/KbfDFN1/1657636839741.jpg","size": "full","aspectRatio": "1:1","aspectMode": "cover","animated": True}],"position": "absolute","width": "13px","height": "13px","backgroundColor": "#000000","cornerRadius": "50px","offsetTop": "17px","offsetStart": "47px","borderWidth": "0.1px","borderColor": "#00ffff"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/KbfDFN1/1657636839741.jpg","size": "full","aspectRatio": "2:3","aspectMode": "cover","animated": True}],"position": "absolute","width": "130px","height": "170px","offsetTop": "50px","offsetStart": "13px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "🄼🄰🄸🄽 🄼🄴🄽🅄","size": "8px","color": "#00ffff","align": "center","offsetTop": "3px"}],"position": "absolute","width": "77px","height": "14px","borderWidth": "0.1px","borderColor": "#00ffff","cornerRadius": "3px","offsetTop": "17px","offsetEnd": "14px"},{"type": "box","layout": "horizontal","contents": [{"type": "text","text": "𝐏𝐑𝐎𝐓𝐄𝐂𝐓","size": "10px","color": "#00ffff","align": "center","offsetTop": "4px"}],"position": "absolute","width": "80px","height": "20px","backgroundColor": "#000000","borderWidth": "0.5px","borderColor": "#00ffff","cornerRadius": "5px","offsetTop": "50px","offsetStart": "43px","action": {"type": "uri","label": "action","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=Protect"}},{"type": "box","layout": "horizontal","contents": [{"type": "text","text": "𝐏𝐑𝐎𝐅𝐈𝐋𝐄","size": "10px","color": "#00ffff","align": "center","offsetTop": "4px"}],"position": "absolute","width": "80px","height": "20px","backgroundColor": "#000000","borderWidth": "0.5px","borderColor": "#00ffff","cornerRadius": "5px","offsetTop": "80px","offsetStart": "43px","action": {"type": "uri","label": "action","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=Profile"}},{"type": "box","layout": "horizontal","contents": [{"type": "text","text": "𝐑𝐄𝐌𝐎𝐓𝐄","size": "10px","color": "#00ffff","align": "center","offsetTop": "4px"}],"position": "absolute","width": "80px","height": "20px","backgroundColor": "#000000","borderWidth": "0.5px","borderColor": "#00ffff","cornerRadius": "5px","offsetTop": "110px","offsetStart": "43px","action": {"type": "uri","label": "action","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=Remote"}},{"type": "box","layout": "horizontal","contents": [{"type": "text","text": "𝐇𝐄𝐋𝐏 𝐉𝐒","size": "10px","color": "#00ffff","align": "center","offsetTop": "4px"}],"position": "absolute","width": "80px","height": "20px","backgroundColor": "#000000","borderWidth": "0.5px","borderColor": "#00ffff","cornerRadius": "5px","offsetTop": "140px","offsetStart": "43px","action": {"type": "uri","label": "action","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=Help%20js"}},{"type": "box","layout": "horizontal","contents": [{"type": "text","text": "𝐒𝐓𝐀𝐓𝐔𝐒","size": "10px","color": "#00ffff","align": "center","offsetTop": "4px"}],"position": "absolute","width": "80px","height": "20px","backgroundColor": "#000000","borderWidth": "0.5px","borderColor": "#00ffff","cornerRadius": "5px","offsetTop": "170px","offsetStart": "43px","action": {"type": "uri","label": "action","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=Status"}},{"type": "box","layout": "horizontal","contents": [{"type": "text","text": "𝐂𝐑𝐄𝐀𝐓𝐎𝐑","size": "10px","color": "#00ffff","align": "center","offsetTop": "4px"}],"position": "absolute","width": "80px","height": "20px","backgroundColor": "#000000","borderWidth": "0.5px","borderColor": "#00ffff","cornerRadius": "5px","offsetTop": "200px","offsetStart": "43px","action": {"type": "uri","label": "action","uri": "line://app/1602687308-GXq4Vvk9?type=text&text=Creator"}},{"type": "text","text": "TEAM TERMUX","size": "6px","color": "#ffffff","offsetTop": "1px","offsetEnd": "27px","position": "absolute"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "𝔖𝔢𝔩𝔣𝔟𝔬𝔱","size": "6px","color": "#00ffff","align": "center","offsetTop": "1px"}],"position": "absolute","width": "46px","height": "8px","borderWidth": "0.1px","borderColor": "#00ffff","cornerRadius": "2px","offsetBottom": "1.5px","offsetStart": "12px","backgroundColor": "#000000"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "𝔗𝔢𝔪𝔭𝔩𝔞??𝔢","size": "6px","color": "#00ffff","align": "center","offsetTop": "1px"}],"position": "absolute","width": "46px","height": "8px","borderWidth": "0.1px","borderColor": "#00ffff","cornerRadius": "2px","offsetBottom": "1.5px","backgroundColor": "#000000","offsetEnd": "10.5px"}],"paddingAll": "0px"}}]}}
    sendTemplate(to, data)

def sendFlexVideo(to, videoUrl, thumbnail='dark'):
    main = ["dark","red","cyan","yellow","green","white"]
    if thumbnail in main:
       thumbnail = f"https://i.ibb.co/KbfDFN1/1657636839741.jpg"
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1602687308-GXq4Vvk9', xyzz)
    token = cl.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {'Content-Type': 'application/json','Authorization': 'Bearer %s' % token.accessToken}
    data = {'messages': [{'type': 'video','originalContentUrl': videoUrl,'previewImageUrl': thumbnail,}]}
    requests.post(url, headers=headers, data=json.dumps(data))

def sendFlexAudio(to, link):
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1602687308-GXq4Vvk9', xyzz)
    token = cl.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {'Content-Type': 'application/json','Authorization': 'Bearer %s' % token.accessToken}
    data = {'messages': [{'type': 'audio','originalContentUrl': link,'duration': 250000}]}
    requests.post(url, headers=headers, data=json.dumps(data))


def sendTemplate(to, data):
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1602687308-GXq4Vvk9', xyzz)
    token = cl.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))

def sendCarousel(to, data):
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1602687308-GXq4Vvk9', xyzz)
    token = cl.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))

def sendCarousel(to,col):
    col = json.dumps(col)
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1602687308-GXq4Vvk9', xyzz)
    token = cl.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    return requests.post(url, data=col, headers=headers)

def sendFoter(to, text):
    data = {"type": "text","text": text,"sentBy": {"label": "❑ TEAM TERMUX ❑","iconUrl": "https://i.ibb.co/KbfDFN1/1657636839741.jpg","linkUrl": "line://nv/profilePopup/mid=u1094909befea4ff8d79d5f71d5356afb"}}
    sendTemplate(to, data)

def failOverAPI():
    try:
        result = requests.get("https://api.boteater.xyz",timeout=0.5)
        if result.status_code == 200:
            return "https://api.boteater.xyz"
        else:
            return "https://api.boteater.us"
    except:
        return "https://api.boteater.us"

def cytmp4(to,url):
    import pafy
    vid = pafy.new(url,basic=False)
    result = vid.streams[-1]
    return result.url
    links = cytmp4(anunya);links = 'https://'+cl.google_url_shorten(links)
    
def pendekin(to,url):
    req_url = 'https://www.googleapis.com/urlshortener/v1/url?key=AIzaSyAzrJV41pMMDFUVPU0wRLtxlbEU-UkHMcI'
    payload = {'longUrl': url}
    headers = {'content-type': 'application/json'}
    r = requests.post(req_url, data=json.dumps(payload), headers=headers)
    resp = json.loads(r.text)
    return resp['id']

def changeVideoAndPictureProfile(pict, vids):
    try:
        files = {'file': open(vids, 'rb')}
        obs_params = cl.genOBSParams({'oid': mid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = cl.server.postContent('{}/talk/vp/upload.nhn'.format(str(cl.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return "update profile failed"
        cl.updateProfilePicture(pict, 'vp')
        return "Success update profile"
    except Exception as e:
        raise Exception("Error change video and picture profile {}".format(str(e)))
        os.remove("vp.mp4")

def changeProfileVideo(to):
    if settings['changevp']['picture'] == None:
        return cl.sendReplyMessage(msg_id, to, "Foto tidak ditemukan")
    elif settings['changevp']['video'] == None:
        return cl.sendReplyMessage(msg_id, to, "Video tidak ditemukan")
    else:
        path = settings['changevp']['video']
        files = {'file': open(path, 'rb')}
        obs_params = cl.genOBSParams({'oid': cl.getProfile().mid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = cl.server.postContent('{}/talk/vp/upload.nhn'.format(str(cl.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return cl.sendReplyMessage(msg_id, to, "Gagal update profile")
        path_p = settings['changevp']['picture']
        settings['changevp']['status'] = False
        cl.updateProfilePicture(path_p, 'vp')

def mentionMembers(to, mid):
    try:
        arrData = ""
        ginfo = cl.getGroup(to)
        textx = "╭─「 Daftar anggota 」\n├↘\n├↘1. "
        arr = []
        no = 1
        for i in mid:
            mention = "@x\n├↘\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention
            if no < len(mid):
                no += 1
                textx += "├↘ {}. ".format(str(no))
            else:
                textx += "╰─「 Mentions {} Member 」".format(str(len(mid)))
        cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def mentions(to, text="", mids=[]):
    arrData = ""
    arr = []
    mention = "@KhieGans  "
    if mids == []:
        raise Exception("Invalid mids")
    if "@!" in text:
        if text.count("@!") != len(mids):
            raise Exception("Invalid mids")
        texts = text.split("@!")
        textx = ""
        for mid in mids:
            textx += str(texts[mids.index(mid)])
            slen = len(textx)
            elen = len(textx) + 15
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
    else:
        textx = ""
        slen = len(textx)
        elen = len(textx) + 15
        arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
        arr.append(arrData)
        textx += mention + str(text)
    cl.sendMessage(to, textx, {'AGENT_NAME':'LINE OFFICIAL', 'AGENT_LINK': 'line://ti/p/~{}'.format(cl.getProfile().userid), 'AGENT_ICON': "http://dl.profile.line-cdn.net/" + cl.getContact("u176ef6889643e290ba5801bffc83457b").picturePath, 'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)

def khieMention(to, text="", mids=[]):
        arrData = ""
        arr = []
        mention = "@Mmk "
        if mids == []:
            raise Exception("Invalid mids")
        if "@!" in text:
            if text.count("@!") != len(mids):
                raise Exception("Invalid mids")
            texts = text.split("@!")
            textx = ''
            h = ''
            for mid in range(len(mids)):
                h+= str(texts[mid].encode('unicode-escape'))
                textx += str(texts[mid])
                if h != textx:slen = len(textx)+h.count('U0');elen = len(textx)+h.count('U0') + 5
                else:slen = len(textx);elen = len(textx) + 5
                arrData = {'S':str(slen), 'E':str(elen), 'M':mids[mid]}
                arr.append(arrData)
                textx += mention
            textx += str(texts[len(mids)])
        else:
            textx = ''
            slen = len(textx)
            elen = len(textx) + 18
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
            arr.append(arrData)
            textx += mention + str(text)
        cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)

def RhyN_(to, mid):
    try:
        aa = '{"S":"0","E":"5","M":'+json.dumps(mid)+'}'
        text_ = '@Khiez'
        cl.sendMessage(to, text_, contentMetadata={'MENTION':'{"MENTIONEES":['+aa+']}'}, contentType=0)
    except Exception as error:
        logError(error)

def sendMention(to, mid, firstmessage, lastmessage):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x "
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        cl.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def mentionMembers2(to, mids=[]):
    if clMID in mids: mids.remove(clMID)
    parsed_len = len(mids)//20+1
    result = '╭───❑ Mention All ❑\n'
    mention = '@zeroxyuuki\n'
    no = 0
    for point in range(parsed_len):
        mentionees = []
        for mid in mids[point*20:(point+1)*20]:
            no += 1
            result += '│ %i. %s' % (no, mention)
            slen = len(result) - 12
            elen = len(result) + 3
            mentionees.append({'S': str(slen), 'E': str(elen - 4), 'M': mid})
            if mid == mids[-1]:
                result += '╰───❑ TEAM TERMUX ❑\n'
        if result:
            if result.endswith('\n'): result = result[:-1]
            cl.sendMessage(to, result, {'MENTION': json.dumps({'MENTIONEES': mentionees})}, 0)
        result = ''

#message.createdTime -> 00:00:00
def cTime_to_datetime(unixtime):
    return datetime.fromtimestamp(int(str(unixtime)[:len(str(unixtime))-3]))
def dt_to_str(dt):
    return dt.strftime('%H:%M:%S')

#delete log if pass more than 24 hours
def delete_log():
    ndt = datetime.now()
    for data in msg_dict:
        if (datetime.utcnow() - cTime_to_datetime(msg_dict[data]["createdTime"])) > datetime.timedelta(1):
            del msg_dict[msg_id]

def atend():
    print("Saving")
    with open("Log_data.json","w",encoding='utf8') as f:
        json.dump(msg_dict, f, ensure_ascii=False, indent=4,separators=(',', ': '))
    print("BYE")

def removeCmd(cmd, text):
	key = Setmain["keyCommand"]
	#if Setmain["setKey"] == False: key = ''
	rmv = len(key + cmd) + 1
	return text[rmv:]

def command(text):
    pesan = text.lower()
    if pesan.startswith(Setmain["keyCommand"]):
        cmd = pesan.replace(Setmain["keyCommand"],"")
    else:
        cmd = "command"
    return cmd

def bot(op):
    global time
    global ast
    global groupParam
    try:
        if op.type == 0:
            print ("[25,26] SEND MESSAGE")
            return
        
        if op.type == 11 or op.type == 122:
            if op.param1 in protectqr:
                try:
                    if cl.getGroup(op.param1).preventedJoinByTicket == False:
                        if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                            cl.reissueGroupTicket(op.param1)
                            X = cl.getGroup(op.param1)
                            X.preventedJoinByTicket = True
                            cl.updateGroup(X)
                            cl.kickoutFromGroup(op.param1,[op.param2])
                except:
                    pass
                    
        if op.type == 13 or op.type == 124:
            if clMID in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                       cl.acceptGroupInvitation(op.param1)
                    else:
                       cl.acceptGroupInvitation(op.param1)                      

            if clMID in op.param3:
                if wait["autoLeave"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        cl.acceptGroupInvitation(op.param1)
                        cl.leaveGroup(op.param1)
                    else:
                        cl.acceptGroupInvitation(op.param1)                      

        if op.type == 13 or op.type == 124:
            if op.param1 in protectinvite:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    babi = op.param3.replace("",',')
                    memek = babi.split(",")
                    for sodok in memek:
                       cl.cancelGroupInvitation(op.param1,[sodok])
                       cl.kickoutFromGroup(op.param1,[op.param2])
                       wait["blacklist"] == True

        if op.type == 17 or op.type == 130:
            if op.param1 in welcome:
                ginfo = cl.getGroup(op.param1)
                contact = cl.getContact(op.param2)
                cover = cl.getProfileCoverURL(op.param2)
                tz = pytz.timezone("Asia/Jakarta")
                timeNow = datetime.now(tz=tz)
                gname = cl.getGroup(op.param1)
                data = {"type": "flex","altText": "TEAM TERMUX","contents": {"type": "bubble","size": "kilo","body": {"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/cxTtfqD/20211221-211015.png","size": "full","aspectRatio": "2:1","aspectMode": "cover"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://obs.line-scdn.net/{}".format(cl.getContact(op.param2).pictureStatus),"size": "full","aspectRatio": "1:1","aspectMode": "cover"}],"position": "absolute","width": "80px","height": "80px","backgroundColor": "#000000","cornerRadius": "1px","offsetTop": "10.5px","offsetEnd": "7.5px"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/KbfDFN1/1657636839741.jpg","size": "full","aspectRatio": "1:1","aspectMode": "cover","animated": True}],"position": "absolute","width": "32px","height": "32px","backgroundColor": "#000000","cornerRadius": "50px","offsetTop": "12.5px","offsetStart": "117.5px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(cl.getContact(op.param2).displayName),"size": "10px","color": "#ffffff","align": "center","offsetTop": "2px"}],"width": "105px","height": "20px","backgroundColor": "#000000","borderWidth": "1px","borderColor": "#0000ff","cornerRadius": "2px","offsetBottom": "4px","offsetEnd": "5px","position": "absolute"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "TEAM TERMUX","size": "10px","color": "#00ff00","align": "center","offsetTop": "3px"}],"width": "102px","height": "20px","backgroundColor": "#000000","borderWidth": "1px","borderColor": "#0000ff","cornerRadius": "2px","position": "absolute","offsetStart": "4px","offsetTop": "3px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "ᗯEᒪᑕOᗰE ᗰEᗰᗷEᖇ","size": "10px","color": "#ffffff","align": "center","offsetTop": "1px"}],"width": "110px","height": "15px","backgroundColor": "#00000050","borderWidth": "1px","borderColor": "#0000ff","cornerRadius": "2px","position": "absolute","offsetStart": "4px","offsetTop": "30px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": wait["mention"],"size": "10px","color": "#ffffff","align": "center","wrap": True}],"position": "absolute","width": "135px","height": "40px","backgroundColor": "#000000","borderWidth": "1px","borderColor": "#0000ff","cornerRadius": "2px","offsetBottom": "35px","offsetStart": "5px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": " "+ datetime.strftime(timeNow,'%H:%M:%S'),"size": "10px","color": "#00ff00","align": "center"}],"position": "absolute","width": "110px","height": "15px","backgroundColor": "#000000","borderWidth": "1px","borderColor": "#0000ff","cornerRadius": "2px","offsetBottom": "18px","offsetStart": "5px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": " " + datetime.strftime(timeNow,'%d-%m-%Y'),"size": "10px","color": "#00ff00","align": "center"}],"position": "absolute","width": "110px","height": "15px","backgroundColor": "#000000","borderWidth": "1px","borderColor": "#0000ff","cornerRadius": "2px","offsetBottom": "2px","offsetStart": "5px"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "{}".format(cover),"size": "full","aspectRatio": "1:1","aspectMode": "cover"}],"position": "absolute","width": "30px","height": "30px","backgroundColor": "#000000","borderWidth": "1px","borderColor": "#0000ff","cornerRadius": "1px","offsetBottom": "2.5px","offsetStart": "115px"}],"paddingAll": "0px","borderWidth": "2px","borderColor": "#0000ff","cornerRadius": "10px"},"action": {"type": "uri","label": "action","uri": "line://nv/profilePopup/mid=u1094909befea4ff8d79d5f71d5356afb"}}}
                sendTemplate(op.param1, data)                                                   
                sid = str(wait["AddstickerWelcome"]["sid"])
                spkg = str(wait["AddstickerWelcome"]["spkg"])
                cl.sendSticker(op.param1, spkg, sid)

        if op.type == 17 or op.type == 128:
            if op.param1 in leave:
                ginfo = cl.getGroup(op.param1)
                contact = cl.getContact(op.param2)
                cover = cl.getProfileCoverURL(op.param2)
                tz = pytz.timezone("Asia/Jakarta")
                timeNow = datetime.now(tz=tz)
                gname = cl.getGroup(op.param1)
                data = {"type": "flex","altText": "TEAM TERMUX","contents": {"type": "bubble","size": "kilo","body": {"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/cxTtfqD/20211221-211015.png","size": "full","aspectRatio": "2:1","aspectMode": "cover"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://obs.line-scdn.net/{}".format(cl.getContact(op.param2).pictureStatus),"size": "full","aspectRatio": "1:1","aspectMode": "cover"}],"position": "absolute","width": "80px","height": "80px","backgroundColor": "#000000","cornerRadius": "1px","offsetTop": "10.5px","offsetEnd": "7.5px"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/KbfDFN1/1657636839741.jpg","size": "full","aspectRatio": "1:1","aspectMode": "cover","animated": True}],"position": "absolute","width": "32px","height": "32px","backgroundColor": "#000000","cornerRadius": "50px","offsetTop": "12.5px","offsetStart": "117.5px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(cl.getContact(op.param2).displayName),"size": "10px","color": "#ffffff","align": "center","offsetTop": "2px"}],"width": "105px","height": "20px","backgroundColor": "#000000","borderWidth": "1px","borderColor": "#0000ff","cornerRadius": "2px","offsetBottom": "4px","offsetEnd": "5px","position": "absolute"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "TEAM TERMUX","size": "10px","color": "#00ff00","align": "center","offsetTop": "3px"}],"width": "102px","height": "20px","backgroundColor": "#000000","borderWidth": "1px","borderColor": "#0000ff","cornerRadius": "2px","position": "absolute","offsetStart": "4px","offsetTop": "3px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "LEAVE MEMBER","size": "10px","color": "#ffffff","align": "center","offsetTop": "1px"}],"width": "110px","height": "15px","backgroundColor": "#00000050","borderWidth": "1px","borderColor": "#0000ff","cornerRadius": "2px","position": "absolute","offsetStart": "4px","offsetTop": "30px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": wait["leave"],"size": "10px","color": "#ffffff","align": "center","wrap": True}],"position": "absolute","width": "135px","height": "40px","backgroundColor": "#000000","borderWidth": "1px","borderColor": "#0000ff","cornerRadius": "2px","offsetBottom": "35px","offsetStart": "5px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": " "+ datetime.strftime(timeNow,'%H:%M:%S'),"size": "10px","color": "#00ff00","align": "center"}],"position": "absolute","width": "110px","height": "15px","backgroundColor": "#000000","borderWidth": "1px","borderColor": "#0000ff","cornerRadius": "2px","offsetBottom": "18px","offsetStart": "5px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": " " + datetime.strftime(timeNow,'%d-%m-%Y'),"size": "10px","color": "#00ff00","align": "center"}],"position": "absolute","width": "110px","height": "15px","backgroundColor": "#000000","borderWidth": "1px","borderColor": "#0000ff","cornerRadius": "2px","offsetBottom": "2px","offsetStart": "5px"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "{}".format(cover),"size": "full","aspectRatio": "1:1","aspectMode": "cover"}],"position": "absolute","width": "30px","height": "30px","backgroundColor": "#000000","borderWidth": "1px","borderColor": "#0000ff","cornerRadius": "1px","offsetBottom": "2.5px","offsetStart": "115px"}],"paddingAll": "0px","borderWidth": "2px","borderColor": "#0000ff","cornerRadius": "10px"},"action": {"type": "uri","label": "action","uri": "line://nv/profilePopup/mid=u1094909befea4ff8d79d5f71d5356afb"}}}
                sendTemplate(op.param1, data)                                                   
                sid = str(wait["AddstickerLeave"]["sid"])
                spkg = str(wait["AddstickerLeave"]["spkg"])
                cl.sendSticker(op.param1, spkg, sid)

        if op.type == 17 or op.type == 130:
            if op.param1 in protectjoin:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    try:
                        if op.param3 not in wait["blacklist"]:
                        	cl.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        pass

            if op.param2 in wait["blacklist"]:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    X = cl.getGroup(op.param1)
                    X.preventedJoinByTicket = True
                    cl.updateGroup(X)
                    cl.kickoutFromGroup(op.param1,[op.param2])            
                        
                return

        if op.type == 0:
            return
        if op.type == 5:
              if wait["autoAdd"] == True:
                  ASU = {"type": "flex","altText": "TEAM TERMUX","contents": { "type": "bubble", "size": "micro", "body": { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/fkMChy0/20211223-051455.png", "size": "full", "aspectMode": "cover", "aspectRatio": "9:13" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/KbfDFN1/1657636839741.jpg", "size": "full", "aspectRatio": "1:1", "aspectMode": "cover", "animated": True } ], "position": "absolute", "width": "23px", "height": "23px", "backgroundColor": "#000000", "cornerRadius": "50px", "offsetTop": "1.5px", "offsetEnd": "8px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/KbfDFN1/1657636839741.jpg", "size": "full", "aspectRatio": "1:1", "aspectMode": "cover", "animated": True } ], "position": "absolute", "width": "23px", "height": "23px", "backgroundColor": "#000000", "cornerRadius": "50px", "offsetBottom": "1.2px", "offsetStart": "8px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": wait["message"], "size": "8px", "color": "#00ffff", "align": "center", "offsetTop": "2px" } ], "position": "absolute", "width": "90px", "height": "15px", "backgroundColor": "#000000", "borderWidth": "0.5px", "borderColor": "#00ffff", "cornerRadius": "2px", "offsetTop": "1.5px", "offsetEnd": "46px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "NOTIFED ADD CONTACT", "size": "8px", "color": "#00ffff", "align": "center", "offsetTop": "2px" } ], "position": "absolute", "width": "90px", "height": "15px", "backgroundColor": "#000000", "cornerRadius": "2px", "offsetBottom": "1.2px", "offsetStart": "45px", "borderWidth": "0.5px", "borderColor": "#00ffff" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "OPEN RENTAL BOTS", "size": "10px", "color": "#00ffff", "align": "center", "offsetTop": "1px" } ], "position": "absolute", "width": "140px", "height": "15px", "backgroundColor": "#000000", "borderWidth": "0.5px", "borderColor": "#00ffff", "cornerRadius": "1px", "offsetTop": "30px", "offsetStart": "9px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "PROTECT", "size": "11px", "color": "#00ffff", "align": "center", "offsetTop": "6px" } ], "position": "absolute", "width": "50px", "height": "30px", "backgroundColor": "#00000050" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "ROOM SMULE", "size": "10px", "color": "#ffffff", "align": "center" } ], "position": "absolute", "width": "90px", "height": "14.5px", "backgroundColor": "#00ff0050", "offsetStart": "50px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "ROOM EVENT", "size": "10px", "color": "#ffffff", "align": "center" } ], "position": "absolute", "width": "90px", "height": "14.5px", "backgroundColor": "#00ff0050", "offsetStart": "50px", "offsetTop": "15px" } ], "position": "absolute", "width": "140px", "height": "30px", "cornerRadius": "1px", "offsetTop": "48px", "offsetStart": "9px", "borderWidth": "0.5px", "borderColor": "#00ffff" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "GOLANG", "size": "11px", "color": "#00ffff", "align": "center", "offsetTop": "6px" } ], "position": "absolute", "width": "50px", "height": "30px", "backgroundColor": "#00000050" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "WAR BOT", "size": "10px", "color": "#ffffff", "align": "center" } ], "position": "absolute", "width": "90px", "height": "14.5px", "backgroundColor": "#00ff0050", "offsetStart": "50px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "CL WAR", "size": "10px", "color": "#ffffff", "align": "center" } ], "position": "absolute", "width": "90px", "height": "14.5px", "backgroundColor": "#00ff0050", "offsetStart": "50px", "offsetTop": "15px" } ], "position": "absolute", "width": "140px", "height": "30px", "cornerRadius": "1px", "offsetTop": "81px", "offsetStart": "9px", "borderWidth": "0.5px", "borderColor": "#00ffff" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "SELFBOT", "size": "11px", "color": "#00ffff", "align": "center", "offsetTop": "6px" } ], "position": "absolute", "width": "50px", "height": "30px", "backgroundColor": "#00000050" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "FULL TEMPLATE", "size": "10px", "color": "#ffffff", "align": "center" } ], "position": "absolute", "width": "90px", "height": "14.5px", "backgroundColor": "#00ff0050", "offsetStart": "50px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "ASIST + AJS", "size": "10px", "color": "#ffffff", "align": "center" } ], "position": "absolute", "width": "90px", "height": "14.5px", "backgroundColor": "#00ff0050", "offsetStart": "50px", "offsetTop": "15px" } ], "position": "absolute", "width": "140px", "height": "30px", "cornerRadius": "1px", "offsetTop": "114px", "offsetStart": "9px", "borderWidth": "0.5px", "borderColor": "#00ffff" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "TOKEN", "size": "11px", "color": "#00ffff", "align": "center", "offsetTop": "6px" } ], "position": "absolute", "width": "50px", "height": "30px", "backgroundColor": "#00000050" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "1 TOKEN 5K", "size": "10px", "color": "#ffffff", "align": "center" } ], "position": "absolute", "width": "90px", "height": "14.5px", "backgroundColor": "#00ff0050", "offsetStart": "50px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "FRESH TOKEN", "size": "10px", "color": "#ffffff", "align": "center" } ], "position": "absolute", "width": "90px", "height": "14.5px", "backgroundColor": "#00ff0050", "offsetStart": "50px", "offsetTop": "15px" } ], "position": "absolute", "width": "140px", "height": "30px", "cornerRadius": "1px", "offsetTop": "148px", "offsetStart": "9px", "borderWidth": "0.5px", "borderColor": "#00ffff" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "TAP HERE FOR ORDER", "size": "10px", "color": "#00ffff", "align": "center", "offsetTop": "3px" } ], "position": "absolute", "width": "140px", "height": "20px", "backgroundColor": "#000000", "borderWidth": "0.5px", "borderColor": "#00ffff", "cornerRadius": "1px", "offsetBottom": "27px", "offsetStart": "9px", "action": { "type": "uri", "label": "action", "uri": "http://line.me/ti/p/~linux.1" } } ], "paddingAll": "0px", "borderWidth": "1px", "borderColor": "#000000", "cornerRadius": "10px" }, "action": { "type": "uri", "label": "action", "uri": "line://nv/profilePopup/mid=u1094909befea4ff8d79d5f71d5356afb" } } }
                  sendTemplate(op.param1, ASU)          
                  sid = str(wait["AddstickerPesan"]["sid"])
                  spkg = str(wait["AddstickerPesan"]["spkg"])
                  cl.sendSticker(msg.to, spkg, sid)
#=========AUTOBLOCK===========
        if op.type == 5:
            print ("[ 5 ] NOTIFIED AUTO BLOCK CONTACT")
            if wait["autoBlock"] == True:
                cl.blockContact(op.param1)
                flex3(op.param1, "")

        if op.type == 65:
            if wait["unsend"] == True:
                try:
                    at = op.param1
                    msg_id = op.param2
                    if msg_id in msg_dict:
                        if msg_dict[msg_id]["from"]:
                           if msg_dict[msg_id]["text"] == 'Gambarnya dibawah':
                                ginfo = cl.getGroup(at)
                                ryan = cl.getContact(msg_dict[msg_id]["from"])
                                zx = ""
                                zxc = ""
                                zx2 = []
                                xpesan =  "╭─「 Gambar Dihapus 」\n│ Pengirim : "
                                ret_ = "│ Nama Grup : {}".format(str(ginfo.name))
                                ret_ += "\n│ Waktu Ngirim : {}".format(dt_to_str(cTime_to_datetime(msg_dict[msg_id]["createdTime"])))
                                ry = str(ryan.displayName)
                                pesan = ''
                                pesan2 = pesan+"@x \n"
                                xlen = str(len(zxc)+len(xpesan))
                                xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                zx = {'S':xlen, 'E':xlen2, 'M':ryan.mid}
                                zx2.append(zx)
                                zxc += pesan2
                                text = xpesan + zxc + ret_ + ""
                                cl.sendMessage(at, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                                cl.sendImage(at, msg_dict[msg_id]["data"])
                           else:
                                ginfo = cl.getGroup(at)
                                ryan = cl.getContact(msg_dict[msg_id]["from"])
                                ret_ =  "╭─「 Pesan Dihapus 」\n"
                                ret_ += "│ Pengirim : {}".format(str(ryan.displayName))
                                ret_ += "\n│ Nama Grup : {}".format(str(ginfo.name))
                                ret_ += "\n│ Waktu Ngirim : {}".format(dt_to_str(cTime_to_datetime(msg_dict[msg_id]["createdTime"])))
                                ret_ += "\n│ Pesannya : {}".format(str(msg_dict[msg_id]["text"]))
                                ret_ += "\n╰───────────"
                                flex3(at, str(ret_))
                        del msg_dict[msg_id]
                except Exception as e:
                    print(e)

        if op.type == 65:
            if wait["unsend"] == True:
                try:
                    at = op.param1
                    msg_id = op.param2
                    if msg_id in msg_dict1:
                        if msg_dict1[msg_id]["from"]:
                                ginfo = cl.getGroup(at)
                                ryan = cl.getContact(msg_dict1[msg_id]["from"])
                                ret_ =  "╭─「 Sticker Dihapus 」\n"
                                ret_ += "│ Pengirim : {}".format(str(ryan.displayName))
                                ret_ += "\n│ Nama Grup : {}".format(str(ginfo.name))
                                ret_ += "\n│ Waktu Ngirim : {}".format(dt_to_str(cTime_to_datetime(msg_dict1[msg_id]["createdTime"])))
                                ret_ += "{}".format(str(msg_dict1[msg_id]["text"]))
                                ret_ += "\n╰───────────"
                                flex3(at, str(ret_))
                                cl.sendImage(at, msg_dict1[msg_id]["data"])
                        del msg_dict1[msg_id]
                except Exception as e:
                    print(e)

        if op.type == 19 or op.type == 133:     
            if op.param1 in protectkick:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    cl.kickoutFromGroup(op.param1,[op.param2])
                else:
                    pass

        if op.type == 32 or op.type == 126:                 
            if op.param1 in protectcancel:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    try:
                        if op.param3 not in wait["blacklist"]:
                            cl.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        pass
                        
                return

        if op.type == 55:
            if op.param2 in wait["blacklist"]:
                random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
            else:
                pass

            if op.param1 in Setmain["RAreadPoint"]:
                if op.param2 in Setmain["RAreadMember"][op.param1]:
                    pass
                else:
                    Setmain["RAreadMember"][op.param1][op.param2] = True
            else:
                pass

        if op.type == 55:
            if cctv['cyduk'][op.param1]==True:
                if op.param1 in cctv['point']:
                    Name = cl.getContact(op.param2).displayName
                    if Name in cctv['sidermem'][op.param1]:
                        pass
                    else:
                        cctv['sidermem'][op.param1] += "\n~ " + Name
                        contact = cl.getContact(op.param2)
                        tz = pytz.timezone("Asia/Jakarta")
                        cover = cl.getProfileCoverURL(op.param2)
                        timeNow = datetime.now(tz=tz)
                        data1 = {"type": "flex","altText": "TEAM TERMUX","contents":{ "type": "bubble", "size": "kilo", "body": { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/sCvs3P1/ezgif-com-gif-maker-44.png", "size": "full", "aspectMode": "cover", "aspectRatio": "5:2" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://obs.line-scdn.net/{}".format(cl.getContact(op.param2).pictureStatus), "aspectRatio": "1:1", "aspectMode": "cover" } ], "position": "absolute", "width": "65px", "height": "65px", "backgroundColor": "#000000", "cornerRadius": "50px", "offsetTop": "6.5px", "offsetEnd": "3px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/25Td9hk/ezgif-com-gif-maker-45.png", "size": "full", "aspectRatio": "1:1", "aspectMode": "cover", "animated": True } ], "position": "absolute", "width": "60px", "height": "60px", "offsetTop": "20.5px", "offsetEnd": "110px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/7K8xYXS/ezgif-com-gif-maker-34.png", "size": "full", "aspectRatio": "1:1", "aspectMode": "cover", "animated": True } ], "position": "absolute", "width": "25px", "height": "25px", "backgroundColor": "#000000", "cornerRadius": "50px", "offsetStart": "10px", "offsetTop": "4px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/2SprjX9/ezgif-com-gif-maker-29.png", "size": "full", "aspectRatio": "1:1", "aspectMode": "cover", "animated": True } ], "position": "absolute", "width": "25px", "height": "25px", "backgroundColor": "#000000", "cornerRadius": "50px", "offsetStart": "10px", "offsetBottom": "3.5px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "{}".format(cover), "size": "full", "aspectRatio": "1:1", "aspectMode": "cover" } ], "position": "absolute", "width": "34px", "height": "34px", "backgroundColor": "#000000", "offsetTop": "35px", "offsetStart": "3.5px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(cl.getContact(op.param2).displayName), "size": "12px", "color": "#ffffff", "align": "center", "offsetTop": "1px" } ], "position": "absolute", "width": "105px", "height": "20px", "backgroundColor": "#000000", "borderWidth": "1px", "borderColor": "#ff0000", "cornerRadius": "2px", "offsetTop": "2px", "offsetStart": "53px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "NOTIFED SIDER", "size": "12px", "color": "#ffffff", "align": "center", "offsetTop": "1px" } ], "position": "absolute", "width": "105px", "height": "20px", "backgroundColor": "#000000", "borderWidth": "1px", "borderColor": "#ff0000", "cornerRadius": "2px", "offsetStart": "53px", "offsetBottom": "1.5px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": wait["mention"], "size": "8px", "color": "#ffffff", "align": "center", "wrap": True } ], "position": "absolute", "width": "130px", "height": "40px", "backgroundColor": "#00000050", "borderWidth": "0.5px", "borderColor": "#ff0000", "cornerRadius": "2px", "offsetTop": "25px", "offsetStart": "55px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": " "+ datetime.strftime(timeNow,'%H:%M:%S'), "size": "8px", "color": "#ffffff", "align": "center", "offsetTop": "1px" } ], "position": "absolute", "width": "62px", "height": "14px", "backgroundColor": "#00000050", "borderWidth": "0.5px", "borderColor": "#ff0000", "cornerRadius": "2px", "offsetBottom": "23px", "offsetStart": "55px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": " "+ datetime.strftime(timeNow,'%Y-%m-%d'), "size": "8px", "color": "#ffffff", "align": "center", "offsetTop": "1px" } ], "position": "absolute", "width": "62px", "height": "14px", "backgroundColor": "#00000050", "borderWidth": "0.5px", "borderColor": "#ff0000", "cornerRadius": "2px", "offsetBottom": "23px", "offsetStart": "122px" }, { "type": "box", "layout": "verical", "contents": [ { "type": "text", "text": "TEAM TERMUX", "size": "12px", "color": "#ffffff", "align": "center", "offsetTop": "1px" } ], "position": "absolute", "width": "70px", "height": "20px", "backgroundColor": "#000000", "borderWidth": "0.5px", "borderColor": "#ff0000", "cornerRadius": "3px", "offsetBottom": "3px", "offsetEnd": "2px" } ], "paddingAll": "0px", "borderWidth": "1px", "borderColor": "#ff0000", "cornerRadius": "10px" }, "action": { "type": "uri", "label": "action", "uri": "line://nv/profilePopup/mid=u1094909befea4ff8d79d5f71d5356afb" } } }
                        data2 = {"type": "flex","altText": "TEAM TERMUX","contents":{ "type": "bubble", "size": "kilo", "body": { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/Vmjd5cc/ezgif-com-gif-maker-57.png", "size": "full", "aspectMode": "cover", "aspectRatio": "5:2", "animated": True }, { "type": "image", "url": "https://i.ibb.co/QCWsZnf/20220109-044116.png", "size": "full", "aspectRatio": "5:2", "aspectMode": "cover", "position": "absolute" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://obs.line-scdn.net/{}".format(cl.getContact(op.param2).pictureStatus), "size": "full", "aspectRatio": "1:1", "aspectMode": "cover" } ], "position": "absolute", "width": "55px", "height": "55px", "backgroundColor": "#000000", "offsetBottom": "14.5px", "offsetStart": "14.5px", "borderWidth": "0.5px", "borderColor": "#000000" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/vkXqNfB/ezgif-com-gif-maker-53.png", "size": "full", "aspectRatio": "1:1", "aspectMode": "cover", "animated": True } ], "position": "absolute", "width": "15px", "height": "15px", "cornerRadius": "50px", "offsetTop": "10px", "offsetStart": "145px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(cl.getContact(op.param2).displayName), "size": "10px", "color": "#ffffff", "align": "center" } ], "position": "absolute", "width": "125px", "height": "15px", "backgroundColor": "#00000070", "cornerRadius": "2px", "offsetTop": "10px", "offsetStart": "15px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": wait["mention"], "size": "10px", "color": "#ffffff", "wrap": True, "align": "center" } ], "position": "absolute", "width": "166px", "height": "38px", "backgroundColor": "#00000070", "cornerRadius": "2px", "offsetTop": "32px", "offsetEnd": "13px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": " "+datetime.strftime(timeNow,'%d-%m-%Y'), "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "3px" } ], "position": "absolute", "width": "50px", "height": "19px", "backgroundColor": "#00000070", "cornerRadius": "2px", "offsetBottom": "9px", "offsetEnd": "13px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": " "+datetime.strftime(timeNow,'%H:%M:%S'), "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "3px" } ], "position": "absolute", "width": "50px", "height": "19px", "backgroundColor": "#00000070", "cornerRadius": "2px", "offsetBottom": "9px", "offsetStart": "80px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "CCTV", "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "3px" } ], "position": "absolute", "width": "50px", "height": "19px", "backgroundColor": "#00000070", "cornerRadius": "2px", "offsetBottom": "9px", "offsetStart": "137px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/zWMVq1R/ezgif-com-gif-maker-54.png", "size": "full", "aspectRatio": "1:1", "aspectMode": "cover", "animated": True } ], "position": "absolute", "width": "15px", "height": "15px", "cornerRadius": "50px", "offsetTop": "11px", "offsetEnd": "13px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "• TEAM TERMUX •", "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "2px" } ], "position": "absolute", "width": "60px", "height": "19px", "backgroundColor": "#00000070", "cornerRadius": "2px", "offsetTop": "11px", "offsetEnd": "30px" } ], "paddingAll": "0px", "borderWidth": "1px", "borderColor": "#ffffff", "cornerRadius": "10px" }, "action": { "type": "uri", "label": "action", "uri": "line://nv/profilePopup/mid=u1094909befea4ff8d79d5f71d5356afb" } } }
                        mek = [data2, data1]
                        kon = random.choice(mek)
                        sid = str(wait["AddstickerSider"]["sid"])
                        spkg = str(wait["AddstickerSider"]["spkg"])
                        cx = threading.Thread(target=sendTemplate(op.param1, kon))
                        cx.start()
                        cx.join()
                        cl.sendSticker(op.param1, spkg, sid)                           
			
        if op.type == 26:
           if wait["selfbot"] == True:
               msg = op.message
               if msg._from not in Bots:
                 if wait["talkban"] == True:
                   if msg._from in wait["Talkblacklist"]:
                      try:
                          random.choice(ABC).kickoutFromGroup(msg.to, [msg._from])
                      except:
                          try:
                              cl.kickoutFromGroup(msg.to, [msg._from])
                          except:
                              cl.kickoutFromGroup(msg.to, [msg._from])
   
        if op.type == 25 or op.type == 26:
            try:
                print ("[ 25 ] SEND MESSAGE")
                msg = op.message
                text = msg.text
                msg_id = msg.id
                receiver = msg.to
                sender = msg._from
                to = msg.to
                if msg.toType == 0 or msg.toType == 1 or msg.toType == 2:
                    if msg.toType == 0:
                        if sender != cl.profile.mid:
                            to = sender
                        else:
                            to = receiver
                    elif msg.toType == 1:
                        to = receiver
                    elif msg.toType == 2:
                        to = receiver
                    if msg.contentType == 0:
                        if text is None:
                            return

            except:
                pass

        if op.type == 25 or op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            to = msg.to
            stickername = str(text)
            if msg.toType == 0 or msg.toType == 1 or msg.toType == 2:
               if msg.toType == 0:
                    to = receiver
               elif msg.toType == 2:
                    to = receiver         
               if msg.contentMetadata is not None  and 'MENTION' in msg.contentMetadata:
                 if wait["detectMention"] == True:
                   name = re.findall(r'@(\w+)', msg.text)
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention["M"] in clMID:
                           contact = cl.getContact(msg._from)
                           anu = contact.displayName
                           cl.sendReplyMessage(msg.to,id, anu)
                           sid = str(wait["AddstickerTag"]["sid"])
                           spkg = str(wait["AddstickerTag"]["spkg"])
                           cl.sendSticker(msg.to, spkg, sid)
                           break
                                                                                                    
               if msg.contentMetadata is not None  and 'MENTION' in msg.contentMetadata:
                 if wait["Mentionkick"] == True:
                   name = re.findall(r'@(\w+)', msg.text)
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in clMID:
                           cl.sendReplyMessage(msg.id,to, "Sorry Notag Active!!")
                           cl.kickoutFromGroup(msg.to, [msg._from])
                           break
                                                      
               if msg.contentMetadata is not None  and 'MENTION' in msg.contentMetadata:
                    if temptag["respontag"] == True:
                        name = re.findall(r'@(\w+)', msg.text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        for mention in mentionees:
                            if clMID in mention["M"]:                      	
                                contact = cl.getContact(sender)
                                cover = cl.getProfileCoverURL(sender)
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                data = {"type": "flex","altText": "TEAM TERMUX","contents": {"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/d0xpypN/20211220-072435.png","size": "full","aspectMode": "cover","aspectRatio": "5:8","gravity": "center"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(wait["Respontag"]),"size": "10px","color": "#ffffff","wrap": True,"align": "center"}],"position": "absolute","width": "143px","height": "50px","backgroundColor": "#ff000050","borderWidth": "1px","borderColor": "#ff0000","cornerRadius": "3px","offsetBottom": "31px","offsetStart": "5px"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://obs.line-scdn.net/{}".format(cl.getContact(sender).pictureStatus),"size": "full","aspectRatio": "1:1","aspectMode": "cover"}],"position": "absolute","width": "140px","height": "140px","borderWidth": "0.5px","borderColor": "#ff0000","cornerRadius": "5px","offsetTop": "31px","offsetStart": "10px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": " "+ datetime.strftime(timeNow,'%H:%M:%S'),"size": "7px","color": "#ffffff","align": "center"}],"position": "absolute","width": "60px","height": "10px","backgroundColor": "#ff000050","borderWidth": "0.5px","borderColor": "#ff0000","cornerRadius": "2px","offsetTop": "2px","offsetStart": "10px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Name : {}".format(cl.getContact(sender).displayName),"size": "7px","color": "#ffffff","align": "center"}],"position": "absolute","width": "113px","height": "10px","backgroundColor": "#ff000050","borderWidth": "0.5px","cornerRadius": "3px","offsetTop": "19px","offsetStart": "10px","borderColor": "#ff0000"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": " " + datetime.strftime(timeNow,'%d-%m-%Y'),"size": "7px","color": "#ffffff","align": "center"}],"position": "absolute","width": "60px","height": "10px","backgroundColor": "#ff000050","borderWidth": "0.5px","borderColor": "#ff0000","cornerRadius": "2px","offsetBottom": "3px","offsetEnd": "10px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "AUTO RESPON MENTION","size": "7px","color": "#ffffff","align": "center"}],"position": "absolute","width": "113px","height": "10px","backgroundColor": "#ff000050","borderWidth": "0.5px","cornerRadius": "3px","borderColor": "#ff0000","offsetBottom": "19px","offsetEnd": "10px"}],"paddingAll": "0px","borderWidth": "1px","borderColor": "#ff0000","cornerRadius": "10px"},"action": {"type": "uri","label": "action","uri": "line://nv/profilePopup/mid=u1094909befea4ff8d79d5f71d5356afb"}}}                            
                                rs = threading.Thread(target=sendTemplate(to, data))
                                rs.start()
                                rs.join()
                                sid = str(wait["AddstickerTag"]["sid"])
                                spkg = str(wait["AddstickerTag"]["spkg"])
                                cl.sendSticker(msg.to, spkg, sid)  
 
               if msg.contentType == 6:
                 if wait["responGc"] == True:
                     a = cl.getContact(sender)
                     if msg.toType == 2:
                         b = msg.contentMetadata['GC_EVT_TYPE']
                         c = msg.contentMetadata["GC_MEDIA_TYPE"]
                         tz = pytz.timezone("Asia/Jakarta")
                         timeNow = datetime.now(tz=tz)
                         contact = cl.getContact(sender)
                         cover = cl.getProfileCoverURL(sender)
                         gname = cl.getGroup(msg.to)
                         if c == "AUDIO" and b == "S":
                             data = {"type": "flex","altText": "TEAM TERMUX","contents": { "type": "bubble", "size": "micro", "body": { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/wyRnCDh/ezgif-com-gif-maker-47.png", "size": "full", "aspectMode": "cover", "aspectRatio": "1:1", "animated": True }, { "type": "image", "url": "https://i.ibb.co/SwZJ0Ch/20220108-060443.png", "position": "absolute", "size": "full", "aspectRatio": "1:1", "aspectMode": "cover" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/nLjjnZY/ezgif-com-gif-maker-49.png", "size": "full", "aspectRatio": "1:1", "aspectMode": "cover", "animated": True } ], "position": "absolute", "width": "25px", "height": "25px", "offsetTop": "3.3px", "offsetEnd": "3px", "cornerRadius": "1px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/6NsLJLY/ezgif-com-gif-maker-48.png", "size": "full", "aspectRatio": "1:1", "aspectMode": "cover", "animated": True } ], "position": "absolute", "width": "25px", "height": "25px", "cornerRadius": "1px", "offsetBottom": "3.3px", "offsetStart": "3px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://obs.line-scdn.net/{}".format(cl.getContact(sender).pictureStatus), "size": "full", "aspectRatio": "1:1", "aspectMode": "cover", "animated": True } ], "position": "absolute", "width": "51px", "height": "50.5px", "backgroundColor": "#000000", "offsetBottom": "23px", "offsetEnd": "3px", "cornerRadius": "1px", "borderWidth": "0.5px", "borderColor": "#000000" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "START CALL GROUP", "size": "10px", "color": "#00ff00", "align": "center", "offsetTop": "1px" } ], "position": "absolute", "width": "105px", "height": "15px", "cornerRadius": "1px", "offsetTop": "2px", "offsetStart": "12px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "❑ TEAM TERMUX ❑", "size": "10px", "color": "#00ff00", "align": "center" } ], "position": "absolute", "width": "105px", "height": "15px", "cornerRadius": "1px", "offsetBottom": "2px", "offsetEnd": "12px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "PICTURE", "size": "10px", "color": "#ffffff", "align": "center" } ], "position": "absolute", "width": "52px", "height": "15px", "cornerRadius": "1px", "offsetTop": "37px", "offsetEnd": "3px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "PROFILE", "size": "10px", "color": "#ffffff", "align": "center" } ], "position": "absolute", "width": "52px", "height": "15px", "cornerRadius": "1px", "offsetTop": "63px", "offsetEnd": "3px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(cl.getContact(sender).displayName), "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "0.5px" } ], "position": "absolute", "width": "90px", "height": "16.5px", "borderWidth": "0.5px", "borderColor": "#00ff00", "offsetTop": "26.5px", "offsetStart": "5px", "cornerRadius": "1px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": " "+datetime.strftime(timeNow,'%H:%M:%S'), "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "0.5px" } ], "position": "absolute", "width": "90px", "height": "16.5px", "borderWidth": "0.5px", "borderColor": "#00ff00", "offsetTop": "51.5px", "offsetStart": "5px", "cornerRadius": "1px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": " "+datetime.strftime(timeNow,'%d-%m-%Y'), "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "0.5px" } ], "position": "absolute", "width": "90px", "height": "16.5px", "borderWidth": "0.5px", "borderColor": "#00ff00", "offsetTop": "77px", "offsetStart": "5px", "cornerRadius": "1px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "TIPE : AUDIO", "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "0.5px" } ], "position": "absolute", "width": "90px", "height": "16.5px", "borderWidth": "0.5px", "borderColor": "#00ff00", "offsetTop": "103px", "offsetStart": "5px", "cornerRadius": "1px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(str(gname.name)), "size": "7px", "color": "#00ff00", "align": "center", "offsetTop": "4px" } ], "position": "absolute", "width": "60px", "height": "15px", "cornerRadius": "1px", "offsetBottom": "21px", "offsetStart": "36px" } ], "paddingAll": "0px", "borderWidth": "1px", "borderColor": "#00ff00", "cornerRadius": "10px" }, "action": { "type": "uri", "label": "action", "uri": "line://nv/profilePopup/mid=u1094909befea4ff8d79d5f71d5356afb" } } }
                             sid = threading.Thread(target=sendTemplate(to, data))
                             sid.start()
                             sid.join()
                             if wait["call"] == True:
                                 cl.sendMention(sender,"@!\n"+wait["callText"],'',[sender])
                         if c == "VIDEO" and b == "S":
                             data = {"type": "flex","altText": "TEAM TERMUX","contents": { "type": "bubble", "size": "micro", "body": { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/wyRnCDh/ezgif-com-gif-maker-47.png", "size": "full", "aspectMode": "cover", "aspectRatio": "1:1", "animated": True }, { "type": "image", "url": "https://i.ibb.co/SwZJ0Ch/20220108-060443.png", "position": "absolute", "size": "full", "aspectRatio": "1:1", "aspectMode": "cover" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/nLjjnZY/ezgif-com-gif-maker-49.png", "size": "full", "aspectRatio": "1:1", "aspectMode": "cover", "animated": True } ], "position": "absolute", "width": "25px", "height": "25px", "offsetTop": "3.3px", "offsetEnd": "3px", "cornerRadius": "1px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/6NsLJLY/ezgif-com-gif-maker-48.png", "size": "full", "aspectRatio": "1:1", "aspectMode": "cover", "animated": True } ], "position": "absolute", "width": "25px", "height": "25px", "cornerRadius": "1px", "offsetBottom": "3.3px", "offsetStart": "3px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://obs.line-scdn.net/{}".format(cl.getContact(sender).pictureStatus), "size": "full", "aspectRatio": "1:1", "aspectMode": "cover", "animated": True } ], "position": "absolute", "width": "51px", "height": "50.5px", "backgroundColor": "#000000", "offsetBottom": "23px", "offsetEnd": "3px", "cornerRadius": "1px", "borderWidth": "0.5px", "borderColor": "#000000" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "START CALL GROUP", "size": "10px", "color": "#00ff00", "align": "center", "offsetTop": "1px" } ], "position": "absolute", "width": "105px", "height": "15px", "cornerRadius": "1px", "offsetTop": "2px", "offsetStart": "12px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "❑ TEAM TERMUX ❑", "size": "10px", "color": "#00ff00", "align": "center" } ], "position": "absolute", "width": "105px", "height": "15px", "cornerRadius": "1px", "offsetBottom": "2px", "offsetEnd": "12px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "PICTURE", "size": "10px", "color": "#ffffff", "align": "center" } ], "position": "absolute", "width": "52px", "height": "15px", "cornerRadius": "1px", "offsetTop": "37px", "offsetEnd": "3px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "PROFILE", "size": "10px", "color": "#ffffff", "align": "center" } ], "position": "absolute", "width": "52px", "height": "15px", "cornerRadius": "1px", "offsetTop": "63px", "offsetEnd": "3px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(cl.getContact(sender).displayName), "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "0.5px" } ], "position": "absolute", "width": "90px", "height": "16.5px", "borderWidth": "0.5px", "borderColor": "#00ff00", "offsetTop": "26.5px", "offsetStart": "5px", "cornerRadius": "1px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": " "+datetime.strftime(timeNow,'%H:%M:%S'), "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "0.5px" } ], "position": "absolute", "width": "90px", "height": "16.5px", "borderWidth": "0.5px", "borderColor": "#00ff00", "offsetTop": "51.5px", "offsetStart": "5px", "cornerRadius": "1px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": " "+datetime.strftime(timeNow,'%d-%m-%Y'), "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "0.5px" } ], "position": "absolute", "width": "90px", "height": "16.5px", "borderWidth": "0.5px", "borderColor": "#00ff00", "offsetTop": "77px", "offsetStart": "5px", "cornerRadius": "1px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "TIPE : VIDEO", "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "0.5px" } ], "position": "absolute", "width": "90px", "height": "16.5px", "borderWidth": "0.5px", "borderColor": "#00ff00", "offsetTop": "103px", "offsetStart": "5px", "cornerRadius": "1px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(str(gname.name)), "size": "7px", "color": "#00ff00", "align": "center", "offsetTop": "4px" } ], "position": "absolute", "width": "60px", "height": "15px", "cornerRadius": "1px", "offsetBottom": "21px", "offsetStart": "36px" } ], "paddingAll": "0px", "borderWidth": "1px", "borderColor": "#00ff00", "cornerRadius": "10px" }, "action": { "type": "uri", "label": "action", "uri": "line://nv/profilePopup/mid=u1094909befea4ff8d79d5f71d5356afb" } } }
                             sid1 = threading.Thread(target=sendTemplate(to, data))
                             sid1.start()
                             sid1.join()
                             if wait["call"] == True:
                                 cl.sendMention(sender,"@!\n"+wait["callText"],'',[sender])
                         if c == "LIVE" and b == "S":
                             data = {"type": "flex","altText": "TEAM TERMUX","contents": { "type": "bubble", "size": "micro", "body": { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/wyRnCDh/ezgif-com-gif-maker-47.png", "size": "full", "aspectMode": "cover", "aspectRatio": "1:1", "animated": True }, { "type": "image", "url": "https://i.ibb.co/SwZJ0Ch/20220108-060443.png", "position": "absolute", "size": "full", "aspectRatio": "1:1", "aspectMode": "cover" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/nLjjnZY/ezgif-com-gif-maker-49.png", "size": "full", "aspectRatio": "1:1", "aspectMode": "cover", "animated": True } ], "position": "absolute", "width": "25px", "height": "25px", "offsetTop": "3.3px", "offsetEnd": "3px", "cornerRadius": "1px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/6NsLJLY/ezgif-com-gif-maker-48.png", "size": "full", "aspectRatio": "1:1", "aspectMode": "cover", "animated": True } ], "position": "absolute", "width": "25px", "height": "25px", "cornerRadius": "1px", "offsetBottom": "3.3px", "offsetStart": "3px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://obs.line-scdn.net/{}".format(cl.getContact(sender).pictureStatus), "size": "full", "aspectRatio": "1:1", "aspectMode": "cover", "animated": True } ], "position": "absolute", "width": "51px", "height": "50.5px", "backgroundColor": "#000000", "offsetBottom": "23px", "offsetEnd": "3px", "cornerRadius": "1px", "borderWidth": "0.5px", "borderColor": "#000000" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "START CALL GROUP", "size": "10px", "color": "#00ff00", "align": "center", "offsetTop": "1px" } ], "position": "absolute", "width": "105px", "height": "15px", "cornerRadius": "1px", "offsetTop": "2px", "offsetStart": "12px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "❑ TEAM TERMUX ❑", "size": "10px", "color": "#00ff00", "align": "center" } ], "position": "absolute", "width": "105px", "height": "15px", "cornerRadius": "1px", "offsetBottom": "2px", "offsetEnd": "12px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "PICTURE", "size": "10px", "color": "#ffffff", "align": "center" } ], "position": "absolute", "width": "52px", "height": "15px", "cornerRadius": "1px", "offsetTop": "37px", "offsetEnd": "3px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "PROFILE", "size": "10px", "color": "#ffffff", "align": "center" } ], "position": "absolute", "width": "52px", "height": "15px", "cornerRadius": "1px", "offsetTop": "63px", "offsetEnd": "3px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(cl.getContact(sender).displayName), "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "0.5px" } ], "position": "absolute", "width": "90px", "height": "16.5px", "borderWidth": "0.5px", "borderColor": "#00ff00", "offsetTop": "26.5px", "offsetStart": "5px", "cornerRadius": "1px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": " "+datetime.strftime(timeNow,'%H:%M:%S'), "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "0.5px" } ], "position": "absolute", "width": "90px", "height": "16.5px", "borderWidth": "0.5px", "borderColor": "#00ff00", "offsetTop": "51.5px", "offsetStart": "5px", "cornerRadius": "1px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": " "+datetime.strftime(timeNow,'%d-%m-%Y'), "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "0.5px" } ], "position": "absolute", "width": "90px", "height": "16.5px", "borderWidth": "0.5px", "borderColor": "#00ff00", "offsetTop": "77px", "offsetStart": "5px", "cornerRadius": "1px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "TIPE : LIVE", "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "0.5px" } ], "position": "absolute", "width": "90px", "height": "16.5px", "borderWidth": "0.5px", "borderColor": "#00ff00", "offsetTop": "103px", "offsetStart": "5px", "cornerRadius": "1px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(str(gname.name)), "size": "7px", "color": "#00ff00", "align": "center", "offsetTop": "4px" } ], "position": "absolute", "width": "60px", "height": "15px", "cornerRadius": "1px", "offsetBottom": "21px", "offsetStart": "36px" } ], "paddingAll": "0px", "borderWidth": "1px", "borderColor": "#00ff00", "cornerRadius": "10px" }, "action": { "type": "uri", "label": "action", "uri": "line://nv/profilePopup/mid=u1094909befea4ff8d79d5f71d5356afb" } } }
                             sid2 = threading.Thread(target=sendTemplate(to, data))
                             sid2.start()
                             sid2.join()
                             if wait["call"] == True:
                                 cl.sendMention(sender,"@!\n"+wait["callText"],'',[sender])
                         else:
                             mills = int(msg.contentMetadata["DURATION"])
                             if c == "AUDIO" and b == "E":
                                 data = {"type": "flex","altText": "TEAM TERMUX","contents": { "type": "bubble", "size": "micro", "body": { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/qDqVXFt/ezgif-com-gif-maker-50.png", "size": "full", "aspectMode": "cover", "aspectRatio": "1:1", "animated": True }, { "type": "image", "url": "https://i.ibb.co/nwJbQJY/20220108-115815.png", "position": "absolute", "size": "full", "aspectRatio": "1:1", "aspectMode": "cover" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://obs.line-scdn.net/{}".format(cl.getContact(sender).pictureStatus), "size": "full", "aspectRatio": "1:1", "aspectMode": "cover" } ], "position": "absolute", "width": "50px", "height": "50px", "backgroundColor": "#000000", "offsetTop": "27.5px", "offsetStart": "10px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "{}".format(cover), "size": "full", "aspectRatio": "1:1", "aspectMode": "cover" } ], "position": "absolute", "width": "50px", "height": "50px", "backgroundColor": "#000000", "offsetBottom": "28px", "offsetEnd": "10.5px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/NrD8ph4/ezgif-com-gif-maker-51.png", "size": "full", "aspectRatio": "1:1", "aspectMode": "cover", "animated": True } ], "position": "absolute", "width": "18px", "height": "18px", "backgroundColor": "#000000", "cornerRadius": "50px", "offsetTop": "4.5px", "offsetEnd": "18px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/NrD8ph4/ezgif-com-gif-maker-51.png", "size": "full", "aspectRatio": "1:1", "aspectMode": "cover", "animated": True } ], "position": "absolute", "width": "18px", "height": "18px", "backgroundColor": "#000000", "cornerRadius": "50px", "offsetBottom": "4px", "offsetStart": "16px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "NOTIFE END CALL", "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "1px" } ], "position": "absolute", "width": "107px", "height": "15px", "offsetTop": "5px", "offsetEnd": "45px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "TEAM TERMUX", "size": "10px", "color": "#ffffff", "align": "center", "offsetBottom": "1px" } ], "position": "absolute", "width": "107px", "height": "15px", "offsetBottom": "5px", "offsetStart": "45px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(cl.getContact(sender).displayName), "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "0.5px" } ], "position": "absolute", "width": "80px", "height": "17px", "borderWidth": "0.5px", "borderColor": "#ff0000", "cornerRadius": "1px", "offsetTop": "30px", "offsetEnd": "10px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(str(gname.name)), "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "0.5px" } ], "position": "absolute", "width": "80px", "height": "17px", "borderWidth": "0.5px", "borderColor": "#ff0000", "cornerRadius": "1px", "offsetTop": "55px", "offsetEnd": "10px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": " "+datetime.strftime(timeNow,'%Y-%m-%d'), "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "0.5px" } ], "position": "absolute", "width": "80px", "height": "17px", "borderWidth": "0.5px", "borderColor": "#ff0000", "cornerRadius": "1px", "offsetBottom": "30px", "offsetStart": "10px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": " "+datetime.strftime(timeNow,'%H:%M:%S'), "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "0.5px" } ], "position": "absolute", "width": "80px", "height": "17px", "borderWidth": "0.5px", "borderColor": "#ff0000", "cornerRadius": "1px", "offsetBottom": "55px", "offsetStart": "10px" } ], "paddingAll": "0px", "borderWidth": "1px", "borderColor": "#ff0000", "cornerRadius": "10px" }, "action": { "type": "uri", "label": "action", "uri": "line://nv/profilePopup/mid=u1094909befea4ff8d79d5f71d5356afb" } } }
                                 sad = threading.Thread(target=sendTemplate(to, data))
                                 sad.start()
                                 sad.join()
                             if c == "VIDEO" and b == "E":
                                 data = {"type": "flex","altText": "TEAM TERMUX","contents": { "type": "bubble", "size": "micro", "body": { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/qDqVXFt/ezgif-com-gif-maker-50.png", "size": "full", "aspectMode": "cover", "aspectRatio": "1:1", "animated": True }, { "type": "image", "url": "https://i.ibb.co/nwJbQJY/20220108-115815.png", "position": "absolute", "size": "full", "aspectRatio": "1:1", "aspectMode": "cover" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://obs.line-scdn.net/{}".format(cl.getContact(sender).pictureStatus), "size": "full", "aspectRatio": "1:1", "aspectMode": "cover" } ], "position": "absolute", "width": "50px", "height": "50px", "backgroundColor": "#000000", "offsetTop": "27.5px", "offsetStart": "10px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "{}".format(cover), "size": "full", "aspectRatio": "1:1", "aspectMode": "cover" } ], "position": "absolute", "width": "50px", "height": "50px", "backgroundColor": "#000000", "offsetBottom": "28px", "offsetEnd": "10.5px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/NrD8ph4/ezgif-com-gif-maker-51.png", "size": "full", "aspectRatio": "1:1", "aspectMode": "cover", "animated": True } ], "position": "absolute", "width": "18px", "height": "18px", "backgroundColor": "#000000", "cornerRadius": "50px", "offsetTop": "4.5px", "offsetEnd": "18px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/NrD8ph4/ezgif-com-gif-maker-51.png", "size": "full", "aspectRatio": "1:1", "aspectMode": "cover", "animated": True } ], "position": "absolute", "width": "18px", "height": "18px", "backgroundColor": "#000000", "cornerRadius": "50px", "offsetBottom": "4px", "offsetStart": "16px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "NOTIFE END CALL", "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "1px" } ], "position": "absolute", "width": "107px", "height": "15px", "offsetTop": "5px", "offsetEnd": "45px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "TEAM TERMUX", "size": "10px", "color": "#ffffff", "align": "center", "offsetBottom": "1px" } ], "position": "absolute", "width": "107px", "height": "15px", "offsetBottom": "5px", "offsetStart": "45px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(cl.getContact(sender).displayName), "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "0.5px" } ], "position": "absolute", "width": "80px", "height": "17px", "borderWidth": "0.5px", "borderColor": "#ff0000", "cornerRadius": "1px", "offsetTop": "30px", "offsetEnd": "10px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(str(gname.name)), "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "0.5px" } ], "position": "absolute", "width": "80px", "height": "17px", "borderWidth": "0.5px", "borderColor": "#ff0000", "cornerRadius": "1px", "offsetTop": "55px", "offsetEnd": "10px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": " "+datetime.strftime(timeNow,'%Y-%m-%d'), "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "0.5px" } ], "position": "absolute", "width": "80px", "height": "17px", "borderWidth": "0.5px", "borderColor": "#ff0000", "cornerRadius": "1px", "offsetBottom": "30px", "offsetStart": "10px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": " "+datetime.strftime(timeNow,'%H:%M:%S'), "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "0.5px" } ], "position": "absolute", "width": "80px", "height": "17px", "borderWidth": "0.5px", "borderColor": "#ff0000", "cornerRadius": "1px", "offsetBottom": "55px", "offsetStart": "10px" } ], "paddingAll": "0px", "borderWidth": "1px", "borderColor": "#ff0000", "cornerRadius": "10px" }, "action": { "type": "uri", "label": "action", "uri": "line://nv/profilePopup/mid=u1094909befea4ff8d79d5f71d5356afb" } } }
                                 sad1 = threading.Thread(target=sendTemplate(to, data))
                                 sad1.start()
                                 sad1.join()
                             if c == "LIVE" and b == "E":
                                 data = {"type": "flex","altText": "TEAM TERMUX","contents": { "type": "bubble", "size": "micro", "body": { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/qDqVXFt/ezgif-com-gif-maker-50.png", "size": "full", "aspectMode": "cover", "aspectRatio": "1:1", "animated": True }, { "type": "image", "url": "https://i.ibb.co/nwJbQJY/20220108-115815.png", "position": "absolute", "size": "full", "aspectRatio": "1:1", "aspectMode": "cover" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://obs.line-scdn.net/{}".format(cl.getContact(sender).pictureStatus), "size": "full", "aspectRatio": "1:1", "aspectMode": "cover" } ], "position": "absolute", "width": "50px", "height": "50px", "backgroundColor": "#000000", "offsetTop": "27.5px", "offsetStart": "10px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "{}".format(cover), "size": "full", "aspectRatio": "1:1", "aspectMode": "cover" } ], "position": "absolute", "width": "50px", "height": "50px", "backgroundColor": "#000000", "offsetBottom": "28px", "offsetEnd": "10.5px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/NrD8ph4/ezgif-com-gif-maker-51.png", "size": "full", "aspectRatio": "1:1", "aspectMode": "cover", "animated": True } ], "position": "absolute", "width": "18px", "height": "18px", "backgroundColor": "#000000", "cornerRadius": "50px", "offsetTop": "4.5px", "offsetEnd": "18px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/NrD8ph4/ezgif-com-gif-maker-51.png", "size": "full", "aspectRatio": "1:1", "aspectMode": "cover", "animated": True } ], "position": "absolute", "width": "18px", "height": "18px", "backgroundColor": "#000000", "cornerRadius": "50px", "offsetBottom": "4px", "offsetStart": "16px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "NOTIFE END CALL", "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "1px" } ], "position": "absolute", "width": "107px", "height": "15px", "offsetTop": "5px", "offsetEnd": "45px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "TEAM TERMUX", "size": "10px", "color": "#ffffff", "align": "center", "offsetBottom": "1px" } ], "position": "absolute", "width": "107px", "height": "15px", "offsetBottom": "5px", "offsetStart": "45px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(cl.getContact(sender).displayName), "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "0.5px" } ], "position": "absolute", "width": "80px", "height": "17px", "borderWidth": "0.5px", "borderColor": "#ff0000", "cornerRadius": "1px", "offsetTop": "30px", "offsetEnd": "10px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(str(gname.name)), "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "0.5px" } ], "position": "absolute", "width": "80px", "height": "17px", "borderWidth": "0.5px", "borderColor": "#ff0000", "cornerRadius": "1px", "offsetTop": "55px", "offsetEnd": "10px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": " "+datetime.strftime(timeNow,'%Y-%m-%d'), "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "0.5px" } ], "position": "absolute", "width": "80px", "height": "17px", "borderWidth": "0.5px", "borderColor": "#ff0000", "cornerRadius": "1px", "offsetBottom": "30px", "offsetStart": "10px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": " "+datetime.strftime(timeNow,'%H:%M:%S'), "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "0.5px" } ], "position": "absolute", "width": "80px", "height": "17px", "borderWidth": "0.5px", "borderColor": "#ff0000", "cornerRadius": "1px", "offsetBottom": "55px", "offsetStart": "10px" } ], "paddingAll": "0px", "borderWidth": "1px", "borderColor": "#ff0000", "cornerRadius": "10px" }, "action": { "type": "uri", "label": "action", "uri": "line://nv/profilePopup/mid=u1094909befea4ff8d79d5f71d5356afb" } } }
                                 sad2 = threading.Thread(target=sendTemplate(to, data))
                                 sad2.start()
                                 sad2.join()

               if msg.contentType == 7:
                 if wait["stickerOn"] == True:
                    msg.contentType = 0
                    sendFoter(msg.to,"╭─「 Cek ID Sticker 」\n├↘ STKID : " + msg.contentMetadata["STKID"] + "\n├↘ STKPKGID : " + msg.contentMetadata["STKPKGID"] + "\n├↘ STKVER : " + msg.contentMetadata["STKVER"]+ "\n├↘\n╰─「Link Sticker」" + "\nline://shop/detail/" + msg.contentMetadata["STKPKGID"])
               if msg.contentType == 13:
                 if wait["contact"] == True:
                    msg.contentType = 0
                    cl.sendMessage(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = cl.getContact(msg.contentMetadata["mid"])
                        path = cl.getContact(msg.contentMetadata["mid"]).picturePath
                        image = 'http://dl.profile.line.naver.jp'+path
                        sendFoter(msg.to,"╭─「 Contact Info 」\n├↘ Nama : " + msg.contentMetadata["displayName"] + "\n├↘ MID : " + msg.contentMetadata["mid"] + "\n├↘ Status Msg : " + contact.statusMessage + "\n├↘ Picture URL : http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                        cl.sendImageWithURL(msg.to, image)

        if op.type == 25 or op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            to = msg.to
            stickername = str(text)
            if msg.toType == 0 or msg.toType == 2:
               if msg.toType == 0:
                    to = receiver
               elif msg.toType == 2:
                    to = receiver
               if msg.contentType == 16:
                    if wait["Timeline"] == True:
                            ret_ = "「 Detail Postingan 」"
                            if msg.contentMetadata["serviceType"] == "GB":
                                contact = cl.getContact(sender)
                                auth = "\n• Penulis : {}".format(str(contact.displayName))
                            else:
                                auth = "\n• Penulis : {}".format(str(msg.contentMetadata["serviceName"]))
                            ret_ += auth
                            if "stickerId" in msg.contentMetadata:
                                stck = "\n• Stiker : https://line.me/R/shop/detail/{}".format(str(msg.contentMetadata["packageId"]))
                                ret_ += stck
                            if "mediaOid" in msg.contentMetadata:
                                object_ = msg.contentMetadata["mediaOid"].replace("svc=myhome|sid=h|","")
                                if msg.contentMetadata["mediaType"] == "V":
                                    if msg.contentMetadata["serviceType"] == "GB":
                                        ourl = "\n• Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(msg.contentMetadata["mediaOid"]))
                                        murl = "\n• Media URL : https://obs-us.line-apps.com/myhome/h/download.nhn?{}".format(str(msg.contentMetadata["mediaOid"]))
                                    else:
                                        ourl = "\n• Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(object_))
                                        murl = "\n• Media URL : https://obs-us.line-apps.com/myhome/h/download.nhn?{}".format(str(object_))
                                    ret_ += murl
                                else:
                                    if msg.contentMetadata["serviceType"] == "GB":
                                        ourl = "\n• Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(msg.contentMetadata["mediaOid"]))
                                    else:
                                        ourl = "\n• Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(object_))
                                ret_ += ourl
                            if "text" in msg.contentMetadata:
                                text = "\n• Tulisan : {}".format(str(msg.contentMetadata["text"]))
                                purl = "\n• Post URL : {}".format(str(msg.contentMetadata["postEndUrl"]).replace("line://","https://line.me/R/"))
                                ret_ += purl
                                ret_ += text
                            sendFoter(to, str(ret_))

               if msg.contentType == 16:
                    if wait["likeOn"] == True:
                        url = msg.contentMetadata["postEndUrl"]
                        cl.likePost(url[25:58], url[66:], likeType = 1001)
                        cl.createComment(url[25:58], url[66:], wait["comment"])
                        flexvian(msg.to, "Auto Like Succes ♪")
                        
               if msg.contentType == 7:
                 if msg._from in admin:
                    if wait["AddstickerTag"]["status"] == True:
                        wait["AddstickerTag"]["sid"] = msg.contentMetadata['STKID']
                        wait["AddstickerTag"]["spkg"] = msg.contentMetadata['STKPKGID']
                        flexvian(msg.to, "Add Stickers Tag Succes ♪")
                        wait["AddstickerTag"]["status"] = False     
               if msg.contentType == 7:
                 if msg._from in admin:
                    if wait["AddstickerSider"]["status"] == True:
                        wait["AddstickerSider"]["sid"] = msg.contentMetadata['STKID']
                        wait["AddstickerSider"]["spkg"] = msg.contentMetadata['STKPKGID']
                        flexvian(msg.to, "Add stickers sider ♪")
                        wait["AddstickerSider"]["status"] = False                   
               if msg.contentType == 7:
                 if msg._from in admin:
                    if wait["AddstickerPesan"]["status"] == True:
                        wait["AddstickerPesan"]["sid"] = msg.contentMetadata['STKID']
                        wait["AddstickerPesan"]["spkg"] = msg.contentMetadata['STKPKGID']
                        flexvian(msg.to, "Succes add Stickers ♪")
                        wait["AddstickerPesan"]["status"] = False                   
               if msg.contentType == 7:
                 if msg._from in admin:
                    if wait["AddstickerWelcome"]["status"] == True:
                        wait["AddstickerWelcome"]["sid"] = msg.contentMetadata['STKID']
                        wait["AddstickerWelcome"]["spkg"] = msg.contentMetadata['STKPKGID']
                        flexvian(msg.to, "Succes add Stickers ♪")
                        wait["AddstickerWelcome"]["status"] = False                   
               if msg.contentType == 7:
                 if msg._from in admin:
                    if wait["AddstickerLeave"]["status"] == True:
                        wait["AddstickerLeave"]["sid"] = msg.contentMetadata['STKID']
                        wait["AddstickerLeave"]["spkg"] = msg.contentMetadata['STKPKGID']
                        flexvian(msg.to, "Succes add Stickers Leave ♪")
                        wait["AddstickerLeave"]["status"] = False                   
               if msg.contentType == 0:
                    msg_dict[msg.id] = {"text":msg.text,"from":msg._from,"createdTime":msg.createdTime}
               if msg.contentType == 1:
                    path = cl.downloadObjectMsg(msg_id)
                    msg_dict[msg.id] = {"text":'Gambarnya dibawah',"data":path,"from":msg._from,"createdTime":msg.createdTime}
               if msg.contentType == 7:
                   stk_id = msg.contentMetadata["STKID"]
                   stk_ver = msg.contentMetadata["STKVER"]
                   pkg_id = msg.contentMetadata["STKPKGID"]
                   ret_ = "\n\n「 Sticker Info 」"
                   ret_ += "\n• Sticker ID : {}".format(stk_id)
                   ret_ += "\n• Sticker Version : {}".format(stk_ver)
                   ret_ += "\n• Sticker Package : {}".format(pkg_id)
                   ret_ += "\n• Sticker Url : line://shop/detail/{}".format(pkg_id)
                   query = int(stk_id)
                   if type(query) == int:
                            data = 'https://stickershop.line-scdn.net/stickershop/v1/sticker/'+str(query)+'/ANDROID/sticker.png'
                            path = cl.downloadFileURL(data)
                            msg_dict1[msg.id] = {"text":str(ret_),"data":path,"from":msg._from,"createdTime":msg.createdTime}
                            
               if msg.contentType == 7:
                   if msg._from in admin:
                       try:
                           if wait["sticker"] == True:
                               wait["stickers"][wait["stk"]] = msg.contentMetadata
                               wait["stk"] = {}
                               wait["sticker"] = False
                               f=codecs.open("wait.json","w","utf-8")
                               json.dump(wait, f, sort_keys=True, indent=4,ensure_ascii=False)
                               flexvian(msg.to,"Tersimpan")
                       except Exception as e:
                           sendFoter(msg.to,"{}".format(str(e)))
                       
               if msg.contentType == 7:
                 if wait["stickerOn"] == True:
                    msg.contentType = 0
                    sendFoter(msg.to,"╭─「 Cek ID Sticker 」\n├↘ STKID : " + msg.contentMetadata["STKID"] + "\n├↘ STKPKGID : " + msg.contentMetadata["STKPKGID"] + "\n├↘ STKVER : " + msg.contentMetadata["STKVER"]+ "\n├↘\n╰─「Link Sticker」" + "\nline://shop/detail/" + msg.contentMetadata["STKPKGID"])
               if msg.contentType == 13:
                 if wait["contact"] == True:
                    msg.contentType = 0
                    cl.sendMessage(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = cl.getContact(msg.contentMetadata["mid"])
                        path = cl.getContact(msg.contentMetadata["mid"]).picturePath
                        image = 'http://dl.profile.line.naver.jp'+path
                        sendFoter(msg.to," ╭─「 Contact Info 」\n├↘ Nama : " + msg.contentMetadata["displayName"] + "\n├↘ MID : " + msg.contentMetadata["mid"] + "\n├↘ Status Msg : " + contact.statusMessage + "\n╰─ 「Picture URL : http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                        cl.sendImageWithURL(msg.to, image)
#ADD Bots
               if msg.contentType == 13:
                 if msg._from in admin:
                  if wait["addbots"] == True:
                    if msg.contentMetadata["mid"] in Bots:
                        sendFoter(msg.to,"Sudah dalam daftar bot\nSilahkan ketik refresh")
                        wait["addbots"] = True
                    else:
                        Bots.append(msg.contentMetadata["mid"])
                        wait["addbots"] = True
                        sendFoter(msg.to,"Masuk dalam daftar bots\nSilahkan ketik refresh")
                 if wait["dellbots"] == True:
                    if msg.contentMetadata["mid"] in Bots:
                        Bots.remove(msg.contentMetadata["mid"])
                        sendFoter(msg.to,"Berhasil menghapus dari anggota bot\nSilahkan ketik refresh")
                    else:
                        wait["dellbots"] = True
                        sendFoter(msg.to,"Contact itu bukan anggota bot\nSilahkan ketik refresh")
#ADD STAFF
                 if msg._from in admin:
                  if wait["addstaff"] == True:
                    if msg.contentMetadata["mid"] in staff:
                        sendFoter(msg.to,"Contact itu sudah jadi staff\nSilahkan ketik refresh")
                        wait["addstaff"] = True
                    else:
                        staff.append(msg.contentMetadata["mid"])
                        wait["addstaff"] = True
                        sendFoter(msg.to,"Berhasil menambahkan ke staff\nSilahkan ketik refresh")
                 if wait["dellstaff"] == True:
                    if msg.contentMetadata["mid"] in staff:
                        staff.remove(msg.contentMetadata["mid"])
                        sendFoter(msg.to,"Berhasil menghapus dari staff\nSilahkan ketik refresh")
                        wait["dellstaff"] = True
                    else:
                        wait["dellstaff"] = True
                        sendFoter(msg.to,"Contact itu bukan staff\nSilahkan ketik refresh")
#ADD ADMIN
                 if msg._from in admin:
                  if wait["addadmin"] == True:
                    if msg.contentMetadata["mid"] in admin:
                        sendFoter(msg.to,"Contact itu sudah jadi admin\nSilahkan ketik refresh")
                        wait["addadmin"] = True
                    else:
                        admin.append(msg.contentMetadata["mid"])
                        wait["addadmin"] = True
                        sendFoter(msg.to,"Berhasil menambahkan ke admin\nSilahkan ketik refresh")
                 if wait["delladmin"] == True:
                    if msg.contentMetadata["mid"] in admin:
                        admin.remove(msg.contentMetadata["mid"])
                        sendFoter(msg.to,"Berhasil menghapus dari admin\nSilahkan ketik refresh")
                    else:
                        wait["delladmin"] = True
                        sendFoter(msg.to,"Contact itu bukan admin\nSilahkan ketik refresh")
#ADD BLACKLIST
                 if msg._from in admin:
                  if wait["wblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        sendFoter(msg.to,"Contact itu sudah ada di blacklist\nSilahkan ketik refresh")
                        wait["wblacklist"] = True
                    else:
                        wait["blacklist"][msg.contentMetadata["mid"]] = True
                        wait["wblacklist"] = True
                        sendFoter(msg.to,"Masuk daftar blacklist\nSilahkan ketik refresh")
                  if wait["dblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        del wait["blacklist"][msg.contentMetadata["mid"]]
                        sendFoter(msg.to,"Unbaned blacklist\nSilahkan ketik refresh")
                    else:
                        wait["dblacklist"] = True
                        sendFoter(msg.to,"Contact itu tidak ada di blacklist")
#TALKBAN
                 if msg._from in admin:
                  if wait["Talkwblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["Talkblacklist"]:
                        sendFoter(msg.to,"Contact itu sudah ada di Talkban\nSilahkan ketik refresh")
                        wait["Talkwblacklist"] = True
                    else:
                        wait["Talkblacklist"][msg.contentMetadata["mid"]] = True
                        wait["Talkwblacklist"] = True
                        sendFoter(msg.to,"Berhasil menambahkan ke Talkban user\nSilahkan ketik refresh")
                  if wait["Talkdblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["Talkblacklist"]:
                        del wait["Talkblacklist"][msg.contentMetadata["mid"]]
                        flex3(msg.to,"Berhasil menghapus dari Talkban user\nSilahkan ketik refresh")
                    else:
                        wait["Talkdblacklist"] = True
                        sendFoter(msg.to,"Contact itu tidak ada di Talkban\nSilahkan ketik refresh")
#UPDATE FOTO
               if msg.contentType == 1:
                if msg._from in admin:
                  if wait["Addimage"] == True:
                    try:
                        cl.downloadObjectMsg(msg.id,'path','dataFoto/'+wait["Img"]+'.jpg')
                        flexvian(msg.to, "Berhasil menambahkan gambar")
                        wait["Img"] = {}                
                        wait["Addimage"] = False
                    except Exception as e:
                        cl.downloadObjectMsg(msg.id,'path','dataFoto/'+wait["Img"]+'.jpg')
                        flexvian(msg.to, "Berhasil menambahkan gambar")
                        wait["Img"] = {}
                        wait["Addimage"] = False
               if msg.contentType == 2:
                if msg._from in admin:
                  if wait["Addvideo"] == True:
                    try:
                        cl.downloadObjectMsg(msg.id,'path','dataVideo/'+wait["Video"]+'.mp4')
                        flexvian(msg.to, "Berhasil menambahkan video")
                        wait["Video"] = {}                
                        wait["Addvideo"] = False
                    except Exception as e:
                        cl.downloadObjectMsg(msg.id,'path','dataVideo/'+wait["Video"]+'.mp4')
                        flexvian(msg.to, "Berhasil menambahkan video")
                        wait["Video"] = {}
                        wait["Addvideo"] = False
               if msg.toType == 2:
                 if msg._from in admin:
                   if settings["groupPicture"] == True:
                     path = cl.downloadObjectMsg(msg_id)
                     settings["groupPicture"] = False
                     cl.updateGroupPicture(msg.to, path)
                     flexvian(msg.to, "Success")
               if msg.contentType == 1:
                   if msg._from in admin:
                       if clMID in wait["changeFoto"]:
                            path = cl.downloadObjectMsg(msg_id)
                            del wait["changeFoto"][clMID]
                            cl.updateProfilePicture(path)
                            flexvian(msg.to,"Foto berhasil dirubah")
                   if msg._from in admin:
                       if clMID in settings["changeCover"]:
                            path = cl.downloadObjectMsg(msg_id)
                            del settings["changeCover"][clMID]
                            cl.updateProfileCover(path)
                            flexvian(to, "Updated")                                                            

               if msg.contentType == 0:
                    if Setmain["autoRead"] == True:
                        cl.sendChatChecked(msg.to, msg_id)
                    if text is None:
                        return
                    else:
                        cmd = command(text)
                        if cmd == "chatbot on":
                            if msg._from in admin:
                                wait["selfbot"] = True
                                ret = "Chatbot Enable."
                                flexvian(msg.to, str(ret))

                        elif cmd == comd["help"]:
                          if msg._from in admin:
                            contact = cl.getContact(sender)
                            name = contact.displayName
                            flexhelp(msg.to,"")
  
                        elif cmd == "menu":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                flexhelp2(msg.to,"")
                              
                        elif cmd == "chatbot off":
                            if msg._from in admin:
                                wait["selfbot"] = False
                                ret = "Chatbot Disable"
                                flexvian(msg.to, str(ret))

                        elif cmd == "clear":
                            if msg._from in admin:
                                #process = os.popen('cd /tmp/ && rm -r *')
                                process = os.popen('sync; echo 1 > /proc/sys/vm/drop_caches')
                                a = process.read()
                                ret = "Cleared a chace server"
                                flexvian(msg.to, str(ret))

                        elif cmd == "allowliff":
                            if msg._from in admin:
                                try:
                                    allowLiff()
                                    cl.sendMessage(msg.to, "Allow Template Succes")
                                except:
                                    cl.sendReplyMessage(msg.id,to,"Klick Link and Allow/Izinkan\nline://app/1602687308-GXq4Vvk9")
    
                        elif cmd == "remote":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                vian = open('file/remote.txt','r').read()
                                flex3(msg.to,vian)
    
                        elif cmd == "group":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                vian = open('file/group.txt','r').read()
                                flex3(msg.to,vian)

                        elif cmd == "profile":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                vian = open('file/profile.txt','r').read()
                                flex3(msg.to,vian)

                        elif cmd == "admin":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                vian = open('file/admin.txt','r').read()
                                flex3(msg.to,vian)

                        elif cmd == "banned":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                vian = open('file/banned.txt','r').read()
                                flex3(msg.to,vian)

                        elif cmd == "help js":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                vian = open('file/helpjs.txt','r').read()
                                flex3(msg.to,vian)

                        elif cmd == "setting":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                vian = open('file/setting.txt','r').read()
                                flex3(msg.to,vian)

                        elif cmd == "media":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                vian = open('file/media.txt','r').read()
                                flex3(msg.to,vian)

                        elif cmd == "protect":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                vian = open('file/protect.txt','r').read()
                                flex3(msg.to,vian)

                        elif cmd == "translate":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                vian = open('file/translate.txt','r').read()
                                flex3(msg.to,vian)

                        elif cmd == "cmd list":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                vian = "╭─「👥 Cmd List ??」\n"
                                for u in comd:
                                    vian += "├❑ {} : {}\n".format(u,comd[u])
                                vian += '╰────────'
                                flex3(msg.to, str(vian))
                                                         
                        elif cmd == "status":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                if wait["smulenotife"] == True: md1="𝚂𝙼𝚄𝙻𝙴 ⊷ ≼ ✓ ≽\n"
                                else: md1="𝚂𝙼𝚄𝙻𝙴 ⊷ ≼ ✗ ≽\n"
                                if wait["yt"] == True: md2="𝚈𝙾𝚄𝚃𝚄𝙱𝙴 ⊷ ≼ ✓ ≽\n"
                                else: md2="𝚈𝙾𝚄𝚃𝚄𝙱𝙴 ⊷ ≼ ✗ ≽\n"
                                if wait["tiktok"] == True: md3="𝚃𝙸𝙺𝚃𝙾𝙺 ⊷ ≼ ✓ ≽\n"
                                else: md3="𝚃𝙸𝙺𝚃𝙾𝙺 ⊷ ≼ ✗ ≽\n"
                                if wait["contact"] == True: md4="𝙲𝙾𝙽𝚃𝙰𝙲𝚃 ⊷ ≼ ✓ ≽\n"
                                else: md4="𝙲𝙾𝙽𝚃𝙰𝙲𝚃 ⊷ ≼ ✗ ≽\n"
                                if wait["unsend"] == True: md5="𝚄𝙽𝚂𝙴𝙽𝙳 ⊷ ≼ ✓ ≽\n"
                                else: md5="𝚄𝙽𝚂𝙴𝙽𝙳 ⊷ ≼ ✗ ≽\n"
                                if wait["Timeline"] == True: md6="𝚃𝙸𝙼𝙴𝙻𝙸𝙽𝙴 ⊷ ≼ ✓ ≽\n"
                                else: md6="𝚃𝙸𝙼𝙴𝙻𝙸𝙽𝙴 ⊷ ≼ ✗ ≽\n"
                                if temptag["stealtag"] == True: md7="𝚁𝙴𝚂𝙿𝙾𝙽 ⊷ ≼ ✓ ≽\n"
                                else: md7="𝚁𝙴𝚂𝙿𝙾𝙽 ⊷ ≼ ✗ ≽\n"
                                if wait["autoBlock"] == True: md8="𝙰𝚄𝚃??𝙱𝙻𝙾??𝙺 ⊷ ≼ ✓ ≽\n"
                                else: md8="𝙰𝚄𝚃𝙾𝙱??𝙾𝙲𝙺 ⊷ ≼ ✗ ≽\n"
                                if wait["talkban"] == True: md9="𝚃𝙰𝙻𝙺𝙱𝙰𝙽 ⊷ ≼ ✓ ≽\n"
                                else: md9="𝚃𝙰𝙻𝙺𝙱𝙰𝙽 ⊷ ≼ ✗ ≽\n"
                                if wait["Mentionkick"] == True: md10="𝙽𝙾𝚃𝙰𝙶 ⊷ ≼ ✓ ≽\n"
                                else: md10="𝙽𝙾𝚃𝙰𝙶 ⊷ ≼ ✗ ≽\n"
                                if wait["autoJoin"] == True: md12="𝙰𝚄𝚃𝙾𝙹𝙾𝙸𝙽 ⊷ ≼ ✓ ≽\n"
                                else: md12="𝙰𝚄𝚃𝙾𝙹𝙾𝙸𝙽 ⊷ ≼ ✗ ≽\n"
                                if wait["autoAdd"] == True: md13="𝙰𝚄𝚃𝙾𝙰𝙳𝙳 ⊷ ≼ ✓ ≽\n"
                                else: md13="𝙰𝚄𝚃𝙾𝙰𝙳𝙳 ⊷ ≼ ✗ ≽\n"
                                if wait["likeOn"] == True: md14="𝙰𝚄𝚃𝙾𝙻𝙸𝙺𝙴 ⊷ ≼ ✓ ≽\n"
                                else: md14="𝙰𝚄𝚃𝙾𝙻𝙸𝙺𝙴 ⊷ ≼ ✗ ≽\n"
                                if wait["responGc"] == True: md15="𝚁𝙴𝚂𝙿𝙾𝙽𝙲𝙰𝙻𝙻 ⊷ ≼ ✓ ≽\n"
                                else: md15="𝚁𝙴𝚂𝙿𝙾𝙽𝙲𝙰𝙻𝙻 ⊷ ≼ ✗ ≽\n"
                                if msg.to in welcome: md16="𝚆𝙴𝙻𝙲𝙾𝙼𝙴𝙼𝚂𝙶 ⊷ ≼ ✓ ≽\n"
                                else: md16="𝚆𝙴𝙻𝙲𝙾𝙼𝙴𝙼𝚂𝙶 ⊷ ≼ ✗ ≽\n"
                                if wait["autoLeave"] == True: md17="𝙰𝚄𝚃𝙾𝙻𝙴𝙰𝚅𝙴 ⊷ ≼ ✓ ≽\n"
                                else: md17="𝙰𝚄𝚃𝙾𝙻𝙴𝙰𝚅𝙴 ⊷ ≼ ✗ ≽\n"
                                if msg.to in leave: md18="𝙻𝙴𝙰𝚅𝙴𝙼𝚂𝙶 ⊷ ≼ ✓ ≽\n"
                                else: md18="𝙻𝙴𝙰𝚅𝙴𝙼𝚂𝙶 ⊷ ≼ ✗ ≽\n"
                                if msg.to in protectqr: md19="𝙿𝚁𝙾𝚀𝚁 ⊷ ≼ ✓ ≽\n"
                                else: md19="𝙿𝚁𝙾𝚀𝚁 ⊷ ≼ ✗ ≽\n"
                                if msg.to in protectjoin: md20="𝙿𝚁𝙾𝙹𝙾𝙸𝙽 ⊷ ≼ ✓ ≽\n"
                                else: md20="𝙿𝚁𝙾𝙹𝙾𝙸𝙽 ⊷ ≼ ✗ ≽\n"
                                if msg.to in protectkick: md21="𝙿𝚁𝙾𝙺𝙸𝙲𝙺 ⊷ ≼ ✓ ≽\n"
                                else: md21="𝙿𝚁𝙾??𝙸𝙲𝙺 ⊷ ≼ ✗ ≽\n"
                                if msg.to in protectcancel: md22="𝙿𝚁𝙾𝙲𝙰𝙽𝙲𝙴𝙻𝙻 ⊷ ≼ ✓ ≽\n"
                                else: md22="𝙿𝚁𝙾𝙲𝙰𝙽𝙲𝙴𝙻𝙻 ⊷ ≼ ✗ ≽\n"
                                if msg.to in protectinvite: md23="𝙿𝚁𝙾𝙸𝙽𝚅𝙸𝚃𝙴 ⊷ ≼ ✓ ≽"
                                else: md23="𝙿𝚁𝙾𝙸𝙽𝚅𝙸𝚃𝙴 ⊷ ≼ ✗ ≽"
                                KONTOL = {"type": "flex","altText": "TEAM TERMUX","contents":{"type": "bubble","size": "kilo","body": {"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/GMgqtDy/20211221-233731.png","size": "full","aspectMode": "cover","aspectRatio": "3:4"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/sygX9dY/ezgif-com-gif-maker-19.png","size": "full","aspectRatio": "1:1","aspectMode": "cover"}],"position": "absolute","width": "37px","height": "37px","backgroundColor": "#000000","offsetTop": "3px","offsetEnd": "7px","borderWidth": "1px"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/KbfDFN1/1657636839741.jpg","size": "full","aspectRatio": "1:1","aspectMode": "cover","animated": True}],"position": "absolute","width": "42px","height": "42px","backgroundColor": "#000000","offsetTop": "3.5px","offsetStart": "24px","cornerRadius": "50px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "𝚂𝚃𝙰𝚃𝚄𝚂 𝚂𝙴𝙻𝙵𝙱𝙾𝚃","size": "13px","color": "#00ff00","align": "center","offsetTop": "2px"}],"position": "absolute","width": "120px","height": "20px","backgroundColor": "#000000","borderWidth": "0.5px","borderColor": "#00ff00","cornerRadius": "2px","offsetTop": "6px","offsetEnd": "50px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Zulkifli","size": "11px","color": "#00ff00","align": "center","offsetTop": "3px"}],"position": "absolute","width": "120px","height": "20px","backgroundColor": "#000000","borderWidth": "0.5px","borderColor": "#00ff00","cornerRadius": "2px","offsetBottom": "4px","offsetStart": "10px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": " "+ datetime.strftime(timeNow,'%H:%M:%S'),"size": "12px","color": "#00ff00","align": "center","offsetTop": "2px"}],"position": "absolute","width": "84px","height": "20px","backgroundColor": "#000000","borderWidth": "0.5px","borderColor": "#00ff00","cornerRadius": "2px","offsetBottom": "4px","offsetEnd": "10px"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/9vDk6hj/ezgif-com-gif-maker-33.png","size": "full","aspectRatio": "1:2","aspectMode": "cover","animated": True}],"position": "absolute","width": "150px","height": "250px","offsetTop": "62px","offsetEnd": "14px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(md1),"size": "10px","color": "#ffffff","offsetStart": "5px","offsetTop": "1px"}],"position": "absolute","width": "110px","height": "15px","backgroundColor": "#00000050","borderWidth": "0.5px","borderColor": "#00ff00","cornerRadius": "2px","offsetTop": "50px","offsetStart": "15px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(md2),"size": "10px","color": "#ffffff","offsetStart": "5px","offsetTop": "1px"}],"position": "absolute","width": "110px","height": "15px","backgroundColor": "#00000050","borderWidth": "0.5px","borderColor": "#00ff00","cornerRadius": "2px","offsetTop": "74px","offsetStart": "15px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(md3),"size": "10px","color": "#ffffff","offsetStart": "5px","offsetTop": "1px"}],"position": "absolute","width": "110px","height": "15px","backgroundColor": "#00000050","borderWidth": "0.5px","borderColor": "#00ff00","cornerRadius": "2px","offsetTop": "99px","offsetStart": "15px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(md4),"size": "10px","color": "#ffffff","offsetStart": "5px","offsetTop": "1px"}],"position": "absolute","width": "110px","height": "15px","backgroundColor": "#00000050","borderWidth": "0.5px","borderColor": "#00ff00","cornerRadius": "2px","offsetTop": "124px","offsetStart": "15px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(md5),"size": "10px","color": "#ffffff","offsetStart": "5px","offsetTop": "1px"}],"position": "absolute","width": "110px","height": "15px","backgroundColor": "#00000050","borderWidth": "0.5px","borderColor": "#00ff00","cornerRadius": "2px","offsetTop": "149px","offsetStart": "15px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(md6),"size": "10px","color": "#ffffff","offsetStart": "5px","offsetTop": "1px"}],"position": "absolute","width": "110px","height": "15px","backgroundColor": "#00000050","borderWidth": "0.5px","borderColor": "#00ff00","cornerRadius": "2px","offsetTop": "174px","offsetStart": "15px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(md7),"size": "10px","color": "#ffffff","offsetStart": "5px","offsetTop": "1px"}],"position": "absolute","width": "110px","height": "15px","backgroundColor": "#00000050","borderWidth": "0.5px","borderColor": "#00ff00","cornerRadius": "2px","offsetTop": "199px","offsetStart": "15px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(md8),"size": "10px","color": "#ffffff","offsetStart": "5px","offsetTop": "1px"}],"position": "absolute","width": "110px","height": "15px","backgroundColor": "#00000050","borderWidth": "0.5px","borderColor": "#00ff00","cornerRadius": "2px","offsetTop": "224px","offsetStart": "15px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(md9),"size": "10px","color": "#ffffff","offsetStart": "5px","offsetTop": "1px"}],"position": "absolute","width": "110px","height": "15px","backgroundColor": "#00000050","borderWidth": "0.5px","borderColor": "#00ff00","cornerRadius": "2px","offsetTop": "249px","offsetStart": "15px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(md10),"size": "10px","color": "#ffffff","offsetStart": "5px","offsetTop": "1px"}],"position": "absolute","width": "110px","height": "15px","backgroundColor": "#00000050","borderWidth": "0.5px","borderColor": "#00ff00","cornerRadius": "2px","offsetTop": "274px","offsetStart": "15px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(md12),"size": "10px","color": "#ffffff","offsetStart": "5px","offsetTop": "1px"}],"position": "absolute","width": "110px","height": "16px","backgroundColor": "#00000050","borderWidth": "0.5px","borderColor": "#00ff00","cornerRadius": "2px","offsetTop": "298px","offsetStart": "15px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(md13),"size": "10px","color": "#ffffff","offsetStart": "5px","offsetTop": "1px"}],"position": "absolute","width": "110px","height": "15px","backgroundColor": "#00000050","borderWidth": "0.5px","borderColor": "#00ff00","cornerRadius": "2px","offsetTop": "50px","offsetEnd": "15px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(md14),"size": "10px","color": "#ffffff","offsetStart": "5px","offsetTop": "1px"}],"position": "absolute","width": "110px","height": "15px","backgroundColor": "#00000050","borderWidth": "0.5px","borderColor": "#00ff00","cornerRadius": "2px","offsetTop": "74px","offsetEnd": "15px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(md15),"size": "10px","color": "#ffffff","offsetStart": "5px","offsetTop": "1px"}],"position": "absolute","width": "110px","height": "15px","backgroundColor": "#00000050","borderWidth": "0.5px","borderColor": "#00ff00","cornerRadius": "2px","offsetTop": "99px","offsetEnd": "15px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(md16),"size": "9px","color": "#ffffff","offsetStart": "5px","offsetTop": "1px"}],"position": "absolute","width": "110px","height": "15px","backgroundColor": "#00000050","borderWidth": "0.5px","borderColor": "#00ff00","cornerRadius": "2px","offsetTop": "124px","offsetEnd": "15px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(md17),"size": "10px","color": "#ffffff","offsetStart": "5px","offsetTop": "1px"}],"position": "absolute","width": "110px","height": "15px","backgroundColor": "#00000050","borderWidth": "0.5px","borderColor": "#00ff00","cornerRadius": "2px","offsetTop": "149px","offsetEnd": "15px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(md18),"size": "10px","color": "#ffffff","offsetStart": "5px","offsetTop": "1px"}],"position": "absolute","width": "110px","height": "15px","backgroundColor": "#00000050","borderWidth": "0.5px","borderColor": "#00ff00","cornerRadius": "2px","offsetTop": "174px","offsetEnd": "15px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(md19),"size": "10px","color": "#ffffff","offsetStart": "5px","offsetTop": "1px"}],"position": "absolute","width": "110px","height": "15px","backgroundColor": "#00000050","borderWidth": "0.5px","borderColor": "#00ff00","cornerRadius": "2px","offsetTop": "199px","offsetEnd": "15px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(md20),"size": "10px","color": "#ffffff","offsetStart": "5px","offsetTop": "1px"}],"position": "absolute","width": "110px","height": "15px","backgroundColor": "#00000050","borderWidth": "0.5px","borderColor": "#00ff00","cornerRadius": "2px","offsetTop": "224px","offsetEnd": "15px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(md21),"size": "10px","color": "#ffffff","offsetStart": "5px","offsetTop": "1px"}],"position": "absolute","width": "110px","height": "15px","backgroundColor": "#00000050","borderWidth": "0.5px","borderColor": "#00ff00","cornerRadius": "2px","offsetTop": "249px","offsetEnd": "15px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(md22),"size": "9px","color": "#ffffff","offsetStart": "5px","offsetTop": "1px"}],"position": "absolute","width": "110px","height": "15px","backgroundColor": "#00000050","borderWidth": "0.5px","borderColor": "#00ff00","cornerRadius": "2px","offsetTop": "274px","offsetEnd": "15px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(md23),"size": "10px","color": "#ffffff","offsetStart": "5px","offsetTop": "1px"}],"position": "absolute","width": "110px","height": "15px","backgroundColor": "#00000050","borderWidth": "0.5px","borderColor": "#00ff00","cornerRadius": "2px","offsetTop": "299px","offsetEnd": "15px"}],"paddingAll": "0px","borderWidth": "1px","borderColor": "#00ff00","cornerRadius": "10px"},"action": {"type": "uri","label": "action","uri": "line://nv/profilePopup/mid=u1094909befea4ff8d79d5f71d5356afb"}}}
                                sendTemplate(to, KONTOL)
                                                                
                        elif cmd == "rejectall":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                ginvited = cl.getGroupIdsInvited()
                                if ginvited != [] and ginvited != None:
                                    for gid in ginvited:
                                        cl.rejectGroupInvitation(gid)
                                    flex2(to, "Rejected {} Group Invite".format(str(len(ginvited))))
                                else:
                                    flex2(to, "Nothing")
                                
                        elif cmd == "cancelall":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                    group = cl.getGroup(to)
                                    if group.invitee is None or group.invitee == []:
                                        flexvian(to, "Nothing")
                                    else:
                                        invitee = [contact.mid for contact in group.invitee]
                                        for inv in invitee:
                                            cl.cancelGroupInvitation(to, [inv])
                                        flex2(to, "Cancelled {} Group Pending".format(str(len(invitee))))
                                
                        elif cmd == "accept:all":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                    group = cl.getGroup(to)
                                    if group.invitee is None or group.invitee == []:
                                        flex2(to, "No Have Groups Invitation.")
                                    else:
                                        invitee = [contact.mid for contact in group.invitee]
                                        for acc in invitee:
                                            cl.acceptGroupInvitation(to, [acc])
                                        flex2(to, "Join {} Groups".format(str(len(invitee))))
                              
                        elif cmd == "logout":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                flexvian(msg.to, "Logout Success ♪")
                                sys.exit("Logout")
                              
                        elif cmd.startswith('about'):
                          if msg._from in admin:
                            try:
                                contact = cl.getContact(sender)
                                favoritelist = cl.getFavoriteMids()
                                grouplist = cl.getGroupIdsJoined()
                                contactlist = cl.getAllContactIds()
                                blockedlist = cl.getBlockedContactIds()
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                ALVIAN = { "type": "flex", "altText": "TEAM TERMUX", "contents": { "type": "bubble", "size": "micro", "body": { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/Vmqgzpy/ezgif-com-gif-maker-37.png", "size": "full", "aspectMode": "cover", "aspectRatio": "5:8" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/BrQBTwv/ezgif-com-gif-maker-34.png", "size": "full", "aspectRatio": "1:1", "animated": True } ], "position": "absolute", "width": "22px", "height": "22px", "backgroundColor": "#000000", "cornerRadius": "50px", "offsetTop": "1.5px", "offsetStart": "7.5px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/BrQBTwv/ezgif-com-gif-maker-34.png", "size": "full", "aspectRatio": "1:1", "animated": True } ], "position": "absolute", "width": "22px", "height": "22px", "backgroundColor": "#000000", "cornerRadius": "50px", "offsetBottom": "1.5px", "offsetEnd": "8px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "ABOUT SELFBOT", "size": "10px", "color": "#00ff00", "align": "center" } ], "position": "absolute", "width": "85px", "height": "14px", "backgroundColor": "#000000", "borderWidth": "0.5px", "borderColor": "#0000ff", "cornerRadius": "2px", "offsetTop": "9.5px", "offsetStart": "45px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "SELFBOT FLEX", "size": "10px", "color": "#00ff00", "align": "center" } ], "position": "absolute", "width": "85px", "height": "14px", "backgroundColor": "#000000", "borderWidth": "0.5px", "borderColor": "#0000ff", "cornerRadius": "2px", "offsetBottom": "9.5px", "offsetEnd": "45px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/0h5LZ4k/ezgif-com-gif-maker-33.png", "size": "full", "aspectRatio": "2:3", "aspectMode": "cover", "animated": True }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "DETAIL SELFBOTS", "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "2px" } ], "position": "absolute", "width": "140px", "height": "15px", "backgroundColor": "#0000ff" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Time", "size": "10px", "color": "#00ff00", "align": "center", "offsetTop": "3px" } ], "position": "absolute", "width": "50px", "height": "20px", "backgroundColor": "#00000095" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": " "+ datetime.strftime(timeNow,'%H:%M:%S'), "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "3px" } ], "position": "absolute", "width": "90px", "height": "20px", "backgroundColor": "#00000095", "offsetStart": "50px" } ], "position": "absolute", "width": "140px", "height": "20px", "offsetTop": "16px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Date", "size": "10px", "color": "#00ff00", "align": "center", "offsetTop": "3px" } ], "position": "absolute", "width": "50px", "height": "20px", "backgroundColor": "#00000095" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": " " + datetime.strftime(timeNow,'%d-%m-%Y'), "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "3px" } ], "position": "absolute", "width": "90px", "height": "20px", "backgroundColor": "#00000095", "offsetStart": "50px" } ], "position": "absolute", "width": "140px", "height": "20px", "offsetTop": "36px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Version", "size": "10px", "color": "#00ff00", "align": "center", "offsetTop": "3px" } ], "position": "absolute", "width": "50px", "height": "20px", "backgroundColor": "#00000095" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Selfbot Flex V17", "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "3px" } ], "position": "absolute", "width": "90px", "height": "20px", "backgroundColor": "#00000095", "offsetStart": "50px" } ], "position": "absolute", "width": "140px", "height": "20px", "offsetTop": "56px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Friend", "size": "10px", "color": "#00ff00", "align": "center", "offsetTop": "3px" } ], "position": "absolute", "width": "50px", "height": "20px", "backgroundColor": "#00000095" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{} Friend".format(str(len(contactlist))), "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "3px" } ], "position": "absolute", "width": "90px", "height": "20px", "backgroundColor": "#00000095", "offsetStart": "50px" } ], "position": "absolute", "width": "140px", "height": "20px", "offsetTop": "76px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Blocked", "size": "10px", "color": "#00ff00", "align": "center", "offsetTop": "3px" } ], "position": "absolute", "width": "50px", "height": "20px", "backgroundColor": "#00000095" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{} Contact".format(str(len(blockedlist))), "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "4px" } ], "position": "absolute", "width": "90px", "height": "20px", "backgroundColor": "#00000095", "offsetStart": "50px" } ], "position": "absolute", "width": "140px", "height": "20px", "offsetTop": "96px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Favorite", "size": "10px", "color": "#00ff00", "align": "center", "offsetTop": "3px" } ], "position": "absolute", "width": "50px", "height": "20px", "backgroundColor": "#00000095" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(str(len(favoritelist))), "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "3px" } ], "position": "absolute", "width": "90px", "height": "20px", "backgroundColor": "#00000095", "offsetStart": "50px" } ], "position": "absolute", "width": "140px", "height": "20px", "offsetTop": "116px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Moto", "size": "10px", "color": "#00ff00", "align": "center", "offsetTop": "3px" } ], "position": "absolute", "width": "50px", "height": "20px", "backgroundColor": "#00000095" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "3px", "text": "Save Your Groups" } ], "position": "absolute", "width": "90px", "height": "20px", "backgroundColor": "#00000095", "offsetStart": "50px" } ], "position": "absolute", "width": "140px", "height": "20px", "offsetTop": "136px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Creator", "size": "10px", "color": "#00ff00", "align": "center", "offsetTop": "3px" } ], "position": "absolute", "width": "50px", "height": "20px", "backgroundColor": "#00000095" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "3px", "text": "Mr.V Return" } ], "position": "absolute", "width": "90px", "height": "20px", "backgroundColor": "#00000095", "offsetStart": "50px" } ], "position": "absolute", "width": "140px", "height": "20px", "offsetTop": "156px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Team", "size": "10px", "color": "#00ff00", "align": "center", "offsetTop": "3px" } ], "position": "absolute", "width": "50px", "height": "20px", "backgroundColor": "#00000095" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "size": "9px", "color": "#ffffff", "align": "center", "offsetTop": "4px", "text": "TEAM TERMUX" } ], "position": "absolute", "width": "90px", "height": "20px", "backgroundColor": "#00000095", "offsetStart": "50px" } ], "position": "absolute", "width": "140px", "height": "20px", "offsetTop": "176px" } ], "position": "absolute", "width": "140px", "height": "195px", "offsetTop": "30px", "offsetStart": "10px" } ], "paddingAll": "0px" }, "action": { "type": "uri", "label": "action", "uri": "line://nv/profilePopup/mid=u1094909befea4ff8d79d5f71d5356afb" } } }
                                sendTemplate(to, ALVIAN)       
                            except Exception as e:
                                cl.sendReplyMessage(msg.id,to, str(e))
                               
                        elif cmd.startswith("mid "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key1 = key["MENTIONEES"][0]["M"]
                               mi = cl.getContact(key1)
                               sendFoter(msg.to, "Nama : "+str(mi.displayName)+"\nMID : " +key1)
                               cl.sendMessage(msg.to, None, contentMetadata={'mid': key1}, contentType=13)

                        elif cmd.startswith("appname "):
                            if wait["selfbot"] == True:
                                if msg._from in admin:
                                   sep = text.split(" ")
                                   txt = text.replace(sep [0] + " ","")
                                   api = BEAPI()
                                   res = api.lineAppnameRandom(txt)
                                   pretyPrintJson(res)

                        elif ("Steal " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key1 = key["MENTIONEES"][0]["M"]
                               mi = cl.getContact(key1)
                               sendFotor(msg.to, "╭─「 Contact Info 」\n│ Nama : "+str(mi.displayName)+"\n│ Mid : " +key1+"\n│ Status Msg"+str(mi.statusMessage))
                               cl.sendMessage(msg.to, None, contentMetadata={'mid': key1}, contentType=13)
                               if "videoProfile='{" in str(cl.getContact(key1)):
                                   cl.sendVideoWithURL(msg.to, 'http://dl.profile.line.naver.jp'+str(mi.picturePath)+'/vp.small')
                               else:
                                   cl.sendImageWithURL(msg.to, 'http://dl.profile.line.naver.jp'+str(mi.picturePath))

                        elif ("/ti/g/" in msg.text):
                           if msg._from in admin or msg._from in staff:
                              if settings["autoJoinTicket"] == True:
                                 link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                                 links = link_re.findall(text)
                                 n_links = []
                                 for l in links:
                                    if l not in n_links:
                                       n_links.append(l)
                                 for ticket_id in n_links:
                                    group = cl.findGroupByTicket(ticket_id)
                                    cl.acceptGroupInvitationByTicket(group.id,ticket_id)
                                    flex2(msg.to, "Masuk : %s" % str(group.name))

                        elif text.lower() == "clearchat":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               try:
                                   cl.removeAllMessages(op.param2)
                                   flexvian(msg.to, "Cleared messages")
                               except:
                                   pass
                                
                        elif cmd.startswith("broadcast: "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:  
                                sep = text.split(" ")
                                txt = text.replace(sep [0] + " ","")
                                groups = cl.getGroupIdsJoined()
                                for group in groups:
                                    cl.sendMessage(group, "{}".format(str(txt)))
                                flex2(msg.to, "Broadcast {} Group".format(str(len(groups))))

                        elif text.lower() == "mykey":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               flex2(msg.to, "Setkey Anda: " + str(Setmain["keyCommand"]))
                               
                        elif cmd.startswith("setkey "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   flex2(msg.to, "Gagal mengganti key")
                               else:
                                   Setmain["keyCommand"] = str(key).lower()
                                   flex2(msg.to, "Update to {}".format(str(key).lower()))

                        elif cmd.startswith("setsider: "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   sendFlex(msg.to, "Gagal mengganti key")
                               else:
                                   wait["mention"] = str(key).lower()
                                   flex2(msg.to, "Update to {}".format(str(key).lower()))

                        elif cmd.startswith("setapikey: "):
                          if wait["selfbot"] == True:
                            if msg._from in "u1094909befea4ff8d79d5f71d5356afb":
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   sendFlex(msg.to, "Gagal mengganti key")
                               else:
                                   wait["apikey"] = str(key).lower()
                                   flex2(msg.to, "Success update apikey")

                        elif cmd.startswith("setwelcome: "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   sendFlex(msg.to, "Failed..!!")
                               else:
                                   wait["welcome"] = str(key).lower()
                                   flex2(msg.to, "{}".format(str(key).lower()))

                        elif cmd.startswith("setleave: "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   sendFlex(msg.to, "Failed..!!")
                               else:
                                   wait["leave"] = str(key).lower()
                                   flex2(msg.to, "{}".format(str(key).lower()))

                        elif text.lower() == "resetkey":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               Setmain["keyCommand"] = ""
                               flex2(msg.to, "Succes")

                        elif cmd == "reboot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               flexvian(msg.to, "Waitting 1 second")
                               time.sleep(5)
                               Setmain["restartPoint"] = msg.to
                               flexvian(msg.to, "Be reboot to pee.")
                               restartBot()
                                                          
                        elif cmd == "runtime":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                eltime = time.time() - mulai
                                bot = runtime(eltime)
                                flexvian(msg.to, bot)
                               
                        elif cmd == "blocklist":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                blockedlist = cl.getBlockedContactIds()
                                kontak = cl.getContacts(blockedlist)
                                num=1
                                msgs="「 Blocked List 」\n"
                                for ids in kontak:
                                    msgs+="\n%i. %s" % (num, ids.displayName)
                                    num=(num+1)
                                msgs+="\n\nTotal Blocked : %i" % len(kontak)
                                flex2(msg.to, msgs)
                                
                        elif cmd.startswith("delfriend "):
                          if msg._from in admin:
                            if msg.contentMetadata is not None  and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = cl.getContact(ls)
                                    cl.deleteContact(ls)
                                flex2(to, "Success Remove " + str(contact.displayName) + " to Friendlist")
                                
                        elif cmd == "friendlist":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = cl.getAllContactIds()
                               for i in gid:
                                   G = cl.getContact(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "┃┃ " + str(a) + ". " +G.displayName+ "\n"
                               flex2(msg.id,to,"┏━━[ FRIEND LIST ]\n┃┃\n"+ma+"┃┃\n┗━━[ Total「"+str(len(gid))+"」Friends ]")
                               
                        elif cmd.startswith("bye:"):
                            if wait["selfbot"] == True:
                              if msg._from in admin:
                                  separate = cmd.split(":")
                                  number = cmd.replace(separate[0] + ":","")
                                  groups = cl.getGroupIdsJoined()
                                  try:
                                      group = groups[int(number)-1]
                                      G = cl.getGroup(group)
                                      try:
                                          cl.leaveGroup(G.id)
                                      except:
                                          cl.leaveGroup(G.id)
                                      flex2(msg.to, "Leave Group : " + G.name)
                                  except Exception as error:
                                      sendFoter(msg.to, str(error))

                        elif cmd == "ginfo":
                          if msg._from in admin:
                            try:
                                G = cl.getGroup(msg.to)
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(cl.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                sendFoter(msg.to, "╭─「 Group Info 」\n├↘ Nama Group : {}".format(G.name)+ "\n├↘ ID Group : {}".format(G.id)+ "\n├↘ Pembuat : {}".format(G.creator.displayName)+ "\n├↘ Waktu Dibuat : {}".format(str(timeCreated))+ "\n├↘ Jumlah Member : {}".format(str(len(G.members)))+ "\n├↘ Jumlah Pending : {}".format(gPending)+ "\n├↘ Group Qr : {}".format(gQr)+ "\n├↘ Group Ticket : {}".format(gTicket))
                                cl.sendMessage(msg.to, None, contentMetadata={'mid': G.creator.mid}, contentType=13)
                                cl.sendImageWithURL(msg.to, 'http://dl.profile.line-cdn.net/'+G.pictureStatus)
                            except Exception as e:
                                sendFoter(msg.to, str(e))

                        elif cmd.startswith("infogrup "):
                          if msg._from in admin:
                            separate = text.split(" ")
                            number = text.replace(separate[0] + " ","")
                            groups = cl.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = cl.getGroup(group)
                                try:
                                    gCreator = G.creator.displayName
                                except:
                                    gCreator = "Tidak ditemukan"
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(cl.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                ret_ += "╭───「 Group Info 」───"
                                ret_ += "\n├↘ Nama Group : {}".format(G.name)
                                ret_ += "\n├↘ ID Group : {}".format(G.id)
                                ret_ += "\n├↘ Pembuat : {}".format(gCreator)
                                ret_ += "\n├↘ Waktu Dibuat : {}".format(str(timeCreated))
                                ret_ += "\n├↘ Jumlah Member : {}".format(str(len(G.members)))
                                ret_ += "\n├↘ Jumlah Pending : {}".format(gPending)
                                ret_ += "\n├↘ Group Qr : {}".format(gQr)
                                ret_ += "\n├↘ Group Ticket : {}".format(gTicket)
                                ret_ += "\n├↘ Picture Url : http://dl.profile.line-cdn.net/{}".format(G.pictureStatus)
                                ret_ += "\n╰──────────────"
                                sendFoter(msg.to, str(ret_))
                                cl.sendImageWithURL(msg.to, 'http://dl.profile.line-cdn.net/'+G.pictureStatus)
                            except:
                                pass

                        elif cmd.startswith("gurl "):
                          if msg._from in admin:
                            separate = text.split(" ")
                            number = text.replace(separate[0] + " ","")
                            groups = cl.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = cl.getGroup(group)
                                G.preventedJoinByTicket = False
                                cl.updateGroup(G)
                                try:
                                    gCreator = G.creator.mid
                                    dia = cl.getContact(gCreator)
                                    zx = ""
                                    zxc = ""
                                    zx2 = []
                                    xpesan = '「 Sukses Open Qr 」\n• Creator :  '
                                    diaa = str(dia.displayName)
                                    pesan = ''
                                    pesan2 = pesan+"@a\n"
                                    xlen = str(len(zxc)+len(xpesan))
                                    xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                    zx = {'S':xlen, 'E':xlen2, 'M':dia.mid}
                                    zx2.append(zx)
                                    zxc += pesan2
                                except:
                                    gCreator = "Tidak ditemukan"
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(cl.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                ret_ += xpesan+zxc
                                ret_ += "• Nama : {}".format(G.name)
                                ret_ += "\n• Group Qr : {}".format(gQr)
                                ret_ += "\n• Pendingan : {}".format(gPending)
                                ret_ += "\n• Group Ticket : {}".format(gTicket)
                                ret_ += ""
                                cl.sendMessage(receiver, ret_, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                            except:
                                pass

                        elif cmd.startswith("close "):
                          if msg._from in admin:
                            separate = text.split(" ")
                            number = text.replace(separate[0] + " ","")
                            groups = cl.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = cl.getGroup(group)
                                G.preventedJoinByTicket = True
                                cl.updateGroup(G)
                                try:
                                    gCreator = G.creator.mid
                                    dia = cl.getContact(gCreator)
                                    zx = ""
                                    zxc = ""
                                    zx2 = []
                                    xpesan = '「 Sukses Close Qr 」\n• Creator :  '
                                    diaa = str(dia.displayName)
                                    pesan = ''
                                    pesan2 = pesan+"@a\n"
                                    xlen = str(len(zxc)+len(xpesan))
                                    xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                    zx = {'S':xlen, 'E':xlen2, 'M':dia.mid}
                                    zx2.append(zx)
                                    zxc += pesan2
                                except:
                                    gCreator = "Tidak ditemukan"
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(cl.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                ret_ += xpesan+zxc
                                ret_ += "• Nama : {}".format(G.name)
                                ret_ += "\n• Group Qr : {}".format(gQr)
                                ret_ += "\n• Pendingan : {}".format(gPending)
                                ret_ += "\n• Group Ticket : {}".format(gTicket)
                                ret_ += ""
                                cl.sendMessage(receiver, ret_, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                            except:
                                pass

                        elif cmd.startswith("infomem "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            number = msg.text.replace(separate[0] + " ","")
                            groups = cl.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = cl.getGroup(group)
                                no = 0
                                ret_ = ""
                                for mem in G.members:
                                    no += 1
                                    ret_ += "\n " "├↘ "+ str(no) + ". " + mem.displayName
                                flex2(msg.to,"├↘ Group Name : [ " + str(G.name) + " ]\n\n   [ List Member ]\n" + ret_ + "\n\n「Total %i Members」" % len(G.members))
                            except: 
                                pass

                        elif cmd == "gruplist":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = cl.getGroupIdsJoined()
                               for i in gid:
                                   G = cl.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.name+ "\n"
                               flex2(msg.to,"╔══[ GROUP LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Groups ]")

                        elif cmd == "buka qr":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   X = cl.getGroup(msg.to)
                                   X.preventedJoinByTicket = False
                                   cl.updateGroup(X)
                                   flexvian(msg.to, "Open Link Groups")

                        elif cmd == "tutup qr":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   X = cl.getGroup(msg.to)
                                   X.preventedJoinByTicket = True
                                   cl.updateGroup(X)
                                   flexvian(msg.to, "Blocked Url Groups")

                        elif cmd == "url":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   x = cl.getGroup(msg.to)
                                   if x.preventedJoinByTicket == True:
                                      x.preventedJoinByTicket = False
                                      cl.updateGroup(x)
                                   gurl = cl.reissueGroupTicket(msg.to)
                                   sendFoter(msg.to, "Nama : "+str(x.name)+ "\nUrl : http://line.me/R/ti/g/"+gurl)
                                                                                     
                        elif cmd == "creator" or cmd == "owner":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                contact = cl.getProfile()
                                mids = [contact.mid]
                                status = cl.getContact(sender)                               	
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                cover = cl.getProfileCoverURL(sender)
                                data = {"type": "flex","altText": "TEAM TERMUX","contents":{"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/sygX9dY/ezgif-com-gif-maker-19.png","size": "full","aspectMode": "cover","aspectRatio": "1:1"}],"paddingAll": "0px"},"footer": {"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/KbfDFN1/1657636839741.jpg","size": "full","aspectRatio": "1:1","aspectMode": "cover","animated": True}],"position": "absolute","width": "18px","height": "18px","cornerRadius": "50px","offsetTop": "1px","offsetStart": "5px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "TEAM TERMUX","size": "9px","color": "#ffffff","align": "center","offsetTop": "1px"}],"position": "absolute","width": "130px","height": "15px","borderWidth": "1px","borderColor": "#ffffff","offsetTop": "2px","offsetStart": "25px","cornerRadius": "3px"}],"backgroundColor": "#000000"},"action": {"type": "uri","label": "action","uri": "line://nv/profilePopup/mid=u1094909befea4ff8d79d5f71d5356afb"}},{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/1XJ4f1z/ezgif-com-gif-maker-13.png","size": "full","aspectMode": "cover","aspectRatio": "1:1","gravity": "top"}],"paddingAll": "0px"},"footer": {"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/KbfDFN1/1657636839741.jpg","size": "full","aspectRatio": "1:1","aspectMode": "cover","animated": True}],"position": "absolute","width": "18px","height": "18px","cornerRadius": "50px","offsetTop": "1px","offsetStart": "5px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "PROTECTION YOUR GROUPS","size": "9px","color": "#ffffff","align": "center","offsetTop": "1px"}],"position": "absolute","width": "130px","height": "15px","borderWidth": "1px","borderColor": "#ffffff","offsetTop": "2px","offsetStart": "25px","cornerRadius": "3px"}],"backgroundColor": "#000000"},"action": {"type": "uri","label": "action","uri": "line://nv/profilePopup/mid=u1094909befea4ff8d79d5f71d5356afb"}},{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "TEAM TERMUX","size": "10px","color": "#00ff00","align": "center"},{"type": "separator","color": "#ffffff"}],"position": "absolute","width": "150px","height": "20px","offsetTop": "2px","offsetStart": "3px"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "TEAM : Zulkifli","size": "10px","color": "#ffffff","align": "center"},{"type": "separator","color": "#ffffff"}],"position": "absolute","width": "150px","height": "15px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "MAKER : Zulkifli","size": "10px","color": "#ffffff","align": "center"},{"type": "separator","color": "#ffffff"}],"position": "absolute","width": "150px","height": "15px","offsetTop": "15px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "RILISE : 2016","size": "10px","color": "#ffffff","align": "center"},{"type": "separator","color": "#ffffff"}],"position": "absolute","width": "150px","height": "15px","offsetTop": "30px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "VERSION : SELFBOT V17","size": "10px","color": "#ffffff","align": "center"},{"type": "separator","color": "#ffffff"}],"position": "absolute","width": "150px","height": "15px","offsetTop": "45px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "OPEN RENTAL BOT","size": "10px","color": "#ffffff","align": "center"},{"type": "separator","color": "#ffffff"}],"position": "absolute","width": "150px","height": "15px","offsetTop": "60px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "SELFBOT","size": "10px","color": "#ffffff","align": "center"},{"type": "separator","color": "#ffffff"}],"position": "absolute","width": "150px","height": "15px","offsetTop": "75px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "PROTECT ROOM","size": "10px","color": "#ffffff","align": "center"},{"type": "separator","color": "#ffffff"}],"position": "absolute","width": "150px","height": "15px","offsetTop": "90px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "GOLANG","size": "10px","color": "#ffffff","align": "center"},{"type": "separator","color": "#ffffff"}],"position": "absolute","width": "150px","height": "15px","offsetTop": "105px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "BOT WAR","size": "10px","color": "#ffffff","align": "center"},{"type": "separator","color": "#ffffff"}],"position": "absolute","width": "150px","height": "15px","offsetTop": "120px"}],"position": "absolute","width": "150px","height": "140px","offsetTop": "15px","offsetStart": "3px"}],"paddingAll": "0px","backgroundColor": "#000000"},"footer": {"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/KbfDFN1/1657636839741.jpg","size": "full","aspectRatio": "1:1","aspectMode": "cover","animated": True}],"position": "absolute","width": "18px","height": "18px","cornerRadius": "50px","offsetTop": "1px","offsetStart": "5px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "TAP HERE FOR ORDER","size": "9px","color": "#ffffff","align": "center","offsetTop": "1px"}],"position": "absolute","width": "130px","height": "15px","borderWidth": "1px","borderColor": "#ffffff","offsetTop": "2px","offsetStart": "25px","cornerRadius": "3px"}],"backgroundColor": "#000000"}}]}}
                                sendTemplate(to, data)
                                                        
                        elif cmd == "me" or cmd == "aku":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                contact = cl.getProfile()
                                mids = [contact.mid]
                                status = cl.getContact(sender)                               	
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                cover = cl.getProfileCoverURL(sender)
                                data = {"type": "flex","altText": "TEAM TERMUX","contents":{"type": "carousel","contents": [{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/fXcBH0n/20211220-153936.png","size": "full","aspectMode": "cover","aspectRatio": "2:3"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/1XJ4f1z/ezgif-com-gif-maker-13.png","size": "full","aspectRatio": "1:1","aspectMode": "cover"}],"position": "absolute","width": "32px","height": "32px","backgroundColor": "#000000","offsetTop": "5.5px","offsetStart": "6px"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/KbfDFN1/1657636839741.jpg","size": "full","aspectRatio": "1:1","aspectMode": "cover","animated": True}],"position": "absolute","width": "36px","height": "36px","backgroundColor": "#000000","offsetBottom": "1.5px","offsetEnd": "5px","cornerRadius": "50px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(status.displayName),"size": "10px","color": "#00ff00","align": "center","offsetTop": "2px"}],"position": "absolute","width": "105px","height": "17px","backgroundColor": "#00000050","borderWidth": "0.5px","borderColor": "#0000ff","cornerRadius": "3px","offsetEnd": "10px","offsetTop": "1px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "𝙳𝙴𝚃𝙰𝙸𝙻 𝙿𝚁𝙾𝙵𝙸𝙻𝙴","size": "8px","color": "#00ff00","align": "center","offsetTop": "4px"}],"position": "absolute","width": "75px","height": "17px","backgroundColor": "#00000050","borderWidth": "0.5px","borderColor": "#000000","cornerRadius": "2px","offsetTop": "22px","offsetStart": "43px"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://obs.line-scdn.net/{}".format(cl.getContact(sender).pictureStatus),"size": "full","aspectRatio": "2:3","aspectMode": "cover"}],"position": "absolute","width": "130px","height": "145px","backgroundColor": "#000000","borderWidth": "1px","borderColor": "#0000ff","cornerRadius": "4px","offsetTop": "48px","offsetStart": "14px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "TEAM TERMUX","size": "10px","color": "#00ff00","align": "center","offsetTop": "2px"}],"position": "absolute","width": "100px","height": "17px","backgroundColor": "#00000050","borderWidth": "0.5px","borderColor": "#0000ff","cornerRadius": "2px","offsetStart": "10px","offsetBottom": "25px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": " "+ datetime.strftime(timeNow,'%H:%M:%S'),"size": "10px","color": "#00ff00","align": "center","offsetTop": "2px"}],"position": "absolute","width": "100px","height": "17px","backgroundColor": "#00000050","borderWidth": "0.5px","borderColor": "#0000ff","cornerRadius": "2px","offsetStart": "10px","offsetBottom": "5px"}],"paddingAll": "0px","borderWidth": "1px","borderColor": "#0000ff","cornerRadius": "10px"},"action": {"type": "uri","label": "action","uri": "line://nv/profilePopup/mid=u1094909befea4ff8d79d5f71d5356afb"}},{"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/fXcBH0n/20211220-153936.png","size": "full","aspectMode": "cover","aspectRatio": "2:3"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/sygX9dY/ezgif-com-gif-maker-19.png","size": "full","aspectRatio": "1:1","aspectMode": "cover"}],"position": "absolute","width": "32px","height": "32px","backgroundColor": "#000000","offsetTop": "5.5px","offsetStart": "6px"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/KbfDFN1/1657636839741.jpg","size": "full","aspectRatio": "1:1","aspectMode": "cover","animated": True}],"position": "absolute","width": "36px","height": "36px","backgroundColor": "#000000","offsetBottom": "1.5px","offsetEnd": "5px","cornerRadius": "50px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "TEAM TERMUX","size": "8px","color": "#00ff00","align": "center","offsetTop": "4px"}],"position": "absolute","width": "105px","height": "17px","backgroundColor": "#00000050","borderWidth": "0.5px","borderColor": "#0000ff","cornerRadius": "3px","offsetEnd": "10px","offsetTop": "1px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "𝙳𝙴𝚃𝙰𝙸𝙻 𝙿𝚁𝙾𝙵𝙸𝙻𝙴","size": "8px","color": "#00ff00","align": "center","offsetTop": "4px"}],"position": "absolute","width": "75px","height": "17px","backgroundColor": "#00000050","borderWidth": "0.5px","borderColor": "#000000","cornerRadius": "2px","offsetTop": "22px","offsetStart": "43px"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "{}".format(cover),"size": "full","aspectRatio": "2:3","aspectMode": "cover"}],"position": "absolute","width": "130px","height": "145px","backgroundColor": "#000000","borderWidth": "1px","borderColor": "#0000ff","cornerRadius": "4px","offsetTop": "48px","offsetStart": "14px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "TEAM TERMUX","size": "10px","color": "#00ff00","align": "center","offsetTop": "2px"}],"position": "absolute","width": "100px","height": "17px","backgroundColor": "#00000050","borderWidth": "0.5px","borderColor": "#0000ff","cornerRadius": "2px","offsetStart": "10px","offsetBottom": "25px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": " " + datetime.strftime(timeNow,'%d-%m-%Y'),"size": "10px","color": "#00ff00","align": "center","offsetTop": "2px"}],"position": "absolute","width": "100px","height": "17px","backgroundColor": "#00000050","borderWidth": "0.5px","borderColor": "#0000ff","cornerRadius": "2px","offsetStart": "10px","offsetBottom": "5px"}],"paddingAll": "0px","borderWidth": "1px","borderColor": "#0000ff","cornerRadius": "10px"},"action": {"type": "uri","label": "action","uri": "line://nv/profilePopup/mid=u1094909befea4ff8d79d5f71d5356afb"}}]}}
                                sendTemplate(to, data)

                        elif cmd.startswith("musik:"):
                           if msg._from in admin:
                                set = text.split(" ")
                                mod = text.replace(set[0] + " ","")
                                mode = mod.split("|")
                                search = str(mode[0])
                                api = BEAPI()
                                main = api.jooxSearch(search)
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                if len(mode) == 1:
                                    num = 0
                                    ret_ = "MUSIK RESULT\n"
                                    for youtube in main["result"]:
                                        num += 1
                                        ret_ += "\n•{}. {}".format(str(num), str(youtube["msong"]))
                                    ret_ += "\nEXAMPLE FOR PLAY"
                                    ret_ += "\nKetik {} | No urutuan di atas ".format(str(text))
                                    cl.sendReplyMessage(msg.id,to, str(ret_))
                                elif len(mode) == 2:
                                    num = int(mode[1])
                                    if num <= len(main["result"]):
                                        pixel = main["result"] [num - 1]
                                        Zulkifli = {"type": "flex","TEAM TERMUX": "Music Template","contents": {"type": "bubble","size": "kilo","body": {"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/BtK5SZg/ezgif-com-gif-maker-26.png","size": "full","aspectMode": "cover","aspectRatio": "2:1"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/sHSrqfz/ezgif-com-gif-to-apng-4.png","size": "full","aspectRatio": "2:3","aspectMode": "cover","animated": True}],"position": "absolute","width": "60px","height": "80px","offsetTop": "30px","offsetEnd": "10px"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "{}".format(str(pixel["imgSrc"])),"size": "full","aspectRatio": "1:1","aspectMode": "cover"}],"position": "absolute","width": "65px","height": "65px","backgroundColor": "#000000","cornerRadius": "50px","offsetTop": "34px","offsetStart": "35px"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/KbfDFN1/1657636839741.jpg","animated": True,}],"position": "absolute","width": "27px","height": "27px","backgroundColor": "#000000","cornerRadius": "50px","offsetTop": "4px","offsetStart": "31px"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "NOTIFED MUSIC DOWNLOAD","size": "8px","color": "#ffffff"},{"type": "separator","color": "#ffffff"}],"position": "absolute","width": "100px","height": "15px"}],"position": "absolute","width": "100px","height": "20px","offsetTop": "12px","offsetStart": "87px"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "TEAM TERMUX","size": "8px","color": "#ffffff","align": "center"},{"type": "separator","color": "#ffffff"}],"position": "absolute","width": "50px","height": "15px"}],"position": "absolute","width": "50px","height": "20px","offsetTop": "12px","offsetStart": "190px"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Singer : {}".format(pixel["msinger"]),"size": "10px","color": "#ffffff"},{"type": "separator","color": "#ffffff"}],"position": "absolute","width": "140px","height": "15px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Title : {}".format(pixel["msong"]),"size": "10px","color": "#ffffff"},{"type": "separator","color": "#ffffff"}],"position": "absolute","width": "140px","height": "15px","offsetTop": "15px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Album : {}".format(pixel["malbum"]),"size": "10px","color": "#ffffff"},{"type": "separator","color": "#ffffff"}],"position": "absolute","width": "140px","height": "15px","offsetTop": "30px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Created : {}".format(pixel["public_time"]),"size": "10px","color": "#ffffff"},{"type": "separator","color": "#ffffff"}],"position": "absolute","width": "140px","height": "15px","offsetTop": "45px"}],"position": "absolute","width": "140px","height": "70px","offsetTop": "30px","offsetStart": "112px"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Time : "+ datetime.strftime(timeNow,'%H:%M:%S'),"size": "10px","color": "#ffffff"},{"type": "separator","color": "#ffffff"}],"position": "absolute","width": "80px","height": "15px"}],"position": "absolute","width": "80px","height": "20px","offsetStart": "87px","offsetBottom": "10px"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Date : "+ datetime.strftime(timeNow,'%Y-%m-%d'),"size": "10px","color": "#ffffff"},{"type": "separator","color": "#ffffff"}],"position": "absolute","width": "80px","height": "15px"}],"position": "absolute","width": "80px","height": "20px","offsetStart": "170px","offsetBottom": "10px"}],"paddingAll": "0px"},"action": {"type": "uri","label": "action","uri": "line://nv/profilePopup/mid=u1094909befea4ff8d79d5f71d5356afb"}}}
                                        sendTemplate(to, Zulkifli)
                                        sendFlexAudio(to, "{}".format(pixel["mp3Url"]))                                         

                        elif cmd.startswith("joox:"):
                           if msg._from in admin:
                                set = text.split(" ")
                                search = text.replace(set[0] + " ","")
                                api = imjustgood(wait["apikey"])
                                data = api.joox(search)
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                Zulkifli = {"type": "flex","altText": "TEAM TERMUX","contents": {"type": "bubble","size": "kilo","body": {"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/BtK5SZg/ezgif-com-gif-maker-26.png","size": "full","aspectMode": "cover","aspectRatio": "2:1"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/sHSrqfz/ezgif-com-gif-to-apng-4.png","size": "full","aspectRatio": "2:3","aspectMode": "cover","animated": True}],"position": "absolute","width": "60px","height": "80px","offsetTop": "30px","offsetEnd": "10px"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "{}".format(data["result"]["thumbnail"]),"size": "full","aspectRatio": "1:1","aspectMode": "cover"}],"position": "absolute","width": "65px","height": "65px","backgroundColor": "#000000","cornerRadius": "50px","offsetTop": "34px","offsetStart": "35px"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/KbfDFN1/1657636839741.jpg","animated": True,}],"position": "absolute","width": "27px","height": "27px","backgroundColor": "#000000","cornerRadius": "50px","offsetTop": "4px","offsetStart": "31px"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "NOTIFED MUSIC DOWNLOAD","size": "8px","color": "#ffffff"},{"type": "separator","color": "#ffffff"}],"position": "absolute","width": "100px","height": "15px"}],"position": "absolute","width": "100px","height": "20px","offsetTop": "12px","offsetStart": "87px"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "APK BOTS","size": "8px","color": "#ffffff","align": "center"},{"type": "separator","color": "#ffffff"}],"position": "absolute","width": "50px","height": "15px"}],"position": "absolute","width": "50px","height": "20px","offsetTop": "12px","offsetStart": "190px"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Singer : {}".format(data["result"]["singer"]),"size": "10px","color": "#ffffff"},{"type": "separator","color": "#ffffff"}],"position": "absolute","width": "140px","height": "15px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Title : {}".format(data["result"]["title"]),"size": "10px","color": "#ffffff"},{"type": "separator","color": "#ffffff"}],"position": "absolute","width": "140px","height": "15px","offsetTop": "15px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Durasi : {}".format(data["result"]["duration"]),"size": "10px","color": "#ffffff"},{"type": "separator","color": "#ffffff"}],"position": "absolute","width": "140px","height": "15px","offsetTop": "30px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Size : {}".format(data["result"]["size"]),"size": "10px","color": "#ffffff"},{"type": "separator","color": "#ffffff"}],"position": "absolute","width": "140px","height": "15px","offsetTop": "45px"}],"position": "absolute","width": "140px","height": "70px","offsetTop": "30px","offsetStart": "112px"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Time : "+ datetime.strftime(timeNow,'%H:%M:%S'),"size": "10px","color": "#ffffff"},{"type": "separator","color": "#ffffff"}],"position": "absolute","width": "80px","height": "15px"}],"position": "absolute","width": "80px","height": "20px","offsetStart": "87px","offsetBottom": "10px"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Date : "+ datetime.strftime(timeNow,'%Y-%m-%d'),"size": "10px","color": "#ffffff"},{"type": "separator","color": "#ffffff"}],"position": "absolute","width": "80px","height": "15px"}],"position": "absolute","width": "80px","height": "20px","offsetStart": "170px","offsetBottom": "10px"}],"paddingAll": "0px"},"action": {"type": "uri","label": "action","uri": "line://nv/profilePopup/mid=u1094909befea4ff8d79d5f71d5356afb"}}}
                                sendTemplate(to, Zulkifli)
                                sendFlexAudio(to, "{}".format(data["result"]["mp3Url"]))

                        elif cmd.startswith("imagetext:"):
                           if msg._from in admin:
                                set = text.split(" ")
                                search = text.replace(set[0] + " ","")
                                api = imjustgood(wait["apikey"])
                                data = api.imagetext(search)
                                img = data["result"]
                                cl.sendImageWithURL(to, str(img))
                            
                        elif cmd == "myliff":
                          if msg._from in admin:
                            if wait["selfbot"] == True:
                              ret_ = []
                              ret_.append({"thumbnailImageUrl": 'https://2.bp.blogspot.com/-_5b81bKClC4/XAEXlpG7PwI/AAAAAAAAAZ4/6MhJlHfSBrUdcn1vJngYvxP1sUZp-L3OQCLcBGAs/s1600/IMG_20181130_175412.JPG',"imageSize": "contain","imageAspectRatio": "square","title": 'FAKE EMAIL GENERATOR',"text": 'LIFF TYPE',"actions": [{"type": "uri","label": "👉 LIVE HERE 👈","uri": 'line://app/1623679774-bQ0ELEkW'}]})
                              ret_.append({"thumbnailImageUrl": 'https://1.bp.blogspot.com/-cmRUZ6qFAj4/VPF9oa5mU0I/AAAAAAAAiBw/YxFCYkmFZ6A/s728-e100/facebook-acccount-password.png',"imageSize": "contain","imageAspectRatio": "square","title": 'FACEBOOK.COM',"text": 'LIFF TYPE',"actions": [{"type": "uri","label": "👉 LIVE HERE 👈","uri": 'line://app/1609524990-mpvZ5xv5'}]})
                              ret_.append({"thumbnailImageUrl": 'https://topesdegama.com/app/uploads/2018/04/play-store-logo-color-750x400.jpg',"imageSize": "contain","imageAspectRatio": "square","title": 'PLAY STORE',"text": 'LIFF TYPE',"actions": [{"type": "uri","label": "👉 LIVE HERE ??","uri": 'line://app/1623679774-qmmXPXJ5'}]})
                              ret_.append({"thumbnailImageUrl": 'https://www.youredm.com/wp-content/uploads/2015/08/soundcloud-ad.png',"imageSize": "contain","imageAspectRatio": "square","title": 'SOUNDCLOUD',"text": 'LIFF TYPE',"actions": [{"type": "uri","label": "👉 LIVE HERE 👈","uri": 'line://app/1623679774-lGOq9q3G'}]})
                              ret_.append({"thumbnailImageUrl": 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTM6fb1xTcHlkyD9LH-dw03naHyZcHVLAosv9R1A2es1RqC0QTr',"imageSize": "contain","imageAspectRatio": "square","title": 'HIGHWAY',"text": 'LIFF TYPE',"actions": [{"type": "uri","label": "👉 LIVE HERE 👈","uri": 'line://app/1623679774-j4rZkZ51'}]})
                              k = len(ret_)//5
                              for aa in range(k+1):
                                  data = {
                                      "type": "template",
                                      "altText": "TEAM TERMUX",
                                      "template": {
                                          "type": "carousel",
                                          "columns": ret_[aa*5 : (aa+1)*5]
                                      }
                                  }
                                  sendTemplate(to,data)       

                        elif cmd.startswith("uns "):
                            if msg._from in admin:
                                sep = text.split(" ")
                                args = text.replace(sep[0] + " ", "")
                                mes = 0
                                try:
                                    mes = int(args[1])
                                except:
                                    mes = 1
                                M = cl.getRecentMessagesV2(to, 101)
                                MId = []
                                for ind, i in enumerate(M):
                                    if ind == 0:
                                        pass
                                    else:
                                        if i._from == cl.profile.mid:
                                            MId.append(i.id)
                                            if len(MId) == mes:
                                                break
                                def unsMes(id):
                                    cl.unsendMessage(id)
                                for i in MId:
                                    thread1 = threading.Thread(target=unsMes, args=(i,))
                                    thread1.start()
                                    thread1.join()
                                cl.unsendMessage(msg.id)
                                                                                                                                    
                        elif cmd == "tag":
                          if msg._from in admin:
                            cl.unsendMessage(msg.id)
                            group = cl.getGroup(to)
                            midMembers = [contact.mid for contact in group.members]
                            midSelect = len(midMembers)//20
                            for mentionMembers in range(midSelect+1):
                                no = 0
                                ret_ = "「 Mention member 」\n"
                                dataMid = []
                                for dataMention in group.members[mentionMembers*20 : (mentionMembers+1)*20]:
                                    dataMid.append(dataMention.mid)
                                    no += 1
                                    ret_ += "\n{}. @!".format(str(no))
                                ret_ += "\n\n「 Jumlah {} member 」".format(str(len(dataMid)))
                                khieMention(to, ret_, dataMid)    
   
                        elif cmd == comd["tagall"]:
                          if msg._from in admin:
                            cl.unsendMessage(msg.id)
                            members = []
                            if msg.toType == 1:
                                room = cl.getCompactRoom(to)
                                members = [mem.mid for mem in room.contacts]
                            elif msg.toType == 2:
                                group = cl.getCompactGroup(to)
                                members = [mem.mid for mem in group.members]
                            else:
                                return cl.sendMessage(to, 'Failed mentionall members, use this command only on room or group chat')
                            if members:
                                mentionMembers2(to, members)
        
                        elif cmd.startswith("tag: "):
                          if msg._from in admin:
                            separate = msg.text.split(":")
                            number = msg.text.replace(separate[0] + ":"," ")
                            groups = cl.getGroupIdsJoined()
                            gid = groups[int(number)-1]                                                                                                      
                            members = []
                            if msg.toType == 1:
                                room = cl.getCompactRoom(gid)
                                members = [mem.mid for mem in room.contacts]
                            elif msg.toType == 2:
                                group = cl.getCompactGroup(gid)
                                members = [mem.mid for mem in group.members]
                            else:
                                return cl.sendMessage(to, 'Failed mentionall members, use this command only on room or group chat')
                            if members:
                                mentionMembers2(gid, members)
                                flex2(msg.to, "Remote Mentions Group: " + str(group.name))                                                  
#=========================Notif smule=========================#                         
                        elif "https://www.smule.com/p/" in msg.text.lower() or "https://www.smule.com/" in msg.text.lower() or "https://www.smule.com/c/" in msg.text.lower() or "https://www.smule.com/s/" in msg.text.lower() or "https://link.smule.com/" in msg.text.lower() or "https://www.smule.com/sing-recording/" in msg.text.lower():
                          if wait["smulenotife"] == True:
                            Bebek = r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
                            Bek = re.findall(Bebek, text)
                            Ram = []
                            for Noobie in Bek:
                                if Noobie not in Ram:
                                    Ram.append(Noobie)
                            for BebekBotsTeam in Ram:
                                Rambu = BebekBotsTeam
                                headers = {
                                    "User-Agent": "Justgood/5.0",
                                    "apiKey": "Rambu86",
                                    "sysName": "GOOD249"
                                    }
                                Rambu = json.loads(requests.get("https://api.imjustgood.com/smuledl="+Rambu,headers=headers).text)
                                cl.sendMessage(to, "Sedang Download Smule")
                                if Rambu["result"]["type"] == "video":
                                    sendFlexVideo(to, "{}".format(Rambu["result"]["mp4Url"]))
                                sendFlexAudio(to, "{}".format(Rambu["result"]["mp3Url"]))
                                print("succes") 
#===========BOT UPDATE============#
                        elif cmd == "updategrup":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if msg.toType == 2:
                                settings["groupPicture"] = True
                                flexvian(msg.to,"Send a Picture ♪")
                                
                        elif cmd == "updatecover":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["changeCover"][clMID] = True
                                flexvian(msg.to,"Send a Picture ♪")

                        elif cmd == "updatefoto":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["changeFoto"][clMID] = True
                                flexvian(msg.to,"Send a Picture ♪")
                               
                                
                        elif cmd.startswith("myname: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = cl.getProfile()
                                profile.displayName = string
                                cl.updateProfile(profile)
                                flex2(msg.id,to,"Update to " + string + "")

                        elif cmd.startswith("cek "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            mid = msg.text.replace(separate[0] + " ","")
                            if mid is not None:
                                listMid = mid.split("*")
                                if len(listMid) > 1:
                                    for a in listMid:
                                        cl.sendContact(to,a)
                                else:
                                    cl.sendContact(to,mid)

                        elif cmd.startswith("stag"):
                            if msg._from in admin:
                                gname = cl.getGroup(msg.to)
                                local = [contact.mid for contact in gname.members]
                                try:
                                    lur = len(local)//20
                                    for fu in range(lur+1):
                                        hdc = u''
                                        sell=0
                                        com=[]
                                        for rid in gname.members[fu*20 : (fu+1)*20]:
                                            com.append({"S":str(sell), "E" :str(sell+6), "M":rid.mid})
                                            sell += 7
                                            hdc += u'@A_RFU\n'
                                            atas = '\n╭───────────────\n│Mention {} '.format(str(gname.name))
                                            atas += '\n│Total {} Members\n╰───────────────'.format(str(len(local)))
                                        cl.sendMessage(to, text=hdc + str(atas), contentMetadata={u'MENTION': json.dumps({'MENTIONEES':com})}, contentType=0)
                                except Exception as error:
                                    cl.sendMessage(to, str(error)) 

                        elif cmd.startswith("addtext "):
                            if msg._from in admin:
                                sep = text.split(" ")
                                apl = text.replace(sep[0] + " ","")
                                sam = apl.split("/")
                                chat1 = sam[0]
                                chat2 = sam[1]
                                apk = ""+chat1
                                tes["Message"][apk] = chat2
                                tes["msg"] = chat1
                                anu = tes["msg"]+'.'
                                cl.sendReplyMessage(msg.id,to,"Command %s created."%chat1)
                                tes["msg"] = {}

                        elif cmd == "list text":
                            if msg._from in admin:
                                if tes["Message"] == {}:
                                    cl.sendReplyMessage(msg.id,to,"empty text")
                                else:
                                    mc = ""
                                    jml = 1
                                    for listword in tes["Message"]:
                                        mc += "\n"+str(jml)+". "+listword+""
                                        jml += 1
                                    cl.sendReplyMessage(msg.id,to, "List text :\n"+str(mc))

                        elif cmd.startswith("deltext "):
                            	if msg._from in admin:
                                    sep = text.split(" ")
                                    xres = text.replace(sep[0] + " ","")
                                    tetx = text.replace(sep[0] + " ","")
                                    if xres in tes["Message"]:
                                        del tes["Message"][xres]                                        
                                        cl.sendReplyMessage(msg.id,to,"Command %s has been removed."%tetx)
                                    else:
                                        cl.sendReplyMessage(msg.id,to,"Command %s does not exist."%tetx)
                            
                        elif cmd == "screen -ls":
                          if msg._from in admin:
                              process = os.popen('screen -list')
                              a = process.read()
                              flex2(to, "{}".format(a))
                              process.close()

                        elif cmd == "myname":
                          if msg._from in admin:
                            h = cl.getContact(sender)
                            cl.sendReplyMessage(msg.id,to, "「 Name 」\n"+str(h.displayName))
                            
                        elif cmd == "mybio":
                          if msg._from in admin:
                            h = cl.getContact(sender)
                            cl.sendReplyMessage(msg.id,to, "「 Status 」\n"+str(h.statusMessage))
                            
                        elif cmd == "mypict":
                          if msg._from in admin:
                            h = cl.getContact(sender)
                            image = "http://dl.profile.line-cdn.net/" + h.pictureStatus
                            cl.sendImageWithURL(msg.to, image)     

                        elif cmd == "myvideo":
                          if msg._from in admin:
                            h = cl.getContact(sender)
                            if h.videoProfile == None:
                            	return cl.sendMessage(to, "「 Video 」\nNone")
                            cl.sendVideoWithURL(msg.to,"http://dl.profile.line-cdn.net/" + h.pictureStatus + "/vp")       
#===========BOT UPDATE============#                                                     
                        elif cmd == "listbot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                ma = ""
                                a = 0
                                for m_id in Bots:
                                    a = a + 1
                                    end = '\n│'
                                    ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n│"
                                flex2(msg.to,"╭─「 User botlist」\n│\n│"+ma+"\n╰──「 Total「%s」User Botlist 」" %(str(len(Bots))))

                        elif cmd == "listadmin":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                ma = ""
                                mb = ""
                                mc = ""
                                a = 0
                                b = 0
                                c = 0
                                for m_id in owner:
                                    a = a + 1
                                    end = '\n│'
                                    ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n│"
                                for m_id in admin:
                                    b = b + 1
                                    end = '\n│'
                                    mb += str(b) + ". " +cl.getContact(m_id).displayName + "\n│"
                                for m_id in staff:
                                    c = c + 1
                                    end = '\n│'
                                    mc += str(c) + ". " +cl.getContact(m_id).displayName + "\n│"
                                flex2(msg.to,"╭─「 List Admin Selfbot 」\n│\n│Owner:\n│"+ma+"\n│Admin:\n│"+mb+"\n│Staff:\n│"+mc+"\n╰──「Total「%s」Team 」" %(str(len(owner)+len(admin)+len(staff))))

                        elif cmd == "listprotect":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                ma = ""
                                mb = ""
                                mc = ""
                                md = ""
                                me = ""
                                a = 0
                                b = 0
                                c = 0
                                d = 0
                                e = 0
                                gid = protectqr
                                for group in gid:
                                    a = a + 1
                                    end = '\n│'
                                    ma += str(a) + ". " +cl.getGroup(group).name + "\n│"
                                gid = protectkick
                                for group in gid:
                                    b = b + 1
                                    end = '\n│'
                                    mb += str(b) + ". " +cl.getGroup(group).name + "\n│"
                                gid = protectjoin
                                for group in gid:
                                    d = d + 1
                                    end = '\n│'
                                    md += str(d) + ". " +cl.getGroup(group).name + "\n│"
                                gid = protectcancel
                                for group in gid:
                                    c = c + 1
                                    end = '\n│'
                                    mc += str(c) + ". " +cl.getGroup(group).name + "\n│"
                                gid = protectinvite
                                for group in gid:
                                    e = e + 1
                                    end = '\n│'
                                    me += str(e) + ". " +cl.getGroup(group).name + "\n"
                                flex2(msg.to,"╭─「 Setting Protection List 」\n│\n│ PROTECT URL :\n│"+ma+"\n│ PROTECT KICK :\n│"+mb+"\n│ PROTECT JOIN :\n│"+md+"\n│ PROTECT CANCEL:\n│"+mc+"\n│ PROTECT INVITE:\n│"+me+"\n╰──「 Total「%s」Protect 」" %(str(len(protectqr)+len(protectkick)+len(protectjoin)+len(protectcancel)+len(protectinvite))))


                        elif cmd == comd["bye"]:
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                G = cl.getGroup(msg.to)
                                flexvian(msg.to, "Sayonara......")
                                cl.leaveGroup(msg.to)

                        elif cmd == "respontime":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                get_profile_time_start = time.time()
                                get_profile = cl.getProfile()
                                get_profile_time = time.time() - get_profile_time_start
                                get_group_time_start = time.time()
                                get_group = cl.getGroupIdsJoined()
                                get_group_time = time.time() - get_group_time_start
                                get_contact_time_start = time.time()
                                get_contact = cl.getContact(mid)
                                get_contact_time = time.time() - get_contact_time_start
                                flex2(msg.to, "「 Respontime 」\n\n - Get Profile\n   %.10f\n - Get Contact\n   %.10f\n - Get Group\n   %.10f" % (get_profile_time/3,get_contact_time/3,get_group_time/3))

                        elif cmd == comd["speed"]:
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                start = time.time()
                                cl.sendMessage("u0a94a68c058d99a72f95b420a0b7a493", "test speed")
                                speed = time.time() - start
                                ping = speed * 1000
                                cl.sendReplyMessage(msg.id,to, "Time {} Ms !".format(str(speedtest(ping))))
                             
                        elif cmd == comd["siderOn"]:
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              cl.unsendMessage(msg.id)
                              try:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  flexvian(msg.to, "Sider Enable ♪") #\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")
                                  del cctv['point'][msg.to]
                                  del cctv['sidermem'][msg.to]
                                  del cctv['cyduk'][msg.to]
                              except:
                                  pass
                              cctv['point'][msg.to] = msg.id
                              cctv['sidermem'][msg.to] = ""
                              cctv['cyduk'][msg.to]=True

                        elif cmd == comd["siderOff"]:
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              if msg.to in cctv['point']:
                                  cl.unsendMessage(msg.id)
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  cctv['cyduk'][msg.to]=False
                                  flexvian(msg.to, "Sider Disable ♪") #\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")
                              else:
                                  flexvian(msg.to, "None Active..!!")
                             
                        elif cmd.startswith("find "):
                          if msg._from in admin:
                            if msg.contentMetadata is not None  and 'MENTION' in msg.contentMetadata:
                                key = eval(msg.contentMetadata["MENTION"])
                                key1 = key["MENTIONEES"][0]["M"]
                                a = cl.getGroupIdsJoined();i = cl.getGroups(a)
                                c = []
                                for h in i:
                                    g = [c.append(h.name[0:20]+',.s/'+str(len(h.members))) for d in h.members if key1 in d.mid]
                                h = "╭「 Find Contact 」─"
                                no = 0
                                for group in c:
                                    no += 1
                                    h+= "\n│{}. {} | {}".format(no, group.split(',.s/')[0], group.split(',.s/')[1])
                                flex2(msg.to,h+"\n╰─「 {} Groups I Found it 」".format(len(c)))                                
                                
                        elif cmd.startswith("tag "):
                          if msg._from in admin:
                            text = removeCmd("tag", text)
                            sep = text.split(" ")
                            text = text.replace(sep[0] + " ", text)
                            cond = text.split(" ")
                            jml = int(cond[0])
                            for x in range(jml):
                                name = cl.getContact(to)
                                RhyN_(to, name.mid)
                                
                        elif cmd.startswith("spam "):
                          if msg._from in admin:
                            dzin = removeCmd("spam", text)
                            line = dzin.split("|")
                            count = int(line[1])
                            text1 = removeCmd("spam"+str(line[0])+"|"+str(count)+"|", text)
                            text2 = count * (text1+"\n")
                            if line[0] == "on":
                                if count <= 1000:
                                    for a in range(count):
                                        cl.sendMessage(msg.to, str(text1))
                                else:
                                    cl.sendMessage(msg.to, "Max 1000.")
                            if line[0] == "off":
                                if count <= 1000:
                                    cl.sendMessage(msg.to, str(text2))
                                else:
                                    cl.sendMessage(msg.to, "Max 1000.")
                            
                        elif cmd == "clearallfriend":
                          if msg._from in admin:
                            n = len(cl.getAllContactIds())
                            try:
                                cl.clearContacts()
                            except: 
                                pass
                            t = len(cl.getAllContactIds())
                            flex2(msg.to,"Type: Friendlist\n • Detail: Clear Contact\n • Before: %s Friendlist\n • After: %s Friendlist\n • Total removed: %s Friendlist\n • Status: Succes.."%(n,t,(n-t)))
#===========Hiburan============#
                        elif cmd == "cctv code":
                          if msg._from in admin:
                           api = imjustgood(wait["apikey"])
                           data = api.cctv_code()
                           vian = "RESULT CCTV"
                           for b in data["result"]["active"]:
                               vian += "\n• {} {}".format(b,data["result"]["active"][b])
                           cl.sendReplyMessage(msg.id,to, "{}\nExample : Cctv (number)".format(vian))
                        elif cmd.startswith('cctv '):
                          if msg._from in admin:
                              try:
                                  args = text.split(" ")
                                  userId = text.replace(args[0] + " ","")
                                  api = imjustgood(wait["apikey"])
                                  data = api.cctvSearch(userId)
                                  print(data)
                                  vian = "DETAIL CCTV INFO"
                                  vian += "\nArea : {}".format(data["result"]["area"])
                                  vian += "\nWilayah : {}".format(data["result"]["wilayah"])
                                  cl.sendReplyMessage(msg.id,to, str(vian))
                                  sendFlexVideo(to, "{}".format(data["result"]["video"]))
                              except Exception as error:
                                  cl.sendReplyMessage(msg.id,to, str(error))

                        elif cmd.startswith('lyrik '):
                          if msg._from in admin:
                           args = text.split(" ")
                           userId = text.replace(args[0] + " ","")
                           api = imjustgood(wait["apikey"])
                           data = api.lyric(userId)
                           vian = "Title : {}".format(data["result"]["title"])
                           vian += "\nArtist : {}".format(data["result"]["artist"])
                           vian += "\n{}".format(data["result"]["lyric"])
                           cl.sendReplyMessage(msg.id,to, str(vian))

                        elif cmd.startswith('exc'):
                         if wait["selfbot"] == True:
                          if msg._from in admin:
                            try:
                               sep = text.split('\n')
                               kontol = text.replace(sep[0] + '\n','')
                               exec()
                            except Exception as e:
                               cl.sendReplyMessage(msg.id,to, "[ INFO ] Error :\n " + str(e))       

                        elif cmd.startswith('nama '):
                          if msg._from in admin:
                           args = text.split(" ")
                           userId = text.replace(args[0] + " ","")
                           api = imjustgood(wait["apikey"])
                           data = api.nama(userId)
                           Zulkifli = { "type": "flex", "altText": "TEAM TERMUX", "contents": { "type": "bubble", "size": "kilo", "body": { "type": "box", "layout": "vertical", "contents": [ { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "ARTI DARI NAMA SESEORANG", "size": "13px", "color": "#ffffff", "align": "center", "offsetTop": "1px" } ], "width": "235px", "height": "20px", "borderWidth": "0.5px", "borderColor": "#00ffff", "cornerRadius": "4px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Name : {}".format(data["result"]["name"]), "size": "13px", "color": "#ffffff", "align": "center", "offsetTop": "1px" } ], "width": "235px", "height": "20px", "borderWidth": "0.5px", "borderColor": "#00ffff", "cornerRadius": "4px", "offsetTop": "5px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Karakter", "size": "14px", "color": "#ffffff", "align": "center" } ], "position": "absolute", "width": "235px", "height": "20px", "borderWidth": "0.5px", "borderColor": "#00ffff" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(data["result"]["definition"]), "size": "12px", "color": "#ffffff", "align": "center", "wrap": True } ], "position": "absolute", "width": "235px", "height": "60px", "offsetTop": "20px" } ], "width": "235px", "height": "80px", "offsetTop": "10px" }, { "type": "text", "text": "{}".format(data["result"]["description"]), "size": "12px", "color": "#ffffff", "wrap": True, "offsetTop": "12px" } ], "backgroundColor": "#000000", "borderWidth": "1px", "borderColor": "#00ffff", "cornerRadius": "10px" }, "action": { "type": "uri", "label": "action", "uri": "line://nv/profilePopup/mid=u1094909befea4ff8d79d5f71d5356afb" } } }
                           sendTemplate(to, Zulkifli)         

                        elif cmd.startswith('tiktok '):
                          if msg._from in admin:
                           args = text.split(" ")
                           userId = text.replace(args[0] + " ","")
                           api = imjustgood(wait["apikey"])
                           data = api.tiktok(userId)
                           result  = "Username : {}".format(data["result"]["username"])
                           result += "\nFullname : {}".format(data["result"]["fullname"])
                           result += "\nPrivate : {}".format(data["result"]["private"])
                           result += "\nVerified : {}".format(data["result"]["private"])
                           result += "\nBiography : {}".format(data["result"]["biography"])
                           result += "\nFollowers : {}".format(data["result"]["followers"])
                           result += "\nFollowing : {}".format(data["result"]["following"])
                           result += "\nLikes : {}".format(data["result"]["likes"])
                           if data["result"]["lastpost"] != []:
                               for a in data["result"]["lastpost"]:
                                   result  = "\Lastpost"
                                   result += "\n- Caption : {}".format(a["desc"])
                                   result += "\n- Created : {}".format(a["created"])
                                   result += "\n- Comments : {}".format(a["comment"])
                                   result += "\n- Playing : {}".format(a["playing"])
                                   result += "\n- Share : {}".format(a["share"])
                               cl.sendReplyMessage(msg.id,to, str(result))
                               sendFlexVideo(to, "{}".format(a["videoUrl"]))

                        elif cmd.startswith('lahir '):
                          if msg._from in admin:
                           args = text.split(" ")
                           userId = text.replace(args[0] + " ","")
                           api = imjustgood(wait["apikey"])
                           data = api.lahir(userId)
                           vian = "Lahir : {}".format(data["result"]["lahir"])
                           vian += "\nHari : {}".format(data["result"]["hari"])
                           vian += "\nZodiac : {}".format(data["result"]["zodiak"])
                           vian += "\nUltah : {}".format(data["result"]["ultah"])
                           vian += "\nUsia : {}".format(data["result"]["usia"])
                           cl.sendReplyMessage(msg.id,to, str(vian))

                        elif cmd.startswith('calculator '):
                          if msg._from in admin:
                           args = text.split(" ")
                           userId = text.replace(args[0] + " ","")
                           api = imjustgood(wait["apikey"])
                           data = api.calc(userId)
                           cl.sendReplyMessage(msg.id,to, "{}".format(data["result"]))
                           
                        elif cmd.startswith('mimpi '):
                          if msg._from in admin:
                              try:
                                  args = text.split(" ")
                                  userId = text.replace(args[0] + " ","")
                                  api = imjustgood(wait["apikey"])
                                  data = api.mimpi(userId)
                                  vian = "ARTI DARI MIMPI"
                                  for vi in data["result"]:
                                      vian += "\nMimpi : {}".format(vi["dream"])
                                      vian += "\n{}".format(vi["meaning"])
                                  cl.sendReplyMessage(msg.id,to, str(vian))
                              except Exception as error:
                                  cl.sendReplyMessage(msg.id,to, str(error))

                        elif cmd.startswith('image '):
                          if msg._from in admin:
                           args = text.split(" ")
                           userId = text.replace(args[0] + " ","")
                           api = imjustgood(wait["apikey"])
                           data = api.wallpaper(userId)
                           for bot in data["result"]:
                               cl.sendImageWithURL(to, str(bot))

                        elif cmd.startswith('text '):
                          if msg._from in admin:
                           vi = text.split(" ")
                           vi1 = text.replace(vi[0] + " ","")
                           mode = vi1.split(" ")
                           search = str(mode[0])
                           kontol = {"id": "1","text": "{}".format(vi1),"text2": "{}".format(search)}
                           api = BEAPI()
                           res = api.textPro(kontol) 
                           cl.sendImageWithURL(to, "{}".format(res["result"]))
                        elif cmd.startswith('text1 '):
                          if msg._from in admin:
                           vi = text.split(" ")
                           vi1 = text.replace(vi[0] + " ","")
                           api = BEAPI()
                           kontol = {"id": "2","text": "{}".format(vi1)}
                           res = api.textPro(kontol)
                           cl.sendImageWithURL(to, "{}".format(res["result"]))
                        elif cmd.startswith('text2 '):
                          if msg._from in admin:
                           vi = text.split(" ")
                           vi1 = text.replace(vi[0] + " ","")
                           kontol = {"id": "9","text": "{}".format(vi1),"text2": "{}".format(vi1)}
                           api = BEAPI()  
                           res = api.textPro(kontol)
                           cl.sendImageWithURL(to, "{}".format(res["result"]))
                        elif cmd.startswith('text3 '):
                          if msg._from in admin:
                           vi = text.split(" ")
                           vi1 = text.replace(vi[0] + " ","")
                           api = BEAPI()
                           kontol = {"id": "4","text": "{}".format(vi1)}
                           res = api.textPro(kontol)
                           cl.sendImageWithURL(to, "{}".format(res["result"]))
                        elif cmd.startswith('text4 '):
                          if msg._from in admin:
                           vi = text.split(" ")
                           vi1 = text.replace(vi[0] + " ","")
                           api = BEAPI()
                           kontol = {"id": "5","text": "{}".format(vi1)}
                           res = api.textPro(kontol)
                           cl.sendImageWithURL(to, "{}".format(res["result"]))
                        elif cmd.startswith('text5 '):
                          if msg._from in admin:
                           vi = text.split(" ")
                           vi1 = text.replace(vi[0] + " ","")
                           api = BEAPI()
                           kontol = {"id": "6","text": "{}".format(vi1)}
                           res = api.textPro(kontol)
                           cl.sendImageWithURL(to, "{}".format(res["result"]))

                        elif cmd.startswith('eng '):
                          if msg._from in admin:
                           args = text.split(" ")
                           userId = text.replace(args[0] + " ","")
                           api = BEAPI()
                           data = api.googleTranslate("en", userId)
                           cl.sendReplyMessage(msg.id,to, "{}".format(data["result"]["trans"]))
                        elif cmd.startswith('japan '):
                          if msg._from in admin:
                           args = text.split(" ")
                           userId = text.replace(args[0] + " ","")
                           api = BEAPI()
                           data = api.googleTranslate("ja", userId)
                           cl.sendReplyMessage(msg.id,to, "{}".format(data["result"]["trans"]))
                        elif cmd.startswith('korea '):
                          if msg._from in admin:
                           args = text.split(" ")
                           userId = text.replace(args[0] + " ","")
                           api = BEAPI()
                           data = api.googleTranslate("ko", userId)
                           cl.sendReplyMessage(msg.id,to, "{}".format(data["result"]["trans"]))
                        elif cmd.startswith('india '):
                          if msg._from in admin:
                           args = text.split(" ")
                           userId = text.replace(args[0] + " ","")
                           api = BEAPI()
                           data = api.googleTranslate("hi", userId)
                           cl.sendReplyMessage(msg.id,to, "{}".format(data["result"]["trans"]))
                        elif cmd.startswith('francis '):
                          if msg._from in admin:
                           args = text.split(" ")
                           userId = text.replace(args[0] + " ","")
                           api = BEAPI()
                           data = api.googleTranslate("fr", userId)
                           cl.sendReplyMessage(msg.id,to, "{}".format(data["result"]["trans"]))
                        elif cmd.startswith('arab '):
                          if msg._from in admin:
                           args = text.split(" ")
                           userId = text.replace(args[0] + " ","")
                           api = BEAPI()
                           data = api.googleTranslate("ar", userId)
                           cl.sendReplyMessage(msg.id,to, "{}".format(data["result"]["trans"]))
                        elif cmd.startswith('china '):
                          if msg._from in admin:
                           args = text.split(" ")
                           userId = text.replace(args[0] + " ","")
                           api = BEAPI()
                           data = api.googleTranslate("zh-CN", userId)
                           cl.sendReplyMessage(msg.id,to, "{}".format(data["result"]["trans"]))
                        elif cmd.startswith('itali '):
                          if msg._from in admin:
                           args = text.split(" ")
                           userId = text.replace(args[0] + " ","")
                           api = BEAPI()
                           data = api.googleTranslate("it", userId)
                           cl.sendReplyMessage(msg.id,to, "{}".format(data["result"]["trans"]))
                        elif cmd.startswith('malay '):
                          if msg._from in admin:
                           args = text.split(" ")
                           userId = text.replace(args[0] + " ","")
                           api = BEAPI()
                           data = api.googleTranslate("ms", userId)
                           cl.sendReplyMessage(msg.id,to, "{}".format(data["result"]["trans"]))
                        elif cmd.startswith('turki '):
                          if msg._from in admin:
                           args = text.split(" ")
                           userId = text.replace(args[0] + " ","")
                           api = BEAPI()
                           data = api.googleTranslate("tr", userId)
                           cl.sendReplyMessage(msg.id,to, "{}".format(data["result"]["trans"]))
                        elif cmd.startswith('rusia '):
                          if msg._from in admin:
                           args = text.split(" ")
                           userId = text.replace(args[0] + " ","")
                           api = BEAPI()
                           data = api.googleTranslate("ru", userId)
                           cl.sendReplyMessage(msg.id,to, "{}".format(data["result"]["trans"]))
                        elif cmd.startswith('spanyol '):
                          if msg._from in admin:
                           args = text.split(" ")
                           userId = text.replace(args[0] + " ","")
                           api = BEAPI()
                           data = api.googleTranslate("es", userId)
                           cl.sendReplyMessage(msg.id,to, "{}".format(data["result"]["trans"]))
                        elif cmd.startswith('sunda '):
                          if msg._from in admin:
                           args = text.split(" ")
                           userId = text.replace(args[0] + " ","")
                           api = BEAPI()
                           data = api.googleTranslate("su", userId)
                           cl.sendReplyMessage(msg.id,to, "{}".format(data["result"]["trans"]))
                        elif cmd.startswith('indo '):
                          if msg._from in admin:
                           args = text.split(" ")
                           userId = text.replace(args[0] + " ","")
                           api = BEAPI()
                           data = api.googleTranslate("id", userId)
                           cl.sendReplyMessage(msg.id,to, "{}".format(data["result"]["trans"]))
                        elif cmd.startswith('thai '):
                          if msg._from in admin:
                           args = text.split(" ")
                           userId = text.replace(args[0] + " ","")
                           api = BEAPI()
                           data = api.googleTranslate("th", userId)
                           cl.sendReplyMessage(msg.id,to, "{}".format(data["result"]["trans"]))
                        elif cmd.startswith('vietnam '):
                          if msg._from in admin:
                           args = text.split(" ")
                           userId = text.replace(args[0] + " ","")
                           api = BEAPI()
                           data = api.googleTranslate("vi", userId)
                           cl.sendReplyMessage(msg.id,to, "{}".format(data["result"]["trans"]))
                        elif cmd.startswith('jawa '):
                          if msg._from in admin:
                           args = text.split(" ")
                           userId = text.replace(args[0] + " ","")
                           api = BEAPI()
                           data = api.googleTranslate("jw", userId)
                           cl.sendReplyMessage(msg.id,to, "{}".format(data["result"]["trans"]))
                        elif cmd.startswith('filipin '):
                          if msg._from in admin:
                           args = text.split(" ")
                           userId = text.replace(args[0] + " ","")
                           api = BEAPI()
                           data = api.googleTranslate("tl", userId)
                           cl.sendReplyMessage(msg.id,to, "{}".format(data["result"]["trans"]))
                        elif cmd.startswith('german '):
                          if msg._from in admin:
                           args = text.split(" ")
                           userId = text.replace(args[0] + " ","")
                           api = BEAPI()
                           data = api.googleTranslate("de", userId)
                           cl.sendReplyMessage(msg.id,to, "{}".format(data["result"]["trans"]))
                           
                        elif cmd.startswith('ytmp3 '):
                          if msg._from in admin:
                           args = text.split(" ")
                           userId = text.replace(args[0] + " ","")
                           api  = imjustgood(wait["apikey"])
                           data = api.youtube(userId)
                           Zulkifli = { "type": "flex", "altText": "TEAM TERMUX", "contents": { "type": "bubble", "size": "kilo", "body": { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/NTzTLQM/20211223-190955.png", "size": "full", "aspectMode": "cover", "aspectRatio": "3:1" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Hasil Pencarian Youtube Mp3", "color": "#ffffff", "align": "center", "size": "8px" } ], "position": "absolute", "width": "157px", "height": "12px", "backgroundColor": "#000000", "borderWidth": "0.5px", "borderColor": "#00ff00", "cornerRadius": "2px", "offsetTop": "0px", "offsetStart": "0px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Selamat Mendengarkan Lagunya Kak", "color": "#ffffff", "align": "center", "size": "8px" } ], "position": "absolute", "width": "157px", "height": "12px", "backgroundColor": "#000000", "borderWidth": "0.5px", "borderColor": "#00ff00", "cornerRadius": "2px", "offsetBottom": "0px", "offsetEnd": "0px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "{}".format(data["result"]["thumbnail"]), "size": "full", "aspectRatio": "1:1", "aspectMode": "cover" } ], "position": "absolute", "width": "55px", "height": "55px", "backgroundColor": "#000000", "borderWidth": "0.5px", "borderColor": "#00ff00", "cornerRadius": "2px", "offsetTop": "16px", "offsetStart": "15px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Durasi", "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "2px" } ], "position": "absolute", "width": "50px", "height": "18px", "backgroundColor": "#00ff0050" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(data["result"]["duration"]), "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "2px" } ], "position": "absolute", "width": "120px", "height": "18px", "backgroundColor": "#000000", "offsetStart": "50px" } ], "position": "absolute", "width": "170px", "height": "18px", "borderWidth": "0.5px", "borderColor": "#00ff00", "offsetTop": "15px", "offsetStart": "75px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Di tonton", "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "2px" } ], "position": "absolute", "width": "50px", "height": "18px", "backgroundColor": "#00ff0050" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(data["result"]["watched"]), "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "2px" } ], "position": "absolute", "width": "120px", "height": "18px", "backgroundColor": "#000000", "offsetStart": "50px" } ], "position": "absolute", "width": "170px", "height": "18px", "borderWidth": "0.5px", "borderColor": "#00ff00", "offsetTop": "35px", "offsetStart": "75px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Title", "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "2px" } ], "position": "absolute", "width": "50px", "height": "18px", "backgroundColor": "#00ff0050" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(data["result"]["title"]), "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "2px" } ], "position": "absolute", "width": "120px", "height": "18px", "backgroundColor": "#000000", "offsetStart": "50px" } ], "position": "absolute", "width": "170px", "height": "18px", "borderWidth": "0.5px", "borderColor": "#00ff00", "offsetTop": "55px", "offsetStart": "75px" } ], "paddingAll": "0px", "borderWidth": "1px", "borderColor": "#00ff00", "cornerRadius": "10px" }, "action": { "type": "uri", "label": "action", "uri": "line://nv/profilePopup/mid=u1094909befea4ff8d79d5f71d5356afb" } } }
                           sendTemplate(to, Zulkifli)         
                           sendFlexAudio(to, "{}".format(data["result"]["audioUrl"]))

                        elif cmd.startswith('porn '):
                          if msg._from in admin:
                           args = text.split(" ")
                           userId = text.replace(args[0] + " ","")
                           api  = imjustgood(wait["apikey"])
                           data = api.porn(userId)
                           Zulkifli = { "type": "flex", "altText": "TEAM TERMUX", "contents": { "type": "bubble", "size": "kilo", "body": { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/NTzTLQM/20211223-190955.png", "size": "full", "aspectMode": "cover", "aspectRatio": "3:1" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Hasil Pencarian Porn Videos", "color": "#ffffff", "align": "center", "size": "8px" } ], "position": "absolute", "width": "157px", "height": "12px", "backgroundColor": "#000000", "borderWidth": "0.5px", "borderColor": "#00ff00", "cornerRadius": "2px", "offsetTop": "0px", "offsetStart": "0px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(data["result"]["title"]), "color": "#ffffff", "align": "center", "size": "8px" } ], "position": "absolute", "width": "157px", "height": "12px", "backgroundColor": "#000000", "borderWidth": "0.5px", "borderColor": "#00ff00", "cornerRadius": "2px", "offsetBottom": "0px", "offsetEnd": "0px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "{}".format(data["result"]["thumbnail"]), "size": "full", "aspectRatio": "1:1", "aspectMode": "cover" } ], "position": "absolute", "width": "55px", "height": "55px", "backgroundColor": "#000000", "borderWidth": "0.5px", "borderColor": "#00ff00", "cornerRadius": "2px", "offsetTop": "16px", "offsetStart": "15px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Durasi", "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "2px" } ], "position": "absolute", "width": "50px", "height": "18px", "backgroundColor": "#00ff0050" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(data["result"]["duration"]), "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "2px" } ], "position": "absolute", "width": "120px", "height": "18px", "backgroundColor": "#000000", "offsetStart": "50px" } ], "position": "absolute", "width": "170px", "height": "18px", "borderWidth": "0.5px", "borderColor": "#00ff00", "offsetTop": "15px", "offsetStart": "75px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Di tonton", "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "2px" } ], "position": "absolute", "width": "50px", "height": "18px", "backgroundColor": "#00ff0050" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(data["result"]["watched"]), "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "2px" } ], "position": "absolute", "width": "120px", "height": "18px", "backgroundColor": "#000000", "offsetStart": "50px" } ], "position": "absolute", "width": "170px", "height": "18px", "borderWidth": "0.5px", "borderColor": "#00ff00", "offsetTop": "35px", "offsetStart": "75px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Quality", "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "2px" } ], "position": "absolute", "width": "50px", "height": "18px", "backgroundColor": "#00ff0050" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(data["result"]["quality"]), "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "2px" } ], "position": "absolute", "width": "120px", "height": "18px", "backgroundColor": "#000000", "offsetStart": "50px" } ], "position": "absolute", "width": "170px", "height": "18px", "borderWidth": "0.5px", "borderColor": "#00ff00", "offsetTop": "55px", "offsetStart": "75px" } ], "paddingAll": "0px", "borderWidth": "1px", "borderColor": "#00ff00", "cornerRadius": "10px" }, "action": { "type": "uri", "label": "action", "uri": "line://nv/profilePopup/mid=u1094909befea4ff8d79d5f71d5356afb" } } }
                           sendTemplate(to, Zulkifli)         
                           sendFlexVideo(to, "{}".format(data["result"]["videoUrl"]))

                        elif cmd.startswith('ytmp4 '):
                          if msg._from in admin:
                           args = text.split(" ")
                           userId = text.replace(args[0] + " ","")
                           api  = imjustgood(wait["apikey"])
                           data = api.youtube(userId)
                           KONTOL = { "type": "flex", "altText": "TEAM TERMUX", "contents": { "type": "bubble", "size": "kilo", "body": { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/NTzTLQM/20211223-190955.png", "size": "full", "aspectMode": "cover", "aspectRatio": "3:1" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Hasil Pencarian Youtube Mp4", "color": "#ffffff", "align": "center", "size": "8px" } ], "position": "absolute", "width": "157px", "height": "12px", "backgroundColor": "#000000", "borderWidth": "0.5px", "borderColor": "#00ff00", "cornerRadius": "2px", "offsetTop": "0px", "offsetStart": "0px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Selamat Mendengarkan Lagunya Kak", "color": "#ffffff", "align": "center", "size": "8px" } ], "position": "absolute", "width": "157px", "height": "12px", "backgroundColor": "#000000", "borderWidth": "0.5px", "borderColor": "#00ff00", "cornerRadius": "2px", "offsetBottom": "0px", "offsetEnd": "0px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "{}".format(data["result"]["thumbnail"]), "size": "full", "aspectRatio": "1:1", "aspectMode": "cover" } ], "position": "absolute", "width": "55px", "height": "55px", "backgroundColor": "#000000", "borderWidth": "0.5px", "borderColor": "#00ff00", "cornerRadius": "2px", "offsetTop": "16px", "offsetStart": "15px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Durasi", "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "2px" } ], "position": "absolute", "width": "50px", "height": "18px", "backgroundColor": "#00ff0050" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(data["result"]["duration"]), "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "2px" } ], "position": "absolute", "width": "120px", "height": "18px", "backgroundColor": "#000000", "offsetStart": "50px" } ], "position": "absolute", "width": "170px", "height": "18px", "borderWidth": "0.5px", "borderColor": "#00ff00", "offsetTop": "15px", "offsetStart": "75px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Di tonton", "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "2px" } ], "position": "absolute", "width": "50px", "height": "18px", "backgroundColor": "#00ff0050" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(data["result"]["watched"]), "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "2px" } ], "position": "absolute", "width": "120px", "height": "18px", "backgroundColor": "#000000", "offsetStart": "50px" } ], "position": "absolute", "width": "170px", "height": "18px", "borderWidth": "0.5px", "borderColor": "#00ff00", "offsetTop": "35px", "offsetStart": "75px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Title", "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "2px" } ], "position": "absolute", "width": "50px", "height": "18px", "backgroundColor": "#00ff0050" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(data["result"]["title"]), "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "2px" } ], "position": "absolute", "width": "120px", "height": "18px", "backgroundColor": "#000000", "offsetStart": "50px" } ], "position": "absolute", "width": "170px", "height": "18px", "borderWidth": "0.5px", "borderColor": "#00ff00", "offsetTop": "55px", "offsetStart": "75px" } ], "paddingAll": "0px", "borderWidth": "1px", "borderColor": "#00ff00", "cornerRadius": "10px" }, "action": { "type": "uri", "label": "action", "uri": "line://nv/profilePopup/mid=u1094909befea4ff8d79d5f71d5356afb" } } }
                           sendTemplate(to, KONTOL)         
                           sendFlexVideo(to, "{}".format(data["result"]["videoUrl"]))

                        elif cmd.startswith('cuaca '):
                          if msg._from in admin:
                           args = text.split(" ")
                           userId = text.replace(args[0] + " ","")
                           api = imjustgood(wait["apikey"])
                           data = api.cuaca(userId)
                           tz = pytz.timezone("Asia/Jakarta")
                           timeNow = datetime.now(tz=tz)
                           KONTOL = { "type": "flex", "altText": "TEAM TERMUX", "contents": { "type": "bubble", "size": "micro", "body": { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/pZbknGg/20211223-173200.png", "size": "full", "aspectMode": "cover", "aspectRatio": "1:1", "gravity": "center" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/KbfDFN1/1657636839741.jpg", "size": "full", "aspectRatio": "1:1", "aspectMode": "cover", "animated": True } ], "position": "absolute", "width": "18px", "height": "18px", "backgroundColor": "#000000", "cornerRadius": "50px", "offsetTop": "1px", "offsetStart": "4.3px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/KbfDFN1/1657636839741.jpg", "size": "full", "aspectRatio": "1:1", "aspectMode": "cover", "animated": True } ], "position": "absolute", "width": "18px", "height": "18px", "backgroundColor": "#000000", "cornerRadius": "50px", "offsetEnd": "4.3px", "offsetBottom": "1px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "INFO CUACA", "size": "9px", "color": "#00ff00", "align": "center" } ], "position": "absolute", "width": "62px", "height": "12px", "backgroundColor": "#000000", "borderWidth": "0.5px", "borderColor": "#00ff00", "cornerRadius": "1px", "offsetTop": "6.7px", "offsetStart": "35px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "TEAM TERMUX", "size": "9px", "color": "#00ff00", "align": "center" } ], "position": "absolute", "width": "62px", "height": "12px", "backgroundColor": "#000000", "borderWidth": "0.5px", "borderColor": "#00ff00", "cornerRadius": "1px", "offsetBottom": "6.8px", "offsetEnd": "35px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": " "+ datetime.strftime(timeNow,'%H:%M:%S'), "size": "8px", "color": "#ffffff", "align": "center", "offsetTop": "2px" } ], "position": "absolute", "width": "37px", "height": "15px", "backgroundColor": "#000000", "borderWidth": "0.5px", "borderColor": "#00ff00", "cornerRadius": "2px", "offsetTop": "3px", "offsetEnd": "5px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": " " + datetime.strftime(timeNow,'%d-%m-%Y'), "size": "8px", "color": "#ffffff", "align": "center", "offsetTop": "2px" } ], "position": "absolute", "width": "37px", "height": "15px", "backgroundColor": "#000000", "borderWidth": "0.5px", "borderColor": "#00ff00", "cornerRadius": "2px", "offsetBottom": "3px", "offsetStart": "5px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Location", "size": "10px", "color": "#000000", "align": "center", "offsetTop": "2px" } ], "position": "absolute", "width": "50px", "height": "20px", "backgroundColor": "#ffffff95" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(data["result"]["location"]), "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "2px" } ], "position": "absolute", "width": "90px", "height": "20px", "backgroundColor": "#00ff0050", "offsetStart": "50px" } ], "position": "absolute", "width": "140px", "height": "20px", "borderWidth": "0.5px", "borderColor": "#00ff00", "offsetTop": "22px", "offsetStart": "9px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Cuaca", "size": "10px", "color": "#000000", "align": "center", "offsetTop": "2px" } ], "position": "absolute", "width": "50px", "height": "20px", "backgroundColor": "#ffffff95" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(data["result"]["description"]), "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "2px" } ], "position": "absolute", "width": "90px", "height": "20px", "backgroundColor": "#00ff0050", "offsetStart": "50px" } ], "position": "absolute", "width": "140px", "height": "20px", "borderWidth": "0.5px", "borderColor": "#00ff00", "offsetTop": "45px", "offsetStart": "9px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Suhu", "size": "10px", "color": "#000000", "align": "center", "offsetTop": "2px" } ], "position": "absolute", "width": "50px", "height": "20px", "backgroundColor": "#ffffff95" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(data["result"]["temperature"]), "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "2px" } ], "position": "absolute", "width": "90px", "height": "20px", "backgroundColor": "#00ff0050", "offsetStart": "50px" } ], "position": "absolute", "width": "140px", "height": "20px", "borderWidth": "0.5px", "borderColor": "#00ff00", "offsetTop": "68px", "offsetStart": "9px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Angin", "size": "10px", "color": "#000000", "align": "center", "offsetTop": "2px" } ], "position": "absolute", "width": "50px", "height": "20px", "backgroundColor": "#ffffff95" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(data["result"]["wind"]), "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "2px" } ], "position": "absolute", "width": "90px", "height": "20px", "backgroundColor": "#00ff0050", "offsetStart": "50px" } ], "position": "absolute", "width": "140px", "height": "20px", "borderWidth": "0.5px", "borderColor": "#00ff00", "offsetTop": "91px", "offsetStart": "9px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Kelembapan", "size": "10px", "color": "#000000", "align": "center", "offsetTop": "2px" } ], "position": "absolute", "width": "50px", "height": "20px", "backgroundColor": "#ffffff95" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(data["result"]["humidity"]), "size": "10px", "color": "#ffffff", "align": "center", "offsetTop": "2px" } ], "position": "absolute", "width": "90px", "height": "20px", "backgroundColor": "#00ff0050", "offsetStart": "50px" } ], "position": "absolute", "width": "140px", "height": "20px", "borderWidth": "0.5px", "borderColor": "#00ff00", "offsetTop": "115px", "offsetStart": "9px" } ], "paddingAll": "0px", "borderWidth": "1px", "borderColor": "#00ff0095", "cornerRadius": "10px" }, "action": { "type": "uri", "label": "action", "uri": "line://nv/profilePopup/mid=u1094909befea4ff8d79d5f71d5356afb" } } }
                           sendTemplate(to, KONTOL)         

                        elif cmd.startswith('sholat '):
                          if msg._from in admin:
                           args = text.split(" ")
                           userId = text.replace(args[0] + " ","")
                           api = imjustgood(wait["apikey"])
                           data = api.adzan(userId)
                           Zulkifli = { "type": "flex", "altText": "TEAM TERMUX", "contents": { "type": "bubble", "size": "micro", "body": { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/mXJ0Cvr/20211222-204940.png", "size": "full", "aspectMode": "cover", "aspectRatio": "9:16", "gravity": "center" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/xD279n2/ezgif-com-gif-maker-36.png", "size": "full", "aspectRatio": "1:1", "aspectMode": "cover", "animated": True } ], "position": "absolute", "width": "35px", "height": "35px", "backgroundColor": "#000000", "offsetTop": "2.5px", "offsetStart": "4.5px", "cornerRadius": "1px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/QNDMj7T/ezgif-com-gif-maker-35.png", "aspectRatio": "1:1", "aspectMode": "cover", "animated": True } ], "position": "absolute", "width": "18px", "height": "18px", "backgroundColor": "#000000", "borderWidth": "0.5px", "borderColor": "#ffd700", "offsetBottom": "2px", "offsetEnd": "10px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "TEAM TERMUX", "color": "#00ff00", "align": "center", "size": "11px", "offsetTop": "2.5px" } ], "position": "absolute", "width": "120px", "height": "17px", "backgroundColor": "#000000", "borderWidth": "0.5px", "borderColor": "#ffd700", "cornerRadius": "2px", "offsetBottom": "2.5px", "offsetStart": "7px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "JADWAL SHALLAT", "size": "11px", "color": "#00ff00", "align": "center", "offsetTop": "2.5px" } ], "position": "absolute", "width": "105px", "height": "17px", "backgroundColor": "#000000", "borderWidth": "0.5px", "borderColor": "#ffd700", "cornerRadius": "2px", "offsetTop": "2.5px", "offsetStart": "45px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "LIST RESULT", "size": "8px", "color": "#00ff00", "align": "center", "offsetTop": "2px" } ], "position": "absolute", "width": "105px", "height": "12px", "backgroundColor": "#000000", "borderWidth": "0.5px", "borderColor": "#ffd700", "cornerRadius": "2px", "offsetTop": "25px", "offsetStart": "45px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Imsyak", "size": "10px", "color": "#000000", "align": "center", "offsetTop": "1px" } ], "position": "absolute", "width": "50px", "height": "15px", "backgroundColor": "#ffffff95" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Pukul : {}".format(data["result"]["adzan"]["imsyak"]), "size": "10px", "color": "#ffffff", "align": "center" } ], "position": "absolute", "width": "90px", "height": "15px", "backgroundColor": "#00ff0050", "offsetStart": "50px" } ], "position": "absolute", "width": "142px", "height": "15px", "offsetTop": "45px", "offsetStart": "8px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Dhuha", "size": "10px", "color": "#000000", "align": "center", "offsetTop": "1px" } ], "position": "absolute", "width": "50px", "height": "15px", "backgroundColor": "#ffffff95" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Pukul : {}".format(data["result"]["adzan"]["dhuha"]), "size": "10px", "color": "#ffffff", "align": "center" } ], "position": "absolute", "width": "90px", "height": "15px", "backgroundColor": "#00ff0050", "offsetStart": "50px" } ], "position": "absolute", "width": "142px", "height": "15px", "offsetTop": "65px", "offsetStart": "8px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Subuh", "size": "10px", "color": "#000000", "align": "center", "offsetTop": "1px" } ], "position": "absolute", "width": "50px", "height": "15px", "backgroundColor": "#ffffff95" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Pukul : {}".format(data["result"]["adzan"]["subuh"]), "size": "10px", "color": "#ffffff", "align": "center" } ], "position": "absolute", "width": "90px", "height": "15px", "backgroundColor": "#00ff0050", "offsetStart": "50px" } ], "position": "absolute", "width": "142px", "height": "15px", "offsetTop": "85px", "offsetStart": "8px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Terbit", "size": "10px", "color": "#000000", "align": "center", "offsetTop": "1px" } ], "position": "absolute", "width": "50px", "height": "15px", "backgroundColor": "#ffffff95" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Pukul : {}".format(data["result"]["adzan"]["terbit"]), "size": "10px", "color": "#ffffff", "align": "center" } ], "position": "absolute", "width": "90px", "height": "15px", "backgroundColor": "#00ff0050", "offsetStart": "50px" } ], "position": "absolute", "width": "142px", "height": "15px", "offsetTop": "105px", "offsetStart": "8px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Dzuhur", "size": "10px", "color": "#000000", "align": "center", "offsetTop": "1px" } ], "position": "absolute", "width": "50px", "height": "15px", "backgroundColor": "#ffffff95" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Pukul : {}".format(data["result"]["adzan"]["dzuhur"]), "size": "10px", "color": "#ffffff", "align": "center" } ], "position": "absolute", "width": "90px", "height": "15px", "backgroundColor": "#00ff0050", "offsetStart": "50px" } ], "position": "absolute", "width": "142px", "height": "15px", "offsetTop": "125px", "offsetStart": "8px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Ashar", "size": "10px", "color": "#000000", "align": "center", "offsetTop": "1px" } ], "position": "absolute", "width": "50px", "height": "15px", "backgroundColor": "#ffffff95" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Pukul : {}".format(data["result"]["adzan"]["ashar"]), "size": "10px", "color": "#ffffff", "align": "center" } ], "position": "absolute", "width": "90px", "height": "15px", "backgroundColor": "#00ff0050", "offsetStart": "50px" } ], "position": "absolute", "width": "142px", "height": "15px", "offsetTop": "145px", "offsetStart": "8px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Maggrib", "size": "10px", "color": "#000000", "align": "center", "offsetTop": "1px" } ], "position": "absolute", "width": "50px", "height": "15px", "backgroundColor": "#ffffff95" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Pukul : {}".format(data["result"]["adzan"]["maghrib"]), "size": "10px", "color": "#ffffff", "align": "center" } ], "position": "absolute", "width": "90px", "height": "15px", "backgroundColor": "#00ff0050", "offsetStart": "50px" } ], "position": "absolute", "width": "142px", "height": "15px", "offsetTop": "165px", "offsetStart": "8px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Isya", "size": "10px", "color": "#000000", "align": "center", "offsetTop": "1px" } ], "position": "absolute", "width": "50px", "height": "15px", "backgroundColor": "#ffffff95" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Pukul : {}".format(data["result"]["adzan"]["isya"]), "size": "10px", "color": "#ffffff", "align": "center" } ], "position": "absolute", "width": "90px", "height": "15px", "backgroundColor": "#00ff0050", "offsetStart": "50px" } ], "position": "absolute", "width": "142px", "height": "15px", "offsetTop": "185px", "offsetStart": "8px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Tanggal", "size": "10px", "color": "#000000", "align": "center", "offsetTop": "1px" } ], "position": "absolute", "width": "50px", "height": "15px", "backgroundColor": "#ffffff95" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(data["result"]["tanggal"]), "size": "10px", "color": "#ffffff", "align": "center" } ], "position": "absolute", "width": "90px", "height": "15px", "backgroundColor": "#00ff0050", "offsetStart": "50px" } ], "position": "absolute", "width": "142px", "height": "15px", "offsetTop": "205px", "offsetStart": "8px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Wilayah", "size": "10px", "color": "#000000", "align": "center", "offsetTop": "1px" } ], "position": "absolute", "width": "50px", "height": "15px", "backgroundColor": "#ffffff95" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(data["result"]["wilayah"]), "size": "10px", "color": "#ffffff", "align": "center" } ], "position": "absolute", "width": "90px", "height": "15px", "backgroundColor": "#00ff0050", "offsetStart": "50px" } ], "position": "absolute", "width": "142px", "height": "15px", "offsetTop": "225px", "offsetStart": "8px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "Solatlah Sebelum Anda Di solatkan", "size": "9px", "color": "#ffffff", "align": "center" } ], "position": "absolute", "width": "140px", "height": "12px", "backgroundColor": "#00ff0050", "offsetBottom": "26px", "offsetStart": "8px" } ], "paddingAll": "0px", "borderWidth": "1px", "borderColor": "#ffd700", "cornerRadius": "10px" }, "action": { "type": "uri", "label": "action", "uri": "line://nv/profilePopup/mid=u1094909befea4ff8d79d5f71d5356afb" } } }
                           sendTemplate(to, Zulkifli)         

                        elif cmd == "corona":
                          if msg._from in admin:
                           api = imjustgood(wait["apikey"])
                           data = api.corona()
                           tz = pytz.timezone("Asia/Jakarta")
                           timeNow = datetime.now(tz=tz)
                           Zulkifli = {"type": "flex","altText": "TEAM TERMUX","contents": {"type": "bubble","size": "micro","body": {"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/WnDPHW9/20211222-161430.png","size": "full","aspectMode": "cover","aspectRatio": "5:8"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/ySztT22/ezgif-com-gif-maker-34.png","size": "full","aspectRatio": "1:1","aspectMode": "cover","animated": True}],"position": "absolute","width": "30px","height": "30px","backgroundColor": "#000000","offsetTop": "6px","offsetStart": "16.5px","cornerRadius": "1px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "𝚀𝚄𝙸𝙲𝙺𝙲𝙾𝚄𝙽??","size": "10px","color": "#00ff00","align": "center","offsetTop": "1px"}],"position": "absolute","width": "93px","height": "15px","backgroundColor": "#000000","borderWidth": "0.5px","borderColor": "#ff0000","cornerRadius": "2px","offsetTop": "2.5px","offsetStart": "52px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "𝙲𝙾𝚅𝙸𝙳 𝟷??","size": "10px","color": "#00ff00","align": "center","offsetTop": "1px"}],"position": "absolute","width": "70px","height": "15px","backgroundColor": "#000000","borderWidth": "0.5px","borderColor": "#ff0000","cornerRadius": "2px","offsetTop": "21px","offsetStart": "50px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": " "+ datetime.strftime(timeNow,'%H:%M:%S'),"size": "10px","color": "#00ff00","align": "center"}],"position": "absolute","width": "55px","height": "15px","backgroundColor": "#000000","borderWidth": "0.5px","borderColor": "#ff0000","cornerRadius": "2px","offsetBottom": "2.5px","offsetStart": "5px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": " " + datetime.strftime(timeNow,'%d-%m-%Y'),"size": "10px","color": "#00ff00","align": "center"}],"position": "absolute","width": "55px","height": "15px","backgroundColor": "#000000","borderWidth": "0.5px","borderColor": "#ff0000","cornerRadius": "2px","offsetBottom": "2.5px","offsetEnd": "5px"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/ySztT22/ezgif-com-gif-maker-34.png","size": "full","aspectRatio": "1:1","aspectMode": "cover","animated": True}],"position": "absolute","width": "18px","height": "18px","backgroundColor": "#000000","offsetBottom": "2.5px","offsetStart": "70px","cornerRadius": "50px"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "𝚂𝙴𝙻𝚄𝚁𝚄𝙷 𝙳𝚄𝙽𝙸𝙰","size": "10px","color": "#00ff00","align": "center","offsetTop": "1px"}],"position": "absolute","width": "131px","height": "15px","backgroundColor": "#000000","borderWidth": "0.5px","borderColor": "#ff0000"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Terjangkit : {}".format(data["result"]["world"]["case"]),"size": "10px","color": "#000000","offsetStart": "5px"}],"position": "absolute","width": "131px","height": "15px","backgroundColor": "#ffffff95","borderWidth": "0.5px","borderColor": "#ff0000","offsetTop": "15px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Meninggal : {}".format(data["result"]["world"]["rip"]),"size": "10px","color": "#000000","offsetStart": "5px"}],"position": "absolute","width": "131px","height": "15px","backgroundColor": "#ffffff95","borderWidth": "0.5px","borderColor": "#ff0000","offsetTop": "30px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Sembuh : {}".format(data["result"]["world"]["fit"]),"size": "10px","color": "#000000","offsetStart": "5px"}],"position": "absolute","width": "131px","height": "15px","backgroundColor": "#ffffff95","borderWidth": "0.5px","borderColor": "#ff0000","offsetTop": "45px"}],"position": "absolute","width": "131px","height": "61px","borderWidth": "0.5px","borderColor": "#ff0000","cornerRadius": "2px","offsetTop": "45px","offsetStart": "14px"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "𝙸𝙽𝙳𝙾𝙽𝙴𝚂𝙸𝙰","size": "10px","color": "#00ff00","align": "center","offsetTop": "1px"}],"position": "absolute","width": "131px","height": "15px","backgroundColor": "#000000","borderWidth": "0.5px","borderColor": "#ff0000"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Terjangkit : {}".format(data["result"]["indonesia"]["fit"]),"size": "10px","color": "#000000","offsetStart": "5px"}],"position": "absolute","width": "131px","height": "15px","backgroundColor": "#ffffff95","borderWidth": "0.5px","borderColor": "#ff0000","offsetTop": "15px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Meninggal : {}".format(data["result"]["indonesia"]["rip"]),"size": "10px","color": "#000000","offsetStart": "5px"}],"position": "absolute","width": "131px","height": "15px","backgroundColor": "#ffffff95","borderWidth": "0.5px","borderColor": "#ff0000","offsetTop": "30px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Sembuh : {}".format(data["result"]["indonesia"]["fit"]),"size": "10px","color": "#000000","offsetStart": "5px"}],"position": "absolute","width": "131px","height": "15px","backgroundColor": "#ffffff95","borderWidth": "0.5px","borderColor": "#ff0000","offsetTop": "45px"}],"position": "absolute","width": "131px","height": "61px","borderWidth": "0.5px","borderColor": "#ff0000","cornerRadius": "2px","offsetTop": "155px","offsetStart": "14px"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "𝙷𝙸𝙼𝙱𝙰𝚄𝙰𝙽 𝚄𝙽𝚃𝚄𝙺 𝚆𝙰𝚁𝙶𝙰","size": "10px","color": "#00ff00","align": "center","offsetTop": "1px"}],"position": "absolute","width": "131px","height": "15px","backgroundColor": "#000000","borderWidth": "0.5px","borderColor": "#ff0000"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Tetap pakai masker, Jaga jarak dan cuci tangan di air mengalir","size": "8px","color": "#000000","align": "center","wrap": True}],"position": "absolute","width": "131px","height": "35px","offsetTop": "15px"}],"position": "absolute","width": "131px","height": "40px","backgroundColor": "#ffffff95","borderWidth": "0.5px","borderColor": "#ff0000","cornerRadius": "2px","offsetTop": "110px","offsetStart": "14px"}],"paddingAll": "0px","borderWidth": "1px","borderColor": "#ff0000","cornerRadius": "10px"},"action": {"type": "uri","label": "action","uri": "line://nv/profilePopup/mid=u1094909befea4ff8d79d5f71d5356afb"}}}
                           sendTemplate(to, Zulkifli)           

                        elif cmd == "surahlist":
                          if msg._from in admin:
                           api = imjustgood(wait["apikey"])
                           data = api.alquran()
                           vian  = "LIST SURAH AL-QUR'AN"
                           for qs in data:
                               vian += "\n{}".format(qs)
                           cl.sendReplyMessage(msg.id,to, str(vian)) 

                        elif cmd.startswith('surah '):
                          if msg._from in admin:
                              try:
                                  args = text.split(" ")
                                  userId = text.replace(args[0] + " ","")
                                  api = imjustgood(wait["apikey"])
                                  data = api.alquranQS(userId) 
                                  audioUrl = data["result"]["audio"]
                                  vian = "Di Turunkan Di :{}\n".format(data["result"]["place"])
                                  vian += "{}".format(data["result"]["desc"])
                                  cl.sendReplyMessage(msg.id,to, (vian))
                                  sendFlexAudio(to, str(audioUrl))
                              except Exception as error:
                                  cl.sendReplyMessage(msg.id,to, "ERROR!\nText Terlalu Panjang!!")         

                        elif cmd == "info bmkg":
                          if msg._from in admin:
                           api = imjustgood(wait["apikey"])
                           data = api.bmkg()
                           ALVIAN = {"type": "flex","altText": "TEAM TERMUX","contents": {"type": "bubble","size": "kilo","body": {"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/qDDMBKV/20211222-095106.png","size": "full","aspectMode": "cover","aspectRatio": "5:8","gravity": "center"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/CbNhcqQ/ezgif-com-gif-maker-34.png","aspectRatio": "1:1","aspectMode": "cover","animated": True}],"position": "absolute","width": "78.5px","height": "78.5px","backgroundColor": "#000000","offsetTop": "24.5px","offsetEnd": "25px"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "{}".format(data["result"]["skema"]),"aspectRatio": "1:1","aspectMode": "cover","animated": True}],"position": "absolute","width": "78.5px","height": "78.5px","backgroundColor": "#000000","offsetBottom": "24.5px","offsetStart": "25px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "MAP PICTURE","size": "10px","color": "#00ff00","align": "center","offsetTop": "1px"}],"position": "absolute","width": "80px","height": "15px","backgroundColor": "#000000","borderWidth": "0.5px","borderColor": "#00ff00","cornerRadius": "2px","offsetBottom": "4px","offsetStart": "24.5px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "阿尔维安普特拉","size": "10px","color": "#00ff00","align": "center","offsetTop": "2px"}],"position": "absolute","width": "80px","height": "15px","backgroundColor": "#000000","borderWidth": "0.5px","borderColor": "#00ff00","cornerRadius": "2px","offsetTop": "4px","offsetEnd": "24.5px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "𝙸𝙽𝙵𝙾 𝙶𝙴𝙼𝙿𝙰 𝙱𝙼𝙺𝙶","size": "15px","color": "#000000","align": "center","offsetTop": "4px"}],"position": "absolute","width": "140px","height": "30px","backgroundColor": "#ffffff95","offsetTop": "20px","offsetStart": "4px","borderWidth": "0.5px","borderColor": "#00ff00","cornerRadius": "2px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "TEAM TERMUX","size": "15px","color": "#000000","align": "center","offsetTop": "4px"}],"position": "absolute","width": "140px","height": "30px","backgroundColor": "#ffffff95","borderWidth": "0.5px","borderColor": "#00ff00","cornerRadius": "2px","offsetBottom": "20px","offsetEnd": "4px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(data["result"]["tanggal"]),"size": "12px","color": "#000000","align": "center","offsetTop": "3px"}],"position": "absolute","width": "130px","height": "25px","backgroundColor": "#ffffff95","offsetTop": "55px","offsetStart": "12px","borderWidth": "0.5px","borderColor": "#00ff00","cornerRadius": "2px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(data["result"]["wilayah"]),"size": "12px","color": "#000000","align": "center","offsetTop": "3px"}],"position": "absolute","width": "130px","height": "25px","backgroundColor": "#ffffff95","offsetTop": "85px","offsetStart": "12px","borderWidth": "0.5px","borderColor": "#00ff00","cornerRadius": "2px"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "𝙻𝙾𝙺𝙰𝚂𝙸 𝙶𝙴𝙼𝙿𝙰","size": "15px","color": "#00ff00","align": "center"}],"position": "absolute","width": "235px","height": "20px","backgroundColor": "#000000","borderWidth": "0.5px","borderColor": "#00ff00","cornerRadius": "1px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(data["result"]["lokasi"]),"size": "13px","color": "#000000","align": "center","wrap": True}],"position": "absolute","width": "235px","height": "32px","offsetTop": "21px"}],"position": "absolute","width": "235px","height": "55px","backgroundColor": "#ffffff95","borderWidth": "0.5px","borderColor": "#00ff00","cornerRadius": "2px","offsetTop": "119px","offsetStart": "12px"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "𝙰𝚁𝙰𝙷𝙰𝙽 𝙳𝙰𝚁𝙸 𝙱𝙼𝙺𝙶","size": "15px","color": "#00ff00","align": "center"}],"position": "absolute","width": "235px","height": "20px","backgroundColor": "#000000","borderWidth": "0.5px","borderColor": "#00ff00","cornerRadius": "1px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(data["result"]["arahan"]),"size": "13px","color": "#000000","align": "center","wrap": True}],"position": "absolute","width": "235px","height": "32px","offsetTop": "21px"}],"position": "absolute","width": "235px","height": "55px","backgroundColor": "#ffffff95","borderWidth": "0.5px","borderColor": "#00ff00","cornerRadius": "2px","offsetTop": "179px","offsetStart": "12px"},{"type": "box","layout": "vertical","contents": [{"type": "box","layout": "vertical","contents": [{"type": "text","text": "𝚂𝙰𝚁𝙰𝙽 𝚄𝙽𝚃𝚄𝙺 𝚆𝙰𝚁𝙶𝙰","size": "15px","color": "#00ff00","align": "center"}],"position": "absolute","width": "235px","height": "20px","backgroundColor": "#000000","borderWidth": "0.5px","borderColor": "#00ff00","cornerRadius": "1px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(data["result"]["saran"]),"size": "13px","color": "#000000","align": "center","wrap": True}],"position": "absolute","width": "235px","height": "32px","offsetTop": "21px"}],"position": "absolute","width": "235px","height": "55px","backgroundColor": "#ffffff95","borderWidth": "0.5px","borderColor": "#00ff00","cornerRadius": "2px","offsetTop": "239px","offsetStart": "12px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(data["result"]["kekuatan"]),"size": "12px","color": "#000000","align": "center","offsetTop": "4px"}],"position": "absolute","width": "130px","height": "25px","backgroundColor": "#ffffff95","borderWidth": "0.5px","borderColor": "#00ff00","cornerRadius": "2px","offsetBottom": "55px","offsetEnd": "11px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Kedalaman : {}".format(data["result"]["kedalaman"]),"size": "12px","color": "#000000","align": "center","offsetTop": "4px"}],"position": "absolute","width": "130px","height": "25px","backgroundColor": "#ffffff95","borderWidth": "0.5px","borderColor": "#00ff00","cornerRadius": "2px","offsetBottom": "85px","offsetEnd": "11px"}],"paddingAll": "0px","borderWidth": "1px","borderColor": "#00ff00","cornerRadius": "10px"},"action": {"type": "uri","label": "action","uri": "line://nv/profilePopup/mid=u1094909befea4ff8d79d5f71d5356afb"}}}
                           sendTemplate(to, ALVIAN)           

                        elif cmd.startswith('fancytext '):
                          if msg._from in admin:
                           args = text.split(" ")
                           userId = text.replace(args[0] + " ","")
                           api = imjustgood(wait["apikey"])
                           data = api.fancy(userId) 
                           vian = "FANCY RESULT :\n"
                           for s in data["result"]:
                               vian += "\n{}\n".format(s)
                           cl.sendReplyMessage(msg.id,to, str(vian))         

                        elif cmd.startswith('acaratv '):
                          if msg._from in admin:
                           args = text.split(" ")
                           userId = text.replace(args[0] + " ","")
                           api = imjustgood(wait["apikey"])
                           data = api.acaratv_channel(userId) 
                           vian = "Jadwal Acara TV"
                           for a in data["result"]:
                               vian += "\n{}".format(a)
                           cl.sendReplyMessage(msg.id,to, str(vian))    

                        elif cmd == "acara tv":
                          if msg._from in admin:
                           api = imjustgood(wait["apikey"])
                           data   = api.acaratv()
                           result = "ACARA TV"
                           for a in data["result"]:
                               for b in a:
                                   result += "\n\nChannel : {}".format(b)
                                   for c in a[b]:
                                       result += "\n{}".format(c)
                           cl.sendReplyMessage(msg.id,to, str(result))      

                        elif cmd == "lowongan kerja":
                          if msg._from in admin:
                           api = imjustgood(wait["apikey"])
                           data   = api.karir()
                           number = 0
                           apkbot = "INFO LOWONGAN KERJA"
                           for a in data["result"]:
                               number += 1
                               apkbot += "\n\n{}. {}".format(number,a["perusahaan"])
                               apkbot += "\nLokasi : {}".format(a["lokasi"])
                               apkbot += "\nProfesi : {}".format(a["profesi"])
                               apkbot += "\nBagian : {}".format(a["bagian"])
                               apkbot += "\nJabatan : {}".format(a["jabatan"])
                               apkbot += "\nGaji : {}".format(a["gaji"])
                               apkbot += "\nPendidikan : {}".format(a["pendidikan"])
                               apkbot += "\nPengalaman : {}".format(a["pengalaman"])
                               apkbot += "\nSyarat : {}".format(a["syarat"])
                               apkbot += "\nDeskirpsi : {}".format(a["deskripsi"])
                               apkbot += "\nSumber : {}".format(a["sumber"])
                           cl.sendReplyMessage(msg.id,to, str(apkbot))     

                        elif cmd.startswith("zodiak"):
                            if msg._from in admin:
                                set = text.split(" ")
                                search = text.replace(set[0] + " ","")
                                api = imjustgood(wait["apikey"])
                                data = api.zodiac(search)
                                vian = "╭─「 ZODIAK INFO 」"
                                vian += "\n├≽ Sign : {}".format(data["result"]["zodiac"])
                                vian += "\n├≽ Couple : {}".format(data["result"]["couple"])
                                vian += "\n├≽ Date Range : {}".format(data["result"]["date"])
                                vian += "\n├≽ Lucky Color : {}".format(data["result"]["color"])
                                vian += "\n├≽ Lucky Time : {}".format(data["result"]["time"])
                                vian += "\n├≽ Lucky Number : {}".format(data["result"]["number"])
                                vian += "\n├≽ Public : {}".format(data["result"]["public"])
                                vian += "\n├≽ Money : {}".format(data["result"]["money"])
                                vian += "\n├≽ Love Couple : {}".format(data["result"]["love"]["couple"])
                                vian += "\n├≽ Love Single : {}".format(data["result"]["love"]["single"])
                                vian += "\n╰─「 TEAM TERMUX 」"
                                cl.sendReplyMessage(msg.id,to, str(vian)) 

                        elif cmd.startswith('instagram '):
                          if msg._from in admin:
                              try:
                                  args = text.split(" ")
                                  userId = text.replace(args[0] + " ","")
                                  api = imjustgood(wait["apikey"])
                                  data = api.instagram(userId) 
                                  INSTA = {"type": "flex","altText": "TEAM TERMUX","contents": { "type": "bubble", "size": "kilo", "body": { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/wRsdDLx/20211227-001623.png", "size": "full", "aspectMode": "cover", "aspectRatio": "5:6" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "{}".format(data["result"]["picture"]), "size": "full", "aspectRatio": "1:1", "aspectMode": "cover" } ], "position": "absolute", "width": "65px", "height": "65px", "cornerRadius": "50px", "offsetTop": "44px", "offsetStart": "5px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(userId), "size": "14px", "color": "#000000", "align": "center" } ], "position": "absolute", "width": "175px", "height": "20px", "offsetTop": "7px", "offsetStart": "35px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(data["result"]["post"]), "size": "12px", "color": "#000000", "align": "center", "offsetTop": "3px" } ], "position": "absolute", "width": "50px", "height": "20px", "offsetTop": "43px", "offsetStart": "90px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(data["result"]["follower"]), "size": "12px", "color": "#000000", "align": "center", "offsetTop": "3px" } ], "position": "absolute", "width": "50px", "height": "20px", "offsetTop": "43px", "offsetStart": "145px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(data["result"]["following"]), "size": "12px", "color": "#000000", "align": "center", "offsetTop": "3px" } ], "position": "absolute", "width": "50px", "height": "20px", "offsetTop": "43px", "offsetEnd": "8px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "👥 {}".format(data["result"]["username"]), "color": "#000000", "size": "12px" } ], "position": "absolute", "width": "100px", "height": "20px", "offsetTop": "140px", "offsetStart": "5px", "backgroundColor": "#ffffff" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "👥 {}".format(data["result"]["fullname"]), "color": "#000000", "size": "14px" } ], "position": "absolute", "width": "130px", "height": "20px", "offsetTop": "120px", "offsetStart": "5px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "• {}".format(data["result"]["biography"]), "size": "14px", "color": "#000000", "wrap": True } ], "position": "absolute", "width": "170px", "height": "140px", "offsetBottom": "8px", "offsetStart": "5px" } ], "paddingAll": "0px", "borderWidth": "1px", "borderColor": "#000000", "cornerRadius": "10px" }, "action": { "type": "uri", "label": "action", "uri": "line://nv/profilePopup/mid=u1094909befea4ff8d79d5f71d5356afb" } } }
                                  sendTemplate(to, INSTA)           
                              except Exception as error:
                                  cl.sendReplyMessage(msg.id,to,str(error))

                        elif cmd.startswith('google '):
                          if msg._from in admin:
                           args = text.split(" ")
                           userId = text.replace(args[0] + " ","")
                           api = imjustgood(wait["apikey"])
                           data = api.search(userId) 
                           number = 0
                           result = "GOOGLE SEARCH RESULT :"
                           for s in data["result"]:
                               number += 1
                               result += "\n{}. {}".format(number,s["title"])
                               result += "\n{}".format(s["snippet"])
                               result += "\n{}".format(s["url"])
                           cl.sendReplyMessage(msg.id,to, str(result))                  

                        elif cmd.startswith("ponsel"):
                            if msg._from in admin:
                                set = text.split(" ")
                                search = text.replace(set[0] + " ","")
                                api = imjustgood(wait["apikey"])
                                data = api.cellular(search)
                                number = 0
                                vian = "SPESIFIKASI PONSEL\n"
                                for a in data["result"]:
                                    number += 1
                                    vian += "\n• {}. {}\n".format(number,a["brands"])
                                    vian += "\n• Release : {}".format(a["release"])
                                    vian += "\n• Chipset : {}".format(a["chipset"])
                                    vian += "\n• Screen : {}".format(a["screen"])
                                    vian += "\n• Battery : {}".format(a["battery"])
                                    vian += "\n• Display : {}".format(a["display"])
                                    vian += "\n• Ram : {}".format(a["ram"])
                                    vian += "\n• Storage : {}\n".format(a["storage"])
                                cl.sendReplyMessage(msg.id,to, str(vian)) 

                        elif cmd.startswith("cvp: "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                sep = text.split(" ")
                                FckVeza = text.replace(sep[0] + " ","")
                                FckVezaGans = cl.getContact(sender)
                                flexvian(msg.to, "Loading...")
                                pic = "http://dl.profile.line-cdn.net/{}".format(FckVezaGans.pictureStatus)
                                subprocess.getoutput('youtube-dl --format mp4 --output vp.mp4 {}'.format(FckVeza))
                                pict = cl.downloadFileURL(pic)
                                vids = "vp.mp4"
                                changeVideoAndPictureProfile(pict, vids)
                                flexvian(msg.to, "Dual Profile Video ♪")
                                os.remove("vp.mp4")

                        elif "https://vt.tiktok.com/" in msg.text.lower() or "https://www.tiktok.com/" in msg.text.lower() or "https://vm.tiktok.com/" in msg.text.lower():                 
                            if wait["tiktok"] == True:               
                                Bek = text.split(" ")
                                Bebek = text.replace(Bek[0] + " ","")
                                Rambu = urllib.parse.quote(Bebek)
                                headers = {
                                  "User-Agent": "Justgood/5.0",
                                  "apiKey": "Rambu86",
                                  "sysName": "GOOD249"
                                 }
                                main = json.loads(requests.get("https://api.imjustgood.com/tiktokdl="+Bebek,headers=headers).text)
                                video = main["result"]['no_watermark'] 
                                cl.sendMessage(msg.to, "Sedang Download Tiktok")
                                sendFlexVideo(to, video)
                                time.sleep(0.0001)      
                                
                        elif "https://youtu.be/" in msg.text.lower():
                          if wait["yt"] == True:
                              Bek = text.split(" ")
                              Bebek = text.replace(Bek[0] + " ","")
                              Bek = urllib.parse.quote(Bebek)
                              headers = {
                                  "User-Agent": "Justgood/5.0",
                                  "apiKey": "Rambu86",
                                  "sysName": "GOOD249"
                                 }
                              main = json.loads(requests.get("https://api.imjustgood.com/youtubedl="+Bebek,headers=headers).text)
                              video = main["result"]["videoUrl"]
                              cl.sendMessage(msg.to, "Sedang Download Youtube")
                              sendFlexVideo(to, video)
                              time.sleep(0.0001)
                              
                        elif cmd.startswith("resi-sicepat:"):
                          if msg._from in admin:
                            try:
                                memek = text.split(" ")
                                ngewe = text.replace(memek[0] + " ","")
                                api = BEAPI()
                                kontol = api.trackingResi(ngewe,"sicepat")
                                vian  = "{}\n".format(kontol["result"]["summary"]["courier_name"])
                                vian += "Resi : {}\n".format(kontol["result"]["summary"]["waybill_number"])
                                vian += "Tanggall : {}\n".format(kontol["result"]["delivery_status"]["pod_date"])
                                vian += "Jam : {}\n".format(kontol["result"]["delivery_status"]["pod_time"])
                                vian += "Penerima : {}\n".format(kontol["result"]["delivery_status"]["pod_receiver"])
                                vian += "Status : {}\n".format(kontol["result"]["delivery_status"]["status"])
                                for a in kontol["result"]["manifest"]:
                                    vian += "\n\n{}".format(a["manifest_description"])
                                    vian += "\nJam : {}".format(a["manifest_time"])
                                    vian += "\nTanggal :{}".format(a["manifest_date"])
                                    vian += "\nTanggal :{}".format(a["city_name"])
                                cl.sendReplyMessage(msg.id,to, str(vian)) 
                            except Exception as error:
                                cl.sendReplyMessage(msg.id,to, str(error))

                        elif cmd.startswith("auth:"):
                          if msg._from in admin:
                            try:
                                memek = text.split(" ")
                                ngewe = text.replace(memek[0] + " ","")
                                api = BEAPI()
                                kontol = api.authKey2Primary(ngewe)
                                #vian = "ANDROID LITE\n{}\n".format(kontol["result"]["android_lite_token"])
                                #vian += "\nANDROID IOS\n{}".format(kontol["result"]["android_token"])
                                cl.sendReplyMessage(msg.id,to, str(vian)) 
                            except Exception as error:
                                cl.sendReplyMessage(msg.id,to, str(error))

                        elif cmd.startswith("resi-pos:"):
                          if msg._from in admin:
                            try:
                                memek = text.split(" ")
                                ngewe = text.replace(memek[0] + " ","")
                                api = BEAPI()
                                kontol = api.trackingResi(ngewe,"pos")
                                vian  = "{}\n".format(kontol["result"]["summary"]["courier_name"])
                                vian += "Resi : {}\n".format(kontol["result"]["summary"]["waybill_number"])
                                vian += "Tanggall : {}\n".format(kontol["result"]["delivery_status"]["pod_date"])
                                vian += "Jam : {}\n".format(kontol["result"]["delivery_status"]["pod_time"])
                                vian += "Penerima : {}\n".format(kontol["result"]["delivery_status"]["pod_receiver"])
                                vian += "Status : {}\n".format(kontol["result"]["delivery_status"]["status"])
                                for a in kontol["result"]["manifest"]:
                                    vian += "\n\n{}".format(a["manifest_description"])
                                    vian += "\nJam : {}".format(a["manifest_time"])
                                    vian += "\nTanggal :{}".format(a["manifest_date"])
                                    vian += "\nTanggal :{}".format(a["city_name"])
                                cl.sendReplyMessage(msg.id,to, str(vian)) 
                            except Exception as error:
                                cl.sendReplyMessage(msg.id,to, str(error))

                        elif cmd.startswith("resi-rex:"):
                          if msg._from in admin:
                            try:
                                memek = text.split(" ")
                                ngewe = text.replace(memek[0] + " ","")
                                api = BEAPI()
                                kontol = api.trackingResi(ngewe,"rex")
                                vian  = "{}\n".format(kontol["result"]["summary"]["courier_name"])
                                vian += "Resi : {}\n".format(kontol["result"]["summary"]["waybill_number"])
                                vian += "Tanggall : {}\n".format(kontol["result"]["delivery_status"]["pod_date"])
                                vian += "Jam : {}\n".format(kontol["result"]["delivery_status"]["pod_time"])
                                vian += "Penerima : {}\n".format(kontol["result"]["delivery_status"]["pod_receiver"])
                                vian += "Status : {}\n".format(kontol["result"]["delivery_status"]["status"])
                                for a in kontol["result"]["manifest"]:
                                    vian += "\n\n{}".format(a["manifest_description"])
                                    vian += "\nJam : {}".format(a["manifest_time"])
                                    vian += "\nTanggal :{}".format(a["manifest_date"])
                                    vian += "\nTanggal :{}".format(a["city_name"])
                                cl.sendReplyMessage(msg.id,to, str(vian)) 
                            except Exception as error:
                                cl.sendReplyMessage(msg.id,to, str(error))

                        elif cmd.startswith("resi-jnt:"):
                          if msg._from in admin:
                            try:
                                memek = text.split(" ")
                                ngewe = text.replace(memek[0] + " ","")
                                api = BEAPI()
                                kontol = api.trackingResi(ngewe,"jnt")
                                vian  = "{}\n".format(kontol["result"]["summary"]["courier_name"])
                                vian += "Resi : {}\n".format(kontol["result"]["summary"]["waybill_number"])
                                vian += "Tanggall : {}\n".format(kontol["result"]["delivery_status"]["pod_date"])
                                vian += "Jam : {}\n".format(kontol["result"]["delivery_status"]["pod_time"])
                                vian += "Penerima : {}\n".format(kontol["result"]["delivery_status"]["pod_receiver"])
                                vian += "Status : {}\n".format(kontol["result"]["delivery_status"]["status"])
                                for a in kontol["result"]["manifest"]:
                                    vian += "\n\n{}".format(a["manifest_description"])
                                    vian += "\nJam : {}".format(a["manifest_time"])
                                    vian += "\nTanggal :{}".format(a["manifest_date"])
                                    vian += "\nTanggal :{}".format(a["city_name"])
                                cl.sendReplyMessage(msg.id,to, str(vian)) 
                            except Exception as error:
                                cl.sendReplyMessage(msg.id,to, str(error))

                        elif cmd.startswith("resi-ninja:"):
                          if msg._from in admin:
                            try:
                                memek = text.split(" ")
                                ngewe = text.replace(memek[0] + " ","")
                                api = BEAPI()
                                kontol = api.trackingResi(ngewe,"ninja")
                                vian  = "{}\n".format(kontol["result"]["summary"]["courier_name"])
                                vian += "Resi : {}\n".format(kontol["result"]["summary"]["waybill_number"])
                                vian += "Tanggall : {}\n".format(kontol["result"]["delivery_status"]["pod_date"])
                                vian += "Jam : {}\n".format(kontol["result"]["delivery_status"]["pod_time"])
                                vian += "Penerima : {}\n".format(kontol["result"]["delivery_status"]["pod_receiver"])
                                vian += "Status : {}\n".format(kontol["result"]["delivery_status"]["status"])
                                for a in kontol["result"]["manifest"]:
                                    vian += "\n\n{}".format(a["manifest_description"])
                                    vian += "\nJam : {}".format(a["manifest_time"])
                                    vian += "\nTanggal :{}".format(a["manifest_date"])
                                    vian += "\nTanggal :{}".format(a["city_name"])
                                cl.sendReplyMessage(msg.id,to, str(vian)) 
                            except Exception as error:
                                cl.sendReplyMessage(msg.id,to, str(error))

                        elif cmd.startswith("smuleprofile:"):
                           if msg._from in admin:
                                set = text.split(" ")
                                mod = text.replace(set[0] + " ","")
                                api = BEAPI()
                                kontol = api.smuleUser(mod)
                                SMULE = {"type": "flex","altText": "TEAM TERMUX","contents": { "type": "bubble", "size": "micro", "body": { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "https://i.ibb.co/qpFCZzz/ezgif-com-gif-maker-41.png", "size": "full", "aspectMode": "cover", "aspectRatio": "2:3" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "image", "url": "{}".format(kontol["result"]["pic_url"]), "size": "full", "aspectRatio": "1:1", "aspectMode": "cover" } ], "position": "absolute", "width": "65px", "height": "65px", "backgroundColor": "#000000", "cornerRadius": "50px", "offsetTop": "32.2px", "offsetStart": "20px", "borderWidth": "0.5px", "borderColor": "#000000" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(kontol["result"]["handle"]), "size": "15px", "color": "#ffffff", "align": "center", "offsetBottom": "-1px" } ], "position": "absolute", "width": "129px", "height": "20px", "backgroundColor": "#000000", "borderWidth": "0.5px", "borderColor": "#00ff00", "cornerRadius": "2px", "offsetTop": "125px", "offsetStart": "15px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(mod), "size": "10px", "color": "#ffffff", "align": "center" } ], "position": "absolute", "width": "120px", "height": "15px", "offsetTop": "5px", "offsetStart": "15px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "FOLLOWER", "size": "9px", "color": "#ffffff", "align": "center", "offsetTop": "1.5px" } ], "position": "absolute", "width": "50px", "height": "15px", "offsetTop": "45px", "offsetEnd": "14px", "borderWidth": "0.5px", "borderColor": "#00ff00", "cornerRadius": "2px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(kontol["result"]["followers"]), "size": "10px", "color": "#ffffff", "align": "center" } ], "position": "absolute", "width": "50px", "height": "25px", "offsetTop": "32px", "offsetEnd": "15px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "FOLLOWING", "size": "9px", "color": "#ffffff", "align": "center", "offsetTop": "2px" } ], "position": "absolute", "width": "50px", "height": "15px", "offsetTop": "77px", "offsetEnd": "14px", "borderWidth": "0.5px", "borderColor": "#00ff00", "cornerRadius": "2px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(kontol["result"]["followees"]), "size": "10px", "color": "#ffffff", "align": "center" } ], "position": "absolute", "width": "50px", "height": "25px", "offsetTop": "64px", "offsetEnd": "15px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "PERFORMANCE", "size": "9px", "color": "#ffffff", "align": "center", "offsetTop": "2px" } ], "position": "absolute", "width": "70px", "height": "15px", "offsetTop": "107px", "offsetEnd": "14px", "borderWidth": "0.5px", "borderColor": "#00ff00", "cornerRadius": "2px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(kontol["result"]["num_performances"]), "size": "10px", "color": "#ffffff", "align": "center" } ], "position": "absolute", "width": "50px", "height": "25px", "offsetTop": "94px", "offsetEnd": "15px" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "HASTAG / PENYEBUTAN", "size": "10px", "color": "#ffffff", "align": "center" } ], "position": "absolute", "width": "130px", "height": "15px", "backgroundColor": "#00ff0050" }, { "type": "box", "layout": "vertical", "contents": [ { "type": "text", "text": "{}".format(kontol["result"]["blurb"]), "size": "10px", "color": "#00ff00", "align": "center", "wrap": True } ], "position": "absolute", "offsetTop": "16px", "width": "130px", "height": "42px" } ], "position": "absolute", "width": "130px", "height": "58px", "offsetBottom": "8px", "offsetStart": "14px", "backgroundColor": "#000000" } ], "paddingAll": "0px", "borderWidth": "1px", "borderColor": "#00ff00", "cornerRadius": "10px" }, "action": { "type": "uri", "label": "action", "uri": "line://nv/profilePopup/mid=u1094909befea4ff8d79d5f71d5356afb" } } }
                                sendTemplate(to, SMULE)           

                        elif cmd.startswith("smule:"):
                           if msg._from in admin:
                                set = text.split(" ")
                                mod = text.replace(set[0] + " ","")
                                mode = mod.split("|")
                                search = str(mode[0])
                                api = BEAPI()
                                res = api.smulePerformance(search)
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                if len(mode) == 1:
                                    num = 0
                                    ret_ = "SMULE SONG LIST\n"
                                    for youtube in res["result"]:
                                        num += 1
                                        ret_ += "\n•{}. {}".format(str(num), str(youtube["title"]))
                                    ret_ += "\nEXAMPLE PLAY"
                                    ret_ += "\n{} | No urutuan di atas ".format(str(text))
                                    cl.sendReplyMessage(msg.id,to, str(ret_))
                                elif len(mode) == 2:
                                    num = int(mode[1])
                                    if num <= len(res["result"]):
                                        pixel = res["result"][num - 1]
                                        Zulkifli = {"type": "flex","altText": "TEAM TERMUX","contents": {"type": "bubble","size": "kilo","body": {"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/rsZLzqS/20211221-150355.png","size": "full","aspectMode": "cover","aspectRatio": "2:1"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/sHSrqfz/ezgif-com-gif-to-apng-4.png","size": "full","aspectRatio": "2:3","aspectMode": "cover","animated": True}],"position": "absolute","width": "50px","height": "70px","offsetBottom": "25px","offsetEnd": "43px"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "{}".format(str(pixel["cover_url"])),"size": "full","aspectRatio": "1:1","aspectMode": "cover"}],"width": "53.5px","height": "53.5px","backgroundColor": "#000000","offsetBottom": "7px","offsetStart": "10.5px","position": "absolute","cornerRadius": "1px"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/YZCtzzG/ezgif-com-gif-maker-32.png","aspectRatio": "1:1","aspectMode": "cover","animated": True,"size": "full","offsetBottom": "15px"}],"position": "absolute","width": "100px","height": "40px","offsetTop": "26px","offsetStart": "100px"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/KbfDFN1/1657636839741.jpg","size": "full","aspectRatio": "1:1","aspectMode": "cover"}],"position": "absolute","width": "32px","height": "32px","backgroundColor": "#000000","offsetTop": "2px","offsetEnd": "13px","cornerRadius": "1px"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/KbfDFN1/1657636839741.jpg","size": "full","aspectRatio": "1:1","aspectMode": "cover","animated": True}],"position": "absolute","width": "29px","height": "29px","backgroundColor": "#000000","cornerRadius": "50px","offsetTop": "38.5px","offsetEnd": "10.5px"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/KbfDFN1/1657636839741.jpg","size": "full","aspectRatio": "1:1","aspectMode": "cover","animated": True}],"position": "absolute","width": "29px","height": "29px","backgroundColor": "#000000","cornerRadius": "50px","offsetTop": "71.5px","offsetEnd": "10px"},{"type": "box","layout": "vertical","contents": [{"type": "image","url": "https://i.ibb.co/XtDjDb8/ezgif-com-gif-maker-25.png","aspectRatio": "1:1","aspectMode": "cover","animated": True,"size": "100px","offsetBottom": "55px"}],"position": "absolute","width": "130px","height": "40px","offsetStart": "55px","offsetBottom": "26px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "NOTIFED SMULE DOWNLOAD","size": "9px","color": "#ffffff","align": "center","offsetTop": "3px"}],"position": "absolute","width": "128px","height": "20px","backgroundColor": "#000000","borderWidth": "1px","borderColor": "#ff0000","cornerRadius": "2px","offsetBottom": "3px","offsetStart": "70px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "TEAM TERMUX","size": "10px","color": "#ffffff","align": "center","offsetTop": "2px"}],"position": "absolute","width": "90px","height": "18px","backgroundColor": "#000000","borderWidth": "1px","borderColor": "#ff0000","cornerRadius": "2px","offsetTop": "2px","offsetStart": "5px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "SELAMAT MENDENGARKAN","size": "8px","color": "#ffffff","align": "center","offsetTop": "3px"}],"position": "absolute","width": "110px","height": "18px","backgroundColor": "#000000","borderWidth": "1px","borderColor": "#ff0000","cornerRadius": "2px","offsetTop": "4px","offsetStart": "100px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": " "+ datetime.strftime(timeNow,'%H:%M:%S'),"size": "10px","color": "#ffffff","align": "center","offsetTop": "1px"}],"position": "absolute","width": "90px","height": "17px","backgroundColor": "#00000080","borderWidth": "1px","borderColor": "#ff0000","cornerRadius": "2px","offsetTop": "25px","offsetStart": "5px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": " "+ datetime.strftime(timeNow,'%Y-%m-%d'),"size": "10px","color": "#ffffff","align": "center","offsetTop": "1px"}],"position": "absolute","width": "90px","height": "17px","backgroundColor": "#00000080","borderWidth": "1px","borderColor": "#ff0000","cornerRadius": "2px","offsetTop": "43px","offsetStart": "5px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Like: {}".format(pixel["stats"]["total_loves"]),"size": "10px","color": "#ffffff","align": "center","offsetTop": "1px"}],"position": "absolute","width": "100px","height": "17px","backgroundColor": "#00000080","borderWidth": "1px","borderColor": "#ff0000","cornerRadius": "2px","offsetTop": "30px","offsetStart": "100px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Playing: {}".format(pixel["stats"]["total_listens"]),"size": "10px","color": "#ffffff","align": "center","offsetTop": "1px"}],"position": "absolute","width": "100px","height": "17px","backgroundColor": "#00000080","borderWidth": "1px","borderColor": "#ff0000","cornerRadius": "2px","offsetTop": "50px","offsetStart": "100px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "Comment: {}".format(pixel["stats"]["total_comments"]),"size": "10px","color": "#ffffff","align": "center"}],"position": "absolute","width": "125px","height": "15px","backgroundColor": "#00000080","borderWidth": "1px","borderColor": "#ff0000","cornerRadius": "2px","offsetTop": "69px","offsetStart": "75px"},{"type": "box","layout": "vertical","contents": [{"type": "text","text": "{}".format(pixel["title"]),"size": "10px","color": "#ffffff","align": "center"}],"position": "absolute","width": "125px","height": "15px","backgroundColor": "#00000080","borderWidth": "1px","borderColor": "#ff0000","cornerRadius": "2px","offsetTop": "87px","offsetStart": "75px"}],"paddingAll": "0px","borderWidth": "1px","borderColor": "#ff0000","cornerRadius": "10px"},"action": {"type": "uri","label": "action","uri": "line://nv/profilePopup/mid=u1094909befea4ff8d79d5f71d5356afb"}}}
                                        sendTemplate(to, Zulkifli)           
                                        if pixel['type'] == "audio":
                                            sendFlexAudio(to, "{}".format(pixel["media_url"]))
                                        else:
                                            sendFlexVideo(to, "{}".format(pixel["video_media_url"]))
                                                                                    
                        elif cmd.startswith("gnamegrup"):
                          if msg._from in admin:
                            if msg.toType == 2:
                                X = cl.getGroup(to)
                                X.name = text.split(" ")
                                cl.updateGroup(X)
                                                               
                        elif cmd.startswith("spamtag "):
                          if msg._from in admin:
                            text_ = cmd.replace("spamtag ", "")
                            cond = text_.split(" ")
                            text = text_.replace(cond[0] + " ", "")
                            jml = int(cond[0])
                            if msg.contentMetadata is not None  and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = cl.getContact(ls)
                                    text = text.replace("@{}".format(str(contact.displayName)),"")
                                if "|" in text:
                                    cond = text.split("|")
                                    fm = cond[0]
                                    lm = cond[1]
                                else:
                                    fm = ""
                                    lm = text
                                for ls in lists:
                                    for x in range(jml):
                                        sendMention(to, ls, str(fm), str(lm))
                                sendFoter(msg.to, "「 Succes tag {} user , with amount {} tags 」".format(str(len(lists)), str(jml)))
                                return
                            else:
                                flexvian(msg.to, "Nothing user :v")
                                return
                                    
                        elif cmd.startswith("call "):
                          if msg._from in admin:
                            if msg.contentMetadata is not None  and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                group = cl.getGroup(to)
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    for var in range(0,500):                                        	
                                        cl.acquireGroupCallRoute(to)                                            
                                        members = [ls for ls in lists]
                                        cl.inviteIntoGroupCall(to, contactIds=members)
                                    try:
                                        flex2(msg.to,"Success 500 invite call group")
                                        break
                                    except Exception as error:
                                        logError(error)                     
                             
                        elif cmd.startswith("block "):
                          if msg._from in admin:
                            if msg.contentMetadata is not None  and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = cl.getContact(ls)
                                    cl.blockContact(ls)
                                flex2(msg.to, "Success add " + str(contact.displayName) + " to Blocklist")



                        elif cmd == "change vp":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["changevp"] = True
                                flexvian(msg.to, "Kirim Video ny")
                                
                        elif cmd.startswith("scall "):
                          if msg._from in admin:
                            sep = text.split(" ")
                            num = int(sep[1])
                            try:                           
                                if msg.contentMetadata is not None  and 'MENTION' in msg.contentMetadata:
                                    names = re.findall(r'@(\w+)', text)
                                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                    mentionees = mention['MENTIONEES']
                                    lists = []
                                    for mention in mentionees:
                                        if mention["M"] not in lists:
                                            lists.append(mention["M"])
                                    for ls in lists:
                                        for var in range(0,num):
                                            group = cl.getGroup(to)
                                            members = [ls]
                                            kunkun = cl.getContact("u1094909befea4ff8d79d5f71d5356afb").displayName
                                            cl.acquireGroupCallRoute(to)
                                            cl.inviteIntoGroupCall(to, contactIds=members)
                                        flex2(msg.to, "Success Invite Groups Call")
                            except Exception as error:
                                flexvian(to, str(error))
                                                                                                             
                        elif cmd.startswith("jumlah: "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                                proses = text.split(":")
                                strnum = text.replace(proses[0] + ":","")
                                num =  int(strnum)
                                Setmain["RAlimit"] = num
                                flexvian(msg.to,"Changed to " +strnum)

                        elif cmd.startswith("spamcall: "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                                proses = text.split(":")
                                strnum = text.replace(proses[0] + ":","")
                                num =  int(strnum)
                                wait["limit"] = num
                                flexvian(msg.to,"Changed to " +strnum)

                        elif cmd.startswith("spamtag "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                                if msg.contentMetadata is not None  and 'MENTION' in msg.contentMetadata:
                                    key = eval(msg.contentMetadata["MENTION"])
                                    key1 = key["MENTIONEES"][0]["M"]
                                    zx = ""
                                    zxc = " "
                                    zx2 = []
                                    pesan2 = "@a"" "
                                    xlen = str(len(zxc))
                                    xlen2 = str(len(zxc)+len(pesan2)-1)
                                    zx = {'S':xlen, 'E':xlen2, 'M':key1}
                                    zx2.append(zx)
                                    zxc += pesan2
                                    msg.contentType = 0
                                    msg.text = zxc
                                    lol = {'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}
                                    msg.contentMetadata = lol
                                    jmlh = int(Setmain["RAlimit"])
                                    if jmlh <= 1000:
                                        for x in range(jmlh):
                                            try:
                                                cl.sendMessage1(msg)
                                            except Exception as e:
                                                cl.sendText(msg.to,str(e))
                                    else:
                                        cl.sendText(msg.to,"Jumlah melebihi 1000")
        
                        elif cmd.startswith('pict '):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                               res = '╭───「 Picture Status 」'
                               no = 0
                               if msg.contentMetadata is not None  and 'MENTION' in msg.contentMetadata:
                                   mentions = ast.literal_eval(msg.contentMetadata['MENTION'])
                                   if len(mentions['MENTIONEES']) == 1:
                                       profile = cl.getContact(mentions['MENTIONEES'][0]['M'])
                                       if profile.pictureStatus:
                                           path = 'http://dl.profile.line-cdn.net/' + profile.pictureStatus
                                           cl.sendImageWithURL(to, path)
                                       else:
                                           flex2(to, 'Failed steal picture status, user `%s` doesn\'t have a picture status' % profile.displayName)
                                
                        elif cmd.startswith('cover '):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                               res = '╭───「 Picture Cover 」'
                               no = 0
                               if msg.contentMetadata is not None  and 'MENTION' in msg.contentMetadata:
                                   mentions = ast.literal_eval(msg.contentMetadata['MENTION'])
                                   if len(mentions['MENTIONEES']) == 1:
                                       mid = mentions['MENTIONEES'][0]['M']
                                       cover = cl.getProfileCoverURL(mid)
                                       cl.sendImageWithURL(to, cover)
                                   else:
                                       flex2(to, 'Failed steal picture status, user `%s` doesn\'t have a picture status' % profile.displayName)
                                    
                        elif cmd.startswith("video "):
                          if msg._from in admin:  
                            if msg.contentMetadata is not None  and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = cl.getContact(ls)
                                    if contact.videoProfile == None:
                                    	continue
                                    path = "http://dl.profile.line-cdn.net/" + contact.pictureStatus + "/vp"
                                    cl.sendVideoWithURL(to, str(path))
                                                                            
                        elif cmd.startswith("name "):
                          if msg._from in admin:  
                            if msg.contentMetadata is not None  and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = cl.getContact(ls)
                                    sendFoter(msg.to, "[ Display Name ]\n{}".format(str(contact.displayName)))
                                    
                        elif cmd.startswith("bio "):
                          if msg._from in admin:  
                            if msg.contentMetadata is not None  and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = cl.getContact(ls)
                                    sendFoter(msg.to, "[ Status Message ]\n{}".format(str(contact.statusMessage)))
                                
                        elif cmd.startswith("addfriend "):
                          if msg._from in admin:  
                            if msg.contentMetadata is not None  and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = cl.getContact(ls)
                                    cl.findAndAddContactsByMid(ls)
                                flex2(msg.to, "Success Add " + str(contact.displayName) + " to Friendlist")
                                
                        elif cmd.startswith("ulti "):
                          if msg._from in admin:  
                            if msg.contentMetadata is not None  and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    try:
                                        cl.kickoutFromGroup(to, [ls])
                                        cl.inviteIntoGroup(to, [ls])
                                        cl.cancelGroupInvitation(to, [ls])
                                    except:
                                       flexvian(msg.to, "Limited !")
      
                        elif cmd.startswith("invite "):
                                if msg._from in creator or msg._from in owner or msg._from in admin:
                                    key = eval(msg.contentMetadata["MENTION"])
                                    key["MENTIONEES"][0]["M"]
                                    targets = []
                                    for x in key["MENTIONEES"]:
                                        targets.append(x["M"])
                                    for target in targets:                                                                            
                                        try:      
                                            cl.findAndAddContactsByMid(target)
                                            cl.inviteIntoGroup(to,[target])                                             
                                        except:
                                            pass

                        elif cmd == "spamcall":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                             if msg.toType == 2:
                                group = cl.getGroup(to)
                                members = [mem.mid for mem in group.members]
                                jmlh = int(wait["limit"])
                                flexvian(msg.to, "Success {} Call Groups".format(str(wait["limit"])))
                                if jmlh <= 1000:
                                  for x in range(jmlh):
                                     try:
                                        cl.acquireGroupCallRoute(to)
                                        cl.inviteIntoGroupCall(to, contactIds=members)
                                     except Exception as e:
                                        cl.sendText(msg.to,str(e))
                                else:
                                    cl.sendText(msg.to,"Jumlah melebihi batas")

                        elif cmd == "kontak1 on" or text.lower() == 'kontak1 on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["contact"] = True
                                cl.sendMessage(msg.to, "Deteksi contact diaktifkan")

                        elif cmd == "kontak1 off" or text.lower() == 'kontak1 off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["contact"] = False
                                cl.sendMessage(msg.to, "Deteksi contact dinonaktifkan")

                        elif cmd.startswith("spamcall "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                proses = text.split(" ")
                                strnum = text.replace(proses[0] + " ","")
                                group = cl.getGroup(to)
                                members = [mem.mid for mem in group.members]
                                flexvian(msg.to,"Success {} Call Groups".format(str(strnum)))
                                jumlah = int(strnum)
                                if jumlah <= 1000:
                                   for x in range(jumlah):
                                   	try:
                                           cl.acquireGroupCallRoute(to)
                                           cl.inviteIntoGroupCall(to, contactIds=members)
                                   	except Exception as e:
                                          cl.sendText(msg.to,str(e))

                        elif 'Gift: ' in msg.text:
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              korban = msg.text.replace('Gift: ','')
                              korban2 = korban.split()
                              midd = korban2[0]
                              jumlah = int(korban2[1])
                              if jumlah <= 1000:
                                  for var in range(0,jumlah):
                                      cl.sendMessage(midd, None, contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58', 'PRDTYPE': 'THEME', 'MSGTPL': '6'}, contentType=9)

                        elif 'Spam: ' in msg.text:
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              korban = msg.text.replace('Spam: ','')
                              korban2 = korban.split()
                              midd = korban2[0]
                              jumlah = int(korban2[1])
                              if jumlah <= 1000:
                                  for var in range(0,jumlah):
                                      sendFoter(midd, str(Setmain["RAmessage1"]))

                        elif cmd.startswith("idline: "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                               try:
                                   sep = text.split(" ")
                                   kontoll = text.replace(sep[0] + " ","")
                                   memek = cl.findContactsByUserid(kontoll)
                                   if True:
                                       cl.sendReplyMessage(msg.id,to, "http://line.me/ti/p/~" + kontoll)
                                       cl.sendMessage(msg.to, None, contentMetadata={'mid': memek.mid}, contentType=13)
                               except:
                                   cl.sendReplyMessage(msg.id,to, "Invalid Line Id !")

                        elif msg.text.lower() in tes["Message"]:
                            if wait["autotext"] == True:
                                sid = tes["Message"][msg.text.lower()]
                                cl.sendReplyMessage(msg.id, to, sid)     
                                    
                        elif msg.text.lower() in wait["stickers"]:
                           if wait["apkTikel"] == True:
                             if msg.text.lower() in wait["stickers"]:
                                 sid = wait["stickers"][msg.text.lower()]["STKID"]
                                 data = {"type": "template","altText": "Sticker","baseSize": { "height": 500, "width": 500 }, "template": {"type": "image_carousel","columns": [{"imageUrl": "https://stickershop.line-scdn.net/stickershop/v1/sticker/{}/IOS/sticker_animation@2x.png".format(sid), "action": {"type": "uri","uri": "line://ti/p/~linux.1","area": {"x": 500,"y": 0,"width": 500,"height": 500}}}]}}
                                 sendTemplate(to, data)      
                                    
                        elif cmd.startswith("dellsticker: "):
                          if msg._from in admin:
                                proses = text.split(" ")
                                nama = text.replace(proses[0] + " ","")
                                try:
                                    if nama not in wait["stickers"]:
                                        flexvian(msg.to,"List Sticker Kosong.")
                                    else:
                                        del wait["stickers"][nama]
                                        f=codecs.open("sticker.json","w","utf-8")
                                        json.dump(wait, f, sort_keys=True, indent=4,ensure_ascii=False)
                                        flexvian(msg.to,"Hapus Sticker ✓")
                                except Exception as e:
                                    cl.sendMessage(msg.to,"{}".format(str(e)))
                                    
                        elif cmd.startswith("stickerlist"):
                          if msg._from in admin:
                                if wait["stickers"] == {}:
                                    flex3(msg.to,"Nothing sticker")
                                else:
                                    no = 0
                                    ret_ = "List\n"
                                    for a in wait["stickers"]:
                                        no += 1
                                        ret_ += "\n" +str(no)+". " +str(a)
                                    ret_ += "\n\nList %i Sticker" % len(wait["stickers"])
                                    flex2(to, ret_)  
  
                        elif cmd.startswith("addsticker: "):
                          if msg._from in admin:
                                proses = text.split(" ")
                                nama = text.replace(proses[0] + " ","")
                                try:
                                    if nama in wait["stickers"]:
                                        flexvian(msg.to,"Sudah ada dalam list")
                                    else:
                                        wait["stk"] = nama
                                        wait["sticker"] = True
                                        f=codecs.open("sticker.json","w","utf-8")
                                        json.dump(wait, f, sort_keys=True, indent=4,ensure_ascii=False)
                                        flexvian(msg.to,"Send a stickers ✓")
                                except Exception as e:
                                    cl.sendMessage(msg.to,"{}".format(str(e)))
                   
#===========Protection============#
                        elif cmd.startswith("welcomemsg "):
                           if msg._from in admin:
                              vian = text.split(" ")
                              spl = text.replace(vian[0] + " ","")
                              if spl == 'on':
                                  if msg.to in welcome:
                                       msgs = "Welcome Sudah Aktif ♪"
                                  else:
                                       welcome.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "Leave Msg diaktifkan\nDi Group : " +str(ginfo.name)
                                  flexvian(msg.to, "Welcome Enable ✓")
                              elif spl == 'off':
                                    if msg.to in welcome:
                                         welcome.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Leave Msg dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Leave Msg sudah tidak aktif"
                                    flexvian(msg.to, "Welcome Disable ✓")

                                
                        elif cmd.startswith("leavemsg "):
                           if msg._from in admin:
                              vian = text.split(" ")
                              spl = text.replace(vian[0] + " ","")
                              if spl == 'on':
                                  if msg.to in leave:
                                       msgs = "Leave Msg sudah aktif"
                                  else:
                                       leave.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "Leave Msg diaktifkan\nDi Group : " +str(ginfo.name)
                                  flexvian(msg.to, "Leave Msg Enable ✓")
                              elif spl == 'off':
                                    if msg.to in leave:
                                         leave.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Leave Msg dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Leave Msg sudah tidak aktif"
                                    flexvian(msg.to, "Leave Msg Disable ✓")

                        elif cmd.startswith("pqr "):
                           if msg._from in admin:
                              vian = text.split(" ")
                              spl = text.replace(vian[0] + " ","")
                              if spl == 'on':
                                  if msg.to in protectqr:
                                       msgs = "Protect url sudah aktif"
                                  else:
                                       protectqr.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "Protect url diaktifkan\nDi Group : " +str(ginfo.name)
                                  flex2(msg.to, "「Enable」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectqr:
                                         protectqr.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Protect url dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect url sudah tidak aktif"
                                    flex2(msg.to, "「Disable」\n" + msgs)

                        elif cmd.startswith("pkick "):
                           if msg._from in admin:
                              vian = text.split(" ")
                              spl = text.replace(vian[0] + " ","")
                              if spl == 'on':
                                  if msg.to in protectkick:
                                       msgs = "Protect kick sudah aktif"
                                  else:
                                       protectkick.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "Protect kick diaktifkan\nDi Group : " +str(ginfo.name)
                                  flex3(msg.to, "「Enable」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectkick:
                                         protectkick.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Protect kick dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect kick sudah tidak aktif"
                                    flex2(msg.to, "「Disable」\n" + msgs)

                        elif cmd.startswith("pjoin "):
                           if msg._from in admin:
                              vian = text.split(" ")
                              spl = text.replace(vian[0] + " ","")
                              if spl == 'on':
                                  if msg.to in protectjoin:
                                       msgs = "Protect join sudah aktif"
                                  else:
                                       protectjoin.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "Protect join diaktifkan\nDi Group : " +str(ginfo.name)
                                  flex2(msg.to, "「Enable」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectjoin:
                                         protectjoin.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Protect join dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect join sudah tidak aktif"
                                    flex2(msg.to, "「Disable」\n" + msgs)

                        elif cmd.startswith("pcancell "):
                           if msg._from in admin:
                              vian = text.split(" ")
                              spl = text.replace(vian[0] + " ","")
                              if spl == 'on':
                                  if msg.to in protectcancel:
                                       msgs = "Protect cancel sudah aktif"
                                  else:
                                       protectcancel.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "Protect cancel diaktifkan\nDi Group : " +str(ginfo.name)
                                  flex2(msg.to, "「Enable」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectcancel:
                                         protectcancel.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Protect cancel dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect cancel sudah tidak aktif"
                                    flex2(msg.to, "「Disable」\n" + msgs)

                        elif cmd.startswith("pinvite "):
                           if msg._from in admin:
                              vian = text.split(" ")
                              spl = text.replace(vian[0] + " ","")
                              if spl == 'on':
                                  if msg.to in protectinvite:
                                       msgs = "Protect invite sudah aktif"
                                  else:
                                       protectinvite.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "Protect in : " +str(ginfo.name)
                                  flex2(msg.to, "Activated\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectinvite:
                                         protectinvite.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Protect invite dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect invite sudah tidak aktif"
                                    flex2(msg.to, "「Disable」\n" + msgs)

                        elif cmd.startswith("maxpro "):
                           if msg._from in admin:
                              vian = text.split(" ")
                              spl = text.replace(vian[0] + " ","")
                              if spl == 'on':
                                  if msg.to in protectqr:
                                       msgs = ""
                                  else:
                                       protectqr.append(msg.to)
                                  if msg.to in protectkick:
                                      msgs = ""
                                  else:
                                      protectkick.append(msg.to)
                                  if msg.to in protectjoin:
                                      msgs = ""
                                  else:
                                      protectjoin.append(msg.to)
                                  if msg.to in protectcancel:
                                      ginfo = cl.getGroup(msg.to)
                                      msgs = "Max protection enable "
                                  else:
                                      protectcancel.append(msg.to)
                                      ginfo = cl.getGroup(msg.to)
                                      msgs = "Max protection allready On"
                                  flex2(msg.to, "Type Protection\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectqr:
                                         protectqr.remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in protectkick:
                                         protectkick.remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in protectjoin:
                                         protectjoin.remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in protectcancel:
                                         protectcancel.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Max protection Disable"
                                    else:
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Max protection allready disble"
                                    flex2(msg.to, "Type Protection\n" + msgs)

#===========KICKOUT============#

                        elif cmd.startswith(comd["kick"]):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Bots:
                                       try:
                                           cl.kickoutFromGroup(msg.to, [target])
                                       except:
                                           pass

#===========ADMIN ADD============#
                        elif cmd.startswith("adminadd "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           admin.append(target)
                                           flexvian(msg.to,"Add To Adminlist ✓")
                                       except:
                                           pass

                        elif cmd.startswith("staffadd "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           staff.append(target)
                                           flexvian(msg.to,"Add To Stafflist ✓")
                                       except:
                                           pass

                        elif cmd.startswith("botadd "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           Bots.append(target)
                                           flexvian(msg.to,"Add To Lisbot ✓")
                                       except:
                                           pass

                        elif cmd.startswith("admindell "):
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Alvian:
                                       try:
                                           admin.remove(target)
                                           flexvian(msg.to,"Delete Admin ✓")
                                       except:
                                           pass

                        elif cmd.startswith("staffdell "):
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Alvian:
                                       try:
                                           staff.remove(target)
                                           flexvian(msg.to,"Delete Staff ✓")
                                       except:
                                           pass

                        elif cmd.startswith("botdell "):
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Alvian:
                                       try:
                                           Bots.remove(target)
                                           flexvian(msg.to,"delete Botlist ✓")
                                       except:
                                           pass
                                           
                        elif cmd == "admin:on" or text.lower() == 'admin:on':
                            if msg._from in admin:
                                wait["addadmin"] = True
                                flexvian(msg.to,"Send Contact ✓")

                        elif cmd == "admin:repeat" or text.lower() == 'admin:repeat':
                            if msg._from in admin:
                                wait["delladmin"] = True
                                flexvian(msg.to,"Send Contact ✓")

                        elif cmd == "staff:on" or text.lower() == 'staff:on':
                            if msg._from in admin:
                                wait["addstaff"] = True
                                flexvian(msg.to,"Send Contact ✓")

                        elif cmd == "staff:repeat" or text.lower() == 'staff:repeat':
                            if msg._from in admin:
                                wait["dellstaff"] = True
                                flexvian(msg.to,"Send Contact ✓")

                        elif cmd == "bot:on" or text.lower() == 'bot:on':
                            if msg._from in admin:
                                wait["addbots"] = True
                                flexvian(msg.to,"Send Contact ✓")

                        elif cmd == "bot:repeat" or text.lower() == 'bot:repeat':
                            if msg._from in admin:
                                wait["dellbots"] = True
                                flexvian(msg.to,"Send Contact ✓")

                        elif cmd == "refresh" or text.lower() == 'abort':
                            if msg._from in admin:
                                wait["addadmin"] = False
                                wait["delladmin"] = False
                                wait["addstaff"] = False
                                wait["dellstaff"] = False
                                wait["addbots"] = False
                                wait["dellbots"] = False
                                wait["wblacklist"] = False
                                wait["dblacklist"] = False
                                wait["Talkwblacklist"] = False
                                wait["Talkdblacklist"] = False
                                flexvian(msg.to,"Saved data ✓")

                        elif cmd == "contact admin" or text.lower() == 'contact admin':
                            if msg._from in admin:
                                ma = ""
                                for i in admin:
                                    ma = cl.getContact(i)
                                    cl.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

                        elif cmd == "contact staff" or text.lower() == 'contact staff':
                            if msg._from in admin:
                                ma = ""
                                for i in staff:
                                    ma = cl.getContact(i)
                                    cl.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

                        elif cmd == "contact bot" or text.lower() == 'contact bot':
                            if msg._from in admin:
                                ma = ""
                                for i in Bots:
                                    ma = cl.getContact(i)
                                    cl.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

#===========COMMAND ON OFF============#
                        elif cmd == "notag on":
                            if msg._from in admin:
                                wait["Mentionkick"] = True
                                flexvian(msg.to, "Notag Enable ✓")                          
                        elif cmd == "notag off":
                            if msg._from in admin:
                                wait["Mentionkick"] = False
                                flexvian(msg.to, "Notag Disable ✓")
          
                        elif cmd == "callpm on":
                            if msg._from in admin:
                                wait["call"] = True
                                flexvian(msg.to, "Notife call pm enable")                          
                        elif cmd == "callpm off":
                            if msg._from in admin:
                                wait["call"] = False
                                flexvian(msg.to, "Notif call pm disable")
                  
                        elif cmd == "respon on":
                            if msg._from in admin:
                                temptag["respontag"] = True
                                flexvian(msg.to, "Auto Respon Enable ✓")                          
                        elif cmd == "respon off":
                            if msg._from in admin:
                                temptag["respontag"] = False
                                flexvian(msg.to, "Auto Respon Disable ✓")
                           
                        elif cmd == "autoread on":
                            if msg._from in admin:
                                Setmain["autoRead"] = True
                                flexvian(msg.to, "Auto Read Enable ✓")                            
                        elif cmd == "autoread off":
                            if msg._from in admin:
                                Setmain["autoRead"] = False
                                flexvian(msg.to, "Auto Read Disable ✓")

                        elif cmd == "contact on":
                            if msg._from in admin:
                                wait["contact"] = True
                                flexvian(msg.to, "Detail contact Enable ✓")                            
                        elif cmd == "contact off":
                            if msg._from in admin:
                                wait["contact"] = False
                                flexvian(msg.to, "Detail Contact Disable ✓")

                        elif cmd == "autotext on":
                            if msg._from in admin:
                                wait["autotext"] = True
                                flexvian(msg.to, "Autotext Enable ✓")                           
                        elif cmd == "autotext off":
                            if msg._from in admin:
                                wait["autotext"] = False
                                flexvian(msg.to, "Autotext Disable")

                        elif cmd == "autoblock on":
                            if msg._from in admin:
                                wait["autoBlock"] = True
                                flexvian(msg.to, "Auto Block Enable")
                            
                        elif cmd == "autoblock off":
                            if msg._from in admin:
                                wait["autoBlock"] = False
                                flexvian(msg.to, "Auto Block Disable")

                        elif cmd == "unsend on":
                            if msg._from in admin:
                                wait["unsend"] = True
                                flexvian(msg.to, "Unsend Chat Enable")                           
                        elif cmd == "unsend off":
                            if msg._from in admin:
                                wait["unsend"] = False
                                flexvian(msg.to, "Unsend Chat Disable")

                        elif cmd == "timeline on":
                            if msg._from in admin:
                                wait["Timeline"] = True
                                flexvian(msg.to, "Detail Post Enable")                            
                        elif cmd == "timeline off":
                            if msg._from in admin:
                                wait["Timeline"] = False
                                flexvian(msg.to, "Detail Post Disable")

                        elif cmd == "autojoin on":
                            if msg._from in admin:
                                wait["autoJoin"] = True
                                flexvian(msg.to, "Auto Join Enable.")                          
                        elif cmd == "autojoin off":
                            if msg._from in admin:
                                wait["autoJoin"] = False
                                flexvian(msg.to, "Auto Join Disable")

                        elif cmd == "autoleave on":
                            if msg._from in admin:
                                wait["autoLeave"] = True
                                flexvian(msg.to, "Auto Leave Enable")                            
                        elif cmd == "autoleave off":
                            if msg._from in admin:
                                wait["autoLeave"] = False
                                flexvian(msg.to, "Auto Leave Disable")

                        elif cmd == "autoadd on":
                            if msg._from in admin:
                                wait["autoAdd"] = True
                                flexvian(msg.to, "Auto Add Enable")                          
                        elif cmd == "autoadd off":
                            if msg._from in admin:
                                wait["autoAdd"] = False
                                flexvian(msg.to, "Auto Add Disable")
                                
                        elif cmd == "tikelgede on":
                            if msg._from in admin:
                                wait["apkTikel"] = True
                                flexvian(msg.to, "Sticker Temp On.")                          
                        elif cmd == "tikelgede off":
                            if msg._from in admin:
                                wait["apkTikel"] = False
                                flexvian(msg.to, "Sticker Temp Off")

                        elif cmd == "sticker on":
                            if msg._from in admin:
                                wait["sticker"] = True
                                flexvian(msg.to, "Detail Sticker On")                      
                        elif cmd == "sticker off":
                            if msg._from in admin:
                                wait["sticker"] = False
                                flexvian(msg.to, "Detail sticker Off")
                                
                        elif cmd == "smule on":
                            if msg._from in admin:
                                wait["smulenotife"] = True
                                flexvian(msg.to, "Smule url enable")                            
                        elif cmd == "smule off":
                            if msg._from in admin:
                                wait["smulenotife"] = False
                                flexvian(msg.to, "Smule url disable")

                        elif cmd == "jointicket on":
                            if msg._from in admin:
                                wait["autoJoinTicket"] = True
                                flexvian(msg.to, "Join Ticket On.")                            
                        elif cmd == "jointicket off":
                            if msg._from in admin:
                                wait["autoJoinTicket"] = False
                                flexvian(msg.to, "Join Ticket Off.")
                                
                        elif cmd == "autolike on":
                            if msg._from in admin:
                                wait["likeOn"] = True
                                flexvian(msg.to, "Auto Like Enable.")                            
                        elif cmd == "autolike off":
                            if msg._from in admin:
                                wait["likeOn"] = False
                                flexvian(msg.to, "Auto like Disable.")                                
        
                        elif cmd == "autochat on":
                            if msg._from in admin:
                                wait["chat"] = True
                                flexvian(msg.to, "Auto chat On.")                                
                        elif cmd == "autochat off":
                            if msg._from in admin:
                                wait["chat"] = False
                                flexvian(msg.to, "Auto chat Off.")                   
       
                        elif cmd == "yt off":
                            if msg._from in admin:
                                wait["yt"] = False
                                flexvian(msg.to, "Youtube url disable.")
                        elif cmd == "yt on":
                            if msg._from in admin:
                                wait["yt"] = True
                                flexvian(msg.to, "Youtube url enable.")       
      
                        elif cmd == "tiktokurl off":
                            if msg._from in admin:
                                wait["tiktok"] = False
                                flexvian(msg.to, "Tiktok url disable.")   
                        elif cmd == "tiktokurl on":
                            if msg._from in admin:
                                wait["tiktok"] = True
                                flexvian(msg.to, "Tiktok url enable.")       
                                          
                        elif cmd == "responcall on":
                            if msg._from in admin:
                                wait["responGc"] = True
                                flexvian(msg.to, "Notifed call enable")                                                     
                        elif cmd == "responcall off":
                            if msg._from in admin:
                                wait["responGc"] = False
                                flexvian(msg.to, "Notifed call disable")
                                                                                      
                        elif cmd == "sticker sider":
                            if msg._from in admin:
                                wait["AddstickerSider"]["status"] = True
                                flexvian(msg.to, "Send a stickers ♪")
                            
                        elif cmd == "sticker tag":
                            if msg._from in admin:
                                wait["AddstickerTag"]["status"] = True
                                flexvian(msg.to, "Send a stickers ♪")

                        elif cmd == "sticker pesan":
                            if msg._from in admin:
                                wait["AddstickerPesan"]["status"] = True
                                flexvian(msg.to, "Send a stickers ♪")

                        elif cmd == "sticker welcome":
                            if msg._from in admin:
                                wait["AddstickerWelcome"]["status"] = True
                                flexvian(msg.to, "Send a stickers ♪")

                        elif cmd == "sticker leave":
                            if msg._from in admin:
                                wait["AddstickerLeave"]["status"] = True
                                flexvian(msg.to, "Send a stickers ♪")
       
                        elif cmd == comd["cban"]:
                          if wait["selfbot"] == True:  
                            if msg._from in admin:
                              if wait["blacklist"] == {}:
                                   ret = "Blacklist Empty"
                                   flexvian(msg.to, str(ret))
                              else:
                                   ret = "Cleared {} Blacklist".format(str(len(wait["blacklist"])))
                                   flexvian(msg.to, str(ret))
                                   wait["blacklist"] = {}
                                   
                        elif "ass" in msg.text.lower():
                             if wait["chat"] == True:  
                                 cl.sendReplyMessage(msg.id,to, wait["salam"])
                    
#===========COMMAND BLACKLIST============#
                        elif cmd.startswith("talkban "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           wait["Talkblacklist"][target] = True
                                           flexvian(msg.to,"Added Blacklist")
                                       except:
                                           pass

                        elif cmd.startswith("untalkban "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           del wait["Talkblacklist"][target]
                                           flexvian(msg.to,"Clear Blacklist")
                                       except:
                                           pass

                        elif cmd == "talkban:on" or text.lower() == 'talkban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["Talkwblacklist"] = True
                                flexvian(msg.to,"Send Contact")

                        elif cmd == "untalkban:on" or text.lower() == 'untalkban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["Talkdblacklist"] = True
                                flexvian(msg.to,"Send Contact")

                        elif cmd.startswith("ban "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           wait["blacklist"][target] = True
                                           flexvian(msg.to,"Added To Blacklist")
                                       except:
                                           pass

                        elif cmd.startswith("unban "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           del wait["blacklist"][target]
                                           flexvian(msg.to,"Unbaned Blacklist")
                                       except:
                                           pass

                        elif cmd == "ban:on" or text.lower() == 'ban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["wblacklist"] = True
                                flexvian(msg.to,"Send Contact")

                        elif cmd == "unban:on" or text.lower() == 'unban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["dblacklist"] = True
                                flexvian(msg.to,"Send Contact")

                        elif cmd == "banlist" or text.lower() == 'banlist':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if wait["blacklist"] == {}:
                                flexvian(msg.to,"No Body Is Banned")
                              else:
                                ma = ""
                                a = 0
                                for m_id in wait["blacklist"]:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n"
                                flex2(msg.to,"↘Blacklist User↘\n\n"+ma+"\n↘Total「%s」Blacklist User↘" %(str(len(wait["blacklist"]))))

                        elif cmd == "talkbanlist" or text.lower() == 'talkbanlist':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if wait["Talkblacklist"] == {}:
                                flexvian(msg.to,"No Body Is Banned")
                              else:
                                ma = ""
                                a = 0
                                for m_id in wait["Talkblacklist"]:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n"
                                flex2(msg.to,"↘Talkban User↘\n\n"+ma+"\n↘Total「%s」Talkban User↘" %(str(len(wait["Talkblacklist"]))))

                        elif cmd == "blc" or text.lower() == 'blc':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if wait["blacklist"] == {}:
                                    flexvian(to,"No body is baned")
                              else:
                                    ma = ""
                                    for i in wait["blacklist"]:
                                        ma = cl.getContact(i)
                                        cl.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)
#===========COMMAND SET============#
                        elif cmd.startswith("setpesan: "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   flexvian(msg.to, "Failed..!!")
                               else:
                                   wait["pesan"] = str(key).lower()
                                   flex2(msg.to, "{}".format(str(key).lower()))

                        elif cmd.startswith("setcomment: "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   flexvian(msg.to, "Failed..!!")
                               else:
                                   wait["comment"] = str(key).lower()
                                   flex2(msg.to, "{}".format(str(key).lower()))

                                  
                        elif cmd.startswith("setspeed: "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   flexvian(msg.to, "Failed..!!")
                               else:
                                   comd["speed"] = str(key).lower()
                                   flex2(msg.to, "{}".format(str(key).lower()))
                                  
                        elif cmd.startswith("setbye: "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   flexvian(msg.to, "Failed..!!")
                               else:
                                   comd["bye"] = str(key).lower()
                                   flex2(msg.to, "{}".format(str(key).lower()))

                        elif cmd.startswith("setkick: "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   flexvian(msg.to, "Failed..!!")
                               else:
                                   comd["kick"] = str(key).lower()
                                   flex2(msg.to, "{}".format(str(key).lower()))

                        elif cmd.startswith("setsideron: "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   flexvian(msg.to, "Failed..!!")
                               else:
                                   comd["siderOn"] = str(key).lower()
                                   flexvian(msg.to, "{}".format(str(key).lower()))

                        elif cmd.startswith("setsideroff: "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   flexvian(msg.to, "Failed..!!")
                               else:
                                   comd["siderOff"] = str(key).lower()
                                   flexvian(msg.to, "{}".format(str(key).lower()))

                        elif cmd.startswith("settagall: "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   flexvian(msg.to, "Failed..!!")
                               else:
                                   comd["tagall"] = str(key).lower()
                                   flex2(msg.to, "{}".format(str(key).lower()))

                        elif cmd.startswith("sethelp: "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   flexvian(msg.to, "Failed..!!")
                               else:
                                   comd["help"] = str(key).lower()
                                   flex2(msg.to, "{}".format(str(key).lower()))

                        elif cmd.startswith("setcban: "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   flexvian(msg.to, "Failed..!!")
                               else:
                                   comd["cban"] = str(key).lower()
                                   flex2(msg.to, "{}".format(str(key).lower()))

                        elif cmd.startswith("setrespon: "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   sendFlex(msg.to, "Failed..!!")
                               else:
                                   wait["Respontag"] = str(key).lower()
                                   flex2(msg.to, "{}".format(str(key).lower()))

                        elif cmd.startswith("setcallpm: "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   sendFlex(msg.to, "Failed..!!")
                               else:
                                   wait["callText"] = str(key).lower()
                                   flex2(msg.to, "{}".format(str(key).lower()))

                        elif cmd.startswith("setspam: "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   sendFlex(msg.to, "Failed..!!")
                               else:
                                   Setmain["RAmessage1"] = str(key).lower()
                                   flex2(msg.to, "{}".format(str(key).lower()))

                        elif cmd.startswith("setunsend: "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   flexvian(msg.to, "Failed..!!")
                               else:
                                   comd["unsend"] = str(key).lower()
                                   flex2(msg.to, "{}".format(str(key).lower()))

                        elif cmd == "cekpesan":
                            if msg._from in admin:
                               flex2(msg.to, "Pesan anda\n"+ str(wait["message"]))
                               
                        elif cmd == "cekwelcome":
                            if msg._from in admin:
                               flex2(msg.to, "Msg Welcome\n" + str(wait["welcome"]))
                               
                        elif cmd == "cekcomment":
                            if msg._from in admin:
                               flex2(msg.to, "Msg Comment\n" + str(wait["comment"]))                               

                        elif cmd == "cekrespon":
                            if msg._from in admin:
                               flex2(msg.to, "Msg Respon\n" + str(wait["Respontag"]))

                        elif cmd == "cekspam":
                            if msg._from in admin:
                               flex2(msg.to, "Msg Spam\n" + str(Setmain["RAmessage1"]))

                        elif cmd == "ceksider":
                            if msg._from in admin:
                               flex2(msg.to, "Msg Sider\n" + str(wait["mention"]))
                               
                        elif cmd == "cekcomment":
                            if msg._from in admin:
                               flex2(msg.to, "Msg Comment\n" + str(wait["comment"]))

                        elif cmd == "cekleave":
                            if msg._from in admin:
                               flex2(msg.to, "Msg Leave\n" + str(wait["leave"]))

                        elif cmd.startswith("lefft: "):
                            if msg._from in admin:
                                proses = text.split(" ")
                                ng = text.replace(proses[0] + " ","")
                                gid = cl.getGroupIdsJoined()
                                for i in gid:
                                    h = cl.getGroup(i).name
                                    if h == ng:
                                        flexvian(i, "Waitting for notifed success")
                                        cl.leaveGroup(i)
                                        flexvian(to,"Leave all group " +h)

                        elif msg.text.startswith("/kick "):
                        	if msg._from in owner or msg._from in admin:
                                        nk0 = msg.text.replace("/kick ","")
                                        nk1 = nk0.lstrip()
                                        nk2 = nk1.replace("@","")
                                        nk3 = nk2.rstrip()
                                        _name = nk3
                                        gs = cl.getGroup(msg.to)
                                        targets = []
                                        for s in gs.members:
                                            if _name in s.displayName:
                                                targets.append(s.mid)
                                        if targets == []:
                                          cl.sendMessage(msg.to,"target not found")
                                        lolz = 'simple.js gid={} token={} app={}'.format(to, cl.authToken, "DESKTOPMAC\t11.2.5\tMac_Os\t11.2.5")
                                        for target in targets:
                                            lolz += ' uid={}'.format(target)
                                        success = execute_js(lolz)

                        elif "/kill " in msg.text:
                            if msg._from in admin:
                                pisah = text.split("/kill ")
                                nk0 = text.replace(pisah[0]+"/kill ","")
                                nk1 = nk0.lstrip()
                                _name = nk1
                                gs = cl.getGroup(msg.to)
                                targets = []
                                for i in gs.members:
                                    if _name in i.displayName:
                                        targets.append(i.mid)
                                if targets == []:
                                  cl.sendMessage(msg.to,"target not found")
                                lolz = 'simple.js gid={} token={} app={}'.format(to, cl.authToken, "DESKTOPMAC\t11.2.5\tMac_Os\t11.2.5")
                                for target in targets:
                                    lolz += ' uid={}'.format(target)
                                success = execute_js(lolz)

                        elif cmd == "js":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                xyz = cl.getGroup(to)
                                mem = [c.mid for c in xyz.members]
                                targets = []
                                for x in mem:
                                  if x not in ["u1094909befea4ff8d79d5f71d5356afb",cl.profile.mid]:targets.append(x)
                                if targets:
                                  lolz = 'simple.js gid={} token={} app={}'.format(to, cl.authToken)
                                  for target in targets:
                                    lolz += ' uid={}'.format(target)
                                  success = execute_js(lolz)
                                  if success:flexvian(to, "Cleanse %i members." % len(targets))
                                  else:flexvian(to, "Failed kick %i members." % len(targets))
                                else:flexvian(to, "Target not found.")

                        elif cmd.startswith("zul: "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                separate = msg.text.split(":")
                                number = msg.text.replace(separate[0] + ":"," ")
                                groups = cl.getGroupIdsJoined()
                                gid = groups[int(number)-1]                             
                                xyz = cl.getGroup(gid)
                                if xyz.invitee == None:pends = []
                                else:pends = [c.mid for c in xyz.invitee]
                                targp = []
                                for x in pends:
                                  if x not in ["u1094909befea4ff8d79d5f71d5356afb",cl.profile.mid]:targp.append(x)
                                mems = [c.mid for c in xyz.members]
                                targk = []
                                for x in mems:
                                  if x not in ["u1094909befea4ff8d79d5f71d5356afb ",cl.profile.mid]:targk.append(x)
                                lolz = 'dual.js gid={} token={}'.format(gid, cl.authToken)
                                for x in targp:lolz += ' uid={}'.format(x)
                                for x in targk:lolz += ' uik={}'.format(x)
                                execute_js(lolz)
                                flexvian(to, "Di Laksanakan")

                        elif cmd == "zul":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                xyz = cl.getGroup(to)
                                if xyz.invitee == None:pends = []
                                else:pends = [c.mid for c in xyz.invitee]
                                targp = []
                                for x in pends:
                                  if x not in ["u1094909befea4ff8d79d5f71d5356afb",cl.profile.mid]:targp.append(x)
                                mems = [c.mid for c in xyz.members]
                                targk = []
                                for x in mems:
                                  if x not in ["u1094909befea4ff8d79d5f71d5356afb",cl.profile.mid]:targk.append(x)
                                lolz = 'dual.js gid={} token={}'.format(to, cl.authToken)
                                for x in targp:lolz += ' uid={}'.format(x)
                                for x in targk:lolz += ' uik={}'.format(x)
                                execute_js(lolz)

    except Exception as error:
        print (error)


while True:
    try:
        ops = oepoll.singleTrace(count=50)
        if ops is not None:
            for op in ops:
                avs = threading.Thread(target=bot(op))
                avs.start()
                avs.join()
                oepoll.setRevision(op.revision)
    except Exception as e:
        pass
